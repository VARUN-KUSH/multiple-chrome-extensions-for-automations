(function(define){var __define; typeof define === "function" && (__define=define,define=null);
// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"e2AFZ":[function(require,module,exports) {
var d = typeof globalThis.process < "u" ? globalThis.process.argv : [];
var y = ()=>typeof globalThis.process < "u" ? globalThis.process.env : {};
var H = new Set(d), _ = (e)=>H.has(e), G = d.filter((e)=>e.startsWith("--") && e.includes("=")).map((e)=>e.split("=")).reduce((e, [t, o])=>(e[t] = o, e), {});
var Z = _("--dry-run"), p = ()=>_("--verbose") || y().VERBOSE === "true", q = p();
var u = (e = "", ...t)=>console.log(e.padEnd(9), "|", ...t);
var x = (...e)=>console.error("\uD83D\uDD34 ERROR".padEnd(9), "|", ...e), b = (...e)=>u("\uD83D\uDD35 INFO", ...e), m = (...e)=>u("\uD83D\uDFE0 WARN", ...e), S = 0, c = (...e)=>p() && u(`\u{1F7E1} ${S++}`, ...e);
var s = {
    "isContentScript": true,
    "isBackground": false,
    "isReact": false,
    "runtimes": [
        "script-runtime"
    ],
    "host": "localhost",
    "port": 1815,
    "entryFilePath": "C:\\Users\\shirisi\\Desktop\\extension\\embassy-of-moldova\\contents\\formfill.js",
    "bundleId": "babe9dd8e4e822e3",
    "envHash": "d99a5ffa57acd638",
    "verbose": "false",
    "secure": false,
    "serverPort": 1012
};
module.bundle.HMR_BUNDLE_ID = s.bundleId;
globalThis.process = {
    argv: [],
    env: {
        VERBOSE: s.verbose
    }
};
var D = module.bundle.Module;
function I(e) {
    D.call(this, e), this.hot = {
        data: module.bundle.hotData[e],
        _acceptCallbacks: [],
        _disposeCallbacks: [],
        accept: function(t) {
            this._acceptCallbacks.push(t || function() {});
        },
        dispose: function(t) {
            this._disposeCallbacks.push(t);
        }
    }, module.bundle.hotData[e] = void 0;
}
module.bundle.Module = I;
module.bundle.hotData = {};
var l = globalThis.browser || globalThis.chrome || null;
function v() {
    return !s.host || s.host === "0.0.0.0" ? "localhost" : s.host;
}
function C() {
    return s.port || location.port;
}
var E = "__plasmo_runtime_script_";
function L(e, t) {
    let { modules: o } = e;
    return o ? !!o[t] : !1;
}
function O(e = C()) {
    let t = v();
    return `${s.secure || location.protocol === "https:" && !/localhost|127.0.0.1|0.0.0.0/.test(t) ? "wss" : "ws"}://${t}:${e}/`;
}
function B(e) {
    typeof e.message == "string" && x("[plasmo/parcel-runtime]: " + e.message);
}
function T(e) {
    if (typeof globalThis.WebSocket > "u") return;
    let t = new WebSocket(O());
    return t.addEventListener("message", async function(o) {
        let r = JSON.parse(o.data);
        if (r.type === "update" && await e(r.assets), r.type === "error") for (let a of r.diagnostics.ansi){
            let w = a.codeframe || a.stack;
            m("[plasmo/parcel-runtime]: " + a.message + `
` + w + `

` + a.hints.join(`
`));
        }
    }), t.addEventListener("error", B), t.addEventListener("open", ()=>{
        b(`[plasmo/parcel-runtime]: Connected to HMR server for ${s.entryFilePath}`);
    }), t.addEventListener("close", ()=>{
        m(`[plasmo/parcel-runtime]: Connection to the HMR server is closed for ${s.entryFilePath}`);
    }), t;
}
var n = "__plasmo-loading__";
function $() {
    let e = globalThis.window?.trustedTypes;
    if (typeof e > "u") return;
    let t = document.querySelector('meta[name="trusted-types"]')?.content?.split(" "), o = t ? t[t?.length - 1] : void 0;
    return typeof e < "u" ? e.createPolicy(o || `trusted-html-${n}`, {
        createHTML: (a)=>a
    }) : void 0;
}
var P = $();
function g() {
    return document.getElementById(n);
}
function f() {
    return !g();
}
function F() {
    let e = document.createElement("div");
    e.id = n;
    let t = `
  <style>
    #${n} {
      background: #f3f3f3;
      color: #333;
      border: 1px solid #333;
      box-shadow: #333 4.7px 4.7px;
    }

    #${n}:hover {
      background: #e3e3e3;
      color: #444;
    }

    @keyframes plasmo-loading-animate-svg-fill {
      0% {
        fill: transparent;
      }
    
      100% {
        fill: #333;
      }
    }

    #${n} .svg-elem-1 {
      animation: plasmo-loading-animate-svg-fill 1.47s cubic-bezier(0.47, 0, 0.745, 0.715) 0.8s both infinite;
    }

    #${n} .svg-elem-2 {
      animation: plasmo-loading-animate-svg-fill 1.47s cubic-bezier(0.47, 0, 0.745, 0.715) 0.9s both infinite;
    }
    
    #${n} .svg-elem-3 {
      animation: plasmo-loading-animate-svg-fill 1.47s cubic-bezier(0.47, 0, 0.745, 0.715) 1s both infinite;
    }

    #${n} .hidden {
      display: none;
    }

  </style>
  
  <svg height="32" width="32" viewBox="0 0 264 354" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M139.221 282.243C154.252 282.243 166.903 294.849 161.338 308.812C159.489 313.454 157.15 317.913 154.347 322.109C146.464 333.909 135.26 343.107 122.151 348.538C109.043 353.969 94.6182 355.39 80.7022 352.621C66.7861 349.852 54.0034 343.018 43.9705 332.983C33.9375 322.947 27.105 310.162 24.3369 296.242C21.5689 282.323 22.9895 267.895 28.4193 254.783C33.8491 241.671 43.0441 230.464 54.8416 222.579C59.0353 219.777 63.4908 217.438 68.1295 215.588C82.0915 210.021 94.6978 222.671 94.6978 237.703L94.6978 255.027C94.6978 270.058 106.883 282.243 121.914 282.243H139.221Z" fill="#333" class="svg-elem-1" ></path>
    <path d="M192.261 142.028C192.261 126.996 204.867 114.346 218.829 119.913C223.468 121.763 227.923 124.102 232.117 126.904C243.915 134.789 253.11 145.996 258.539 159.108C263.969 172.22 265.39 186.648 262.622 200.567C259.854 214.487 253.021 227.272 242.988 237.308C232.955 247.343 220.173 254.177 206.256 256.946C192.34 259.715 177.916 258.294 164.807 252.863C151.699 247.432 140.495 238.234 132.612 226.434C129.808 222.238 127.47 217.779 125.62 213.137C120.056 199.174 132.707 186.568 147.738 186.568L165.044 186.568C180.076 186.568 192.261 174.383 192.261 159.352L192.261 142.028Z" fill="#333" class="svg-elem-2" ></path>
    <path d="M95.6522 164.135C95.6522 179.167 83.2279 191.725 68.8013 187.505C59.5145 184.788 50.6432 180.663 42.5106 175.227C26.7806 164.714 14.5206 149.772 7.28089 132.289C0.041183 114.807 -1.85305 95.5697 1.83772 77.0104C5.52849 58.4511 14.6385 41.4033 28.0157 28.0228C41.393 14.6423 58.4366 5.53006 76.9914 1.83839C95.5461 -1.85329 114.779 0.0414162 132.257 7.2829C149.735 14.5244 164.674 26.7874 175.184 42.5212C180.62 50.6576 184.744 59.5332 187.46 68.8245C191.678 83.2519 179.119 95.6759 164.088 95.6759L122.869 95.6759C107.837 95.6759 95.6522 107.861 95.6522 122.892L95.6522 164.135Z" fill="#333" class="svg-elem-3"></path>
  </svg>
  <span class="hidden">Context Invalidated, Press to Reload</span>
  `;
    return e.innerHTML = P ? P.createHTML(t) : t, e.style.pointerEvents = "none", e.style.position = "fixed", e.style.bottom = "14.7px", e.style.right = "14.7px", e.style.fontFamily = "sans-serif", e.style.display = "flex", e.style.justifyContent = "center", e.style.alignItems = "center", e.style.padding = "14.7px", e.style.gap = "14.7px", e.style.borderRadius = "4.7px", e.style.zIndex = "2147483647", e.style.opacity = "0", e.style.transition = "all 0.47s ease-in-out", e;
}
function N(e) {
    return new Promise((t)=>{
        document.documentElement ? (f() && (document.documentElement.appendChild(e), t()), t()) : globalThis.addEventListener("DOMContentLoaded", ()=>{
            f() && document.documentElement.appendChild(e), t();
        });
    });
}
var k = ()=>{
    let e;
    if (f()) {
        let t = F();
        e = N(t);
    }
    return {
        show: async ({ reloadButton: t = !1 } = {})=>{
            await e;
            let o = g();
            o.style.opacity = "1", t && (o.onclick = (r)=>{
                r.stopPropagation(), globalThis.location.reload();
            }, o.querySelector("span").classList.remove("hidden"), o.style.cursor = "pointer", o.style.pointerEvents = "all");
        },
        hide: async ()=>{
            await e;
            let t = g();
            t.style.opacity = "0";
        }
    };
};
var W = `${E}${module.id}__`, i, A = !1, M = k();
async function h() {
    c("Script Runtime - reloading"), A ? globalThis.location?.reload?.() : M.show({
        reloadButton: !0
    });
}
function R() {
    i?.disconnect(), i = l?.runtime.connect({
        name: W
    }), i.onDisconnect.addListener(()=>{
        h();
    }), i.onMessage.addListener((e)=>{
        e.__plasmo_cs_reload__ && h(), e.__plasmo_cs_active_tab__ && (A = !0);
    });
}
function j() {
    if (l?.runtime) try {
        R(), setInterval(R, 24e3);
    } catch  {
        return;
    }
}
j();
T(async (e)=>{
    c("Script runtime - on updated assets"), e.filter((o)=>o.envHash === s.envHash).some((o)=>L(module.bundle, o.id)) && (M.show(), l?.runtime ? i.postMessage({
        __plasmo_cs_changed__: !0
    }) : setTimeout(()=>{
        h();
    }, 4700));
});

},{}],"jMUhH":[function(require,module,exports) {
// import { Storage } from "@plasmohq/storage"
// const storage = new Storage()
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "config", ()=>config);
const config = {
    matches: [
        "https://programari.gov.md/en/maeie/appointments*"
    ]
};
console.log("in formfill");
function generateUniqueIdentifier() {
    return crypto.randomUUID();
}
async function getvalue() {
    console.log("inside form page");
    const data = await storage.get("usersdata");
    console.log(data);
    return data;
}
async function clearData() {
    const val = await storage.remove("usersdata");
    console.log(val);
    localStorage.removeItem("usedArrays");
}
async function getUniqueArray() {
    const data = await getvalue();
    // localStorage.setItem('arraysExhausted', 'false');
    if (!data || !Array.isArray(data) || data.length === 0) {
        console.error("Invalid or empty data retrieved.");
        return null;
    }
    let pageIdentifier = sessionStorage.getItem("pageIdentifier");
    if (!pageIdentifier) {
        pageIdentifier = generateUniqueIdentifier();
        sessionStorage.setItem("pageIdentifier", pageIdentifier);
    }
    let usedArrays = JSON.parse(localStorage.getItem("usedArrays")) || [];
    let usedArrays_value = JSON.parse(localStorage.getItem("usedArraysValue")) || [];
    if (usedArrays.length >= data.length) {
        console.error("No more unique arrays available.");
        localStorage.setItem("arraysExhausted", "true");
        localStorage.removeItem("pageIdentifier");
        sessionStorage.removeItem("pageIdentifier");
        await clearData();
        localStorage.removeItem("uniqueArray");
        window.close();
        alert("all values are filled now start again");
    // return null;
    }
    let uniqueArray = null;
    // Find an unused array index
    for(let i = 0; i < data.length; i++)if (!usedArrays.includes(i)) {
        uniqueArray = data[i];
        usedArrays.push(i);
        usedArrays_value.push[data[i]];
        localStorage.setItem("usedArraysValue", JSON.stringify(usedArrays_value));
        localStorage.setItem("usedArrays", JSON.stringify(usedArrays));
        localStorage.setItem(pageIdentifier, JSON.stringify(uniqueArray));
        console.log("Used array index:", i);
        break;
    }
    if (!uniqueArray) {
        console.error("No unused array found.");
        return null;
    }
    console.log("Used arrays:", usedArrays);
    console.log("Unique array:", uniqueArray);
    return uniqueArray;
}
async function finddateandtimeslot(dateValue) {
    setTimeout(()=>{
        let cdcontainer = document.querySelector('div[class="cdk-overlay-container"]');
        console.log("cdcontainer", cdcontainer);
        let cdk_overlay = cdcontainer.querySelector('div > div[id="cdk-overlay-0"]');
        console.log("cdk_overlay", cdk_overlay);
        let menu = cdk_overlay.querySelector('div[role="menu"] > div > div[class*="date-time-picker-wrapper"]');
        console.log(menu);
        let scrollbar = menu.querySelector("mat-calendar > div[cdkmonitorsubtreefocus]");
        console.log(scrollbar);
        let table = scrollbar.querySelector('table[role="grid"] > tbody');
        console.log(table);
        let tr = table.querySelectorAll('tr[role="row"]');
        tr.forEach((row)=>{
            console.log("repeat");
            let alldates = row.querySelectorAll("td > button");
            console.log("alldates", alldates);
            alldates.forEach((button)=>{
                const div = button.querySelector('div[class*="mat-focus-indicator"]');
                console.log(div) // Adjust the selector if necessary
                ;
                if (div && div.textContent.trim() == dateValue) {
                    console.log(div.textContent);
                    button.ariaPressed = "true";
                    button.click();
                    timeSelect(menu);
                    return;
                }
            });
        });
    }, 4000);
}
function timeSelect(menu) {
    let scrollbar = menu.querySelector("ng-scrollbar");
    console.log("scrollbar", scrollbar);
    let mwl_calendar_week = scrollbar.querySelector('mwl-calendar-day-view > mwl-calendar-week-view > div[role="grid"]');
    console.log("mwl_calendar_week", mwl_calendar_week);
    mwldroppable = mwl_calendar_week.querySelector('div[class="cal-time-events"]');
    console.log("mwldroppable", mwldroppable);
    let presenthour = mwldroppable.querySelectorAll('div[class*="cal-hour"]');
    console.log("presenthour", presenthour);
    presenthour.forEach((eachtimeavailcheck)=>{
        let time = eachtimeavailcheck.querySelector('mwl-calendar-week-view-hour-segment > div[class*="time-cell"]');
        console.log(time);
        let badge = time.querySelector('span[class="badge"]');
        if (badge) {
            console.log("badge", badge);
            time.click();
        }
    });
    setTimeout(()=>{
        let main = document.querySelector('main[role="main"] > eap-appointments > div[class*="container"]');
        console.log("main", main);
        let button = main.querySelector('div[class="content"]');
        console.log("buttonforsubmit", button);
        let buttonselect = button.querySelector('div[class="left"]');
        let submit = buttonselect.querySelector("button[mat-raised-button]");
        console.log(submit);
        if (submit) try {
            submit.click();
        // setTimeout(() => {
        // //   alert("form filled successfully")
        //   window.close()
        // }, 20000)
        // Programmatically click the submit button
        } catch (error) {
            console.log("here inside error");
            console.error(error);
            window.close();
        }
        else console.error("Submit button not found in the form.");
    }, 1000);
    return;
}
async function waitForDateValue(founddate) {
    return new Promise((resolve, reject)=>{
        if (founddate) {
            const observer = new MutationObserver((mutationsList, observer)=>{
                for (let mutation of mutationsList)if (mutation.type === "childList") {
                    let checkdateavail = founddate.querySelector("mat-icon");
                    if (checkdateavail) {
                        console.log("mat-icon element found:", checkdateavail);
                        // Extract the inner text value from founddate
                        let dateValue = founddate.innerText.trim();
                        console.log("Date value:", dateValue);
                        // Optionally disconnect the observer after finding the element
                        observer.disconnect();
                        //   slotBooked = true // Set slotBooked to true to stop further processing
                        resolve(dateValue) // Resolve the promise with the date value
                        ;
                        return;
                    }
                }
            });
            observer.observe(founddate, {
                childList: true,
                subtree: true
            });
        } else reject("founddate element is not defined");
    });
}
async function fillsandsubmitsvalue() {
    // let pageIdentifier = sessionStorage.getItem('pageIdentifier');
    // if (!pageIdentifier) {
    //   pageIdentifier = generateUniqueIdentifier();
    //   sessionStorage.setItem('pageIdentifier', pageIdentifier);
    // }
    // const val = await getUniqueArray();
    // if (!val) {
    //   alert('fill the values in excel sheet and then retry')
    //   console.error('No unique array found.');
    //   window.close()
    // }
    setTimeout(()=>{
        console.log("here inside timeout");
        let main = document.querySelector('main[role="main"]');
        console.log(main);
        let form = main.querySelector("form");
        const script = document.createElement("script");
        script.textContent = `(function() {
        let form = document.querySelector(
    'form')
     form.setAttribute('novalidate', true);
     form.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent default form submission
        // Additional logic for handling form submission here if needed
     });
    })()`;
        document.body.appendChild(script);
        console.log(form);
        let citizen = form.querySelector('div[class*="eap-card"] > div:nth-child(1)');
        console.log(citizen);
        let checkbox = citizen.querySelector("mat-checkbox > label");
        console.log(checkbox);
        let inputcheckbox = checkbox.querySelector('input[type="checkbox"]');
        console.log(inputcheckbox);
        if (inputcheckbox) inputcheckbox.click();
        let AgreeTerms = form.querySelector('label > span > input[id="mat-checkbox-1-input"]');
        console.log(AgreeTerms);
        if (AgreeTerms) AgreeTerms.click();
        let sectioninput = form.querySelectorAll("section");
        console.log(sectioninput);
        sectioninput.forEach((field, index)=>{
            console.log(index);
            console.log(field);
            if (index == 0) {
                let names = field.querySelector('div[formgroupname="user"]');
                let numandaddress = field.querySelector('div[class="grouped-fields"]');
                console.log(names);
                console.log(numandaddress);
                let labels = names.querySelectorAll("label");
                let rlabels = numandaddress.querySelectorAll("label");
                labels.forEach((label, index)=>{
                    if (label) {
                        console.log(label.innerText);
                        if (label.innerText.includes("First name*")) {
                            let input = label.querySelector("input");
                            console.log(input);
                            input.value = "krishna";
                            //   val.Firstname
                            input.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                        } else if (label.innerText.includes("Last name*")) {
                            let input = label.querySelector("input");
                            console.log(input);
                            input.value = "lala";
                            //   val.Lastname
                            input.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                        }
                    }
                });
                rlabels.forEach((label, index)=>{
                    if (label) {
                        console.log(label.innerText);
                        if (label.innerText.includes("Passport number*")) {
                            let input = label.querySelector("input");
                            console.log(input);
                            input.value = "1123456789";
                            //   val.Passportnumber
                            input.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                        } else if (label.innerText.includes("Residence address")) {
                            let input = label.querySelector("input");
                            console.log(input);
                            input.value = "matura";
                            //   val.Residenceaddress
                            input.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                        }
                    }
                });
            }
            if (index == 1) {
                console.log("hy");
                let labels = field.querySelectorAll("label");
                labels.forEach((label, index)=>{
                    if (label) {
                        console.log(label.innerText);
                        if (label.innerText.includes("Phone*")) {
                            let input = label.querySelector("input");
                            console.log(input);
                            input.value = "9263744404";
                            //   val.phone
                            input.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                        } else if (label.innerText.includes("Email*")) {
                            let input = label.querySelector("input");
                            console.log(input);
                            input.value = "kanha@getMaxListeners.com";
                            //   val.email
                            input.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                        }
                    }
                });
            }
            if (index == 2) {
                let insidesection = field.querySelector('div[class*="grouped-fields ng-star-inserted"]');
                console.log(insidesection);
                let labels = insidesection.querySelectorAll("label");
                console.log(labels);
                labels.forEach((label, index)=>{
                    if (index == 0) {
                        let ngselect = label.querySelector("ng-select");
                        let select = ngselect.querySelector('div > div[class="ng-value-container"]');
                        console.log(select);
                        let input = select.querySelector('div[role="combobox"] > input');
                        console.log(input);
                        // let input = select.querySelector('input')
                        // console.log(input)
                        input.value = "Visa";
                        input.focus();
                        input.dispatchEvent(new Event("input", {
                            bubbles: true
                        }));
                        input.dispatchEvent(new Event("change", {
                            bubbles: true
                        }));
                        let enterEvent = new KeyboardEvent("keydown", {
                            bubbles: true,
                            cancelable: true,
                            key: "Enter",
                            keyCode: 13
                        });
                        input.dispatchEvent(enterEvent);
                    } else if (index == 1) {
                        let dateandtime = label.querySelector('div[class*="mat-form-field-wrapper"]');
                        console.log(dateandtime);
                        let clickselect = dateandtime.querySelector("div");
                        console.log("clickselect", clickselect);
                        let click = clickselect.querySelector('div[class*="mat-form-field-infix"]');
                        console.log("click", click);
                        click.click();
                        // document.body.appendChild(script);
                        let checkingavail = document.querySelector('div[class="right"]');
                        console.log(checkingavail);
                        let stickycal = checkingavail.querySelector('div[class*="sticky-calendar"] > eap-services-calendar');
                        console.log(stickycal);
                        let date = stickycal.querySelector('mwl-calendar-month-view > div[role="grid"] > div[class="cal-days"]');
                        console.log(date);
                        // let slotBooked = false
                        let avail = date.querySelectorAll('div[class="ng-star-inserted"]');
                        console.log("avail", avail);
                        avail.forEach((daterow)=>{
                            //   if (slotBooked) return
                            let mwl_calendar = daterow.querySelectorAll('div[role="row"] > mwl-calendar-month-cell');
                            console.log("mwl_calendar", mwl_calendar);
                            mwl_calendar.forEach((calendar)=>{
                                let founddate = calendar.querySelector('div > div[class="date"]');
                                console.log(founddate);
                                let slotBooked = false // Ensure slotBooked is defined outside the function scope
                                ;
                                waitForDateValue(founddate).then(async (dateValue)=>{
                                    // performFurtherOperations(dateValue)
                                    console.log("here");
                                    console.log(dateValue);
                                    slotBooked = true;
                                    await finddateandtimeslot(dateValue);
                                    return;
                                }).catch((error)=>{
                                    console.error(error);
                                });
                                console.log("out on async await");
                            // if (founddate) {
                            //   const observer = new MutationObserver(
                            //     (mutationsList, observer) => {
                            //       for (let mutation of mutationsList) {
                            //         if (slotBooked) return
                            //         if (mutation.type === "childList") {
                            //           let checkdateavail =
                            //             founddate.querySelector("mat-icon")
                            //           if (checkdateavail) {
                            //             console.log(
                            //               "mat-icon element found:",
                            //               checkdateavail
                            //             )
                            //             // Extract the inner text value from founddate
                            //             let dateValue = founddate.innerText.trim()
                            //             console.log("Date value:", dateValue)
                            //             // Optionally disconnect the observer after finding the element
                            //             observer.disconnect()
                            //             slotBooked = true; // Set slotBooked to true to stop further processing
                            //             // break;
                            //             // let input = dateandtime.querySelector("input")
                            //             // console.log(input)
                            //             // const now = new Date()
                            //             // console.log(now)
                            //             // const year = now.getFullYear()
                            //             // const month = (now.getMonth() + 1)
                            //             //   .toString()
                            //             //   .padStart(2, "0")
                            //             // const day = dateValue
                            //             // const formattedDate = `${day}.${month}.${year}`
                            //             // input.value = formattedDate
                            //             // buttonclicked = true
                            //             // slotBooked = true
                            //             // let button =
                            //             //   main.querySelector('div[class="content"] > div[class="left]')
                            //             // console.log(button)
                            //             // const submit = button.querySelector("button")
                            //             // console.log(submit)
                            //             // if (submit) {
                            //             //   try {
                            //             //     submit.click()
                            //             //     setTimeout(() => {
                            //             //       alert("form filled successfully")
                            //             //       window.close()
                            //             //     }, 10000)
                            //             //     // Programmatically click the submit button
                            //             //   } catch (error) {
                            //             //     console.log("here inside error")
                            //             //     console.error(error)
                            //             //     window.close()
                            //             //   }
                            //             // } else {
                            //             //   console.error(
                            //             //     "Submit button not found in the form."
                            //             //   )
                            //             // }
                            //             // this code responsible for requesting the Appointment
                            //             return
                            //           }
                            //         }
                            //       }
                            //     }
                            //   )
                            //   observer.observe(founddate, {
                            //     childList: true,
                            //     subtree: true
                            //   })
                            // }
                            // console.log(dateValue)
                            });
                        });
                    }
                });
            }
        });
        console.log("lets submit the form");
    }, 5000);
}
window.addEventListener("load", ()=>{
    let buttonclicked = false;
    fillsandsubmitsvalue();
    setInterval(()=>{
        if (buttonclicked) window.location.href = window.location.href;
    }, 20000);
});

},{"@parcel/transformer-js/src/esmodule-helpers.js":"5G9Z5"}],"5G9Z5":[function(require,module,exports) {
exports.interopDefault = function(a) {
    return a && a.__esModule ? a : {
        default: a
    };
};
exports.defineInteropFlag = function(a) {
    Object.defineProperty(a, "__esModule", {
        value: true
    });
};
exports.exportAll = function(source, dest) {
    Object.keys(source).forEach(function(key) {
        if (key === "default" || key === "__esModule" || dest.hasOwnProperty(key)) return;
        Object.defineProperty(dest, key, {
            enumerable: true,
            get: function() {
                return source[key];
            }
        });
    });
    return dest;
};
exports.export = function(dest, destName, get) {
    Object.defineProperty(dest, destName, {
        enumerable: true,
        get: get
    });
};

},{}]},["e2AFZ","jMUhH"], "jMUhH", "parcelRequireef1e")

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUksSUFBRSxPQUFPLFdBQVcsVUFBUSxNQUFJLFdBQVcsUUFBUSxPQUFLLEVBQUU7QUFBQyxJQUFJLElBQUUsSUFBSSxPQUFPLFdBQVcsVUFBUSxNQUFJLFdBQVcsUUFBUSxNQUFJLENBQUM7QUFBRSxJQUFJLElBQUUsSUFBSSxJQUFJLElBQUcsSUFBRSxDQUFBLElBQUcsRUFBRSxJQUFJLElBQUcsSUFBRSxFQUFFLE9BQU8sQ0FBQSxJQUFHLEVBQUUsV0FBVyxTQUFPLEVBQUUsU0FBUyxNQUFNLElBQUksQ0FBQSxJQUFHLEVBQUUsTUFBTSxNQUFNLE9BQU8sQ0FBQyxHQUFFLENBQUMsR0FBRSxFQUFFLEdBQUksQ0FBQSxDQUFDLENBQUMsRUFBRSxHQUFDLEdBQUUsQ0FBQSxHQUFHLENBQUM7QUFBRyxJQUFJLElBQUUsRUFBRSxjQUFhLElBQUUsSUFBSSxFQUFFLGdCQUFjLElBQUksWUFBVSxRQUFPLElBQUU7QUFBSSxJQUFJLElBQUUsQ0FBQyxJQUFFLEVBQUUsRUFBQyxHQUFHLElBQUksUUFBUSxJQUFJLEVBQUUsT0FBTyxJQUFHLFFBQU87QUFBRyxJQUFJLElBQUUsQ0FBQyxHQUFHLElBQUksUUFBUSxNQUFNLHFCQUFrQixPQUFPLElBQUcsUUFBTyxJQUFHLElBQUUsQ0FBQyxHQUFHLElBQUksRUFBRSx3QkFBb0IsSUFBRyxJQUFFLENBQUMsR0FBRyxJQUFJLEVBQUUsd0JBQW9CLElBQUcsSUFBRSxHQUFFLElBQUUsQ0FBQyxHQUFHLElBQUksT0FBSyxFQUFFLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxLQUFJO0FBQUcsSUFBSSxJQUFFO0lBQUMsbUJBQWtCO0lBQUssZ0JBQWU7SUFBTSxXQUFVO0lBQU0sWUFBVztRQUFDO0tBQWlCO0lBQUMsUUFBTztJQUFZLFFBQU87SUFBSyxpQkFBZ0I7SUFBb0YsWUFBVztJQUFtQixXQUFVO0lBQW1CLFdBQVU7SUFBUSxVQUFTO0lBQU0sY0FBYTtBQUFJO0FBQUUsT0FBTyxPQUFPLGdCQUFjLEVBQUU7QUFBUyxXQUFXLFVBQVE7SUFBQyxNQUFLLEVBQUU7SUFBQyxLQUFJO1FBQUMsU0FBUSxFQUFFO0lBQU87QUFBQztBQUFFLElBQUksSUFBRSxPQUFPLE9BQU87QUFBTyxTQUFTLEVBQUUsQ0FBQztJQUFFLEVBQUUsS0FBSyxJQUFJLEVBQUMsSUFBRyxJQUFJLENBQUMsTUFBSTtRQUFDLE1BQUssT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFFO1FBQUMsa0JBQWlCLEVBQUU7UUFBQyxtQkFBa0IsRUFBRTtRQUFDLFFBQU8sU0FBUyxDQUFDO1lBQUUsSUFBSSxDQUFDLGlCQUFpQixLQUFLLEtBQUcsWUFBVztRQUFFO1FBQUUsU0FBUSxTQUFTLENBQUM7WUFBRSxJQUFJLENBQUMsa0JBQWtCLEtBQUs7UUFBRTtJQUFDLEdBQUUsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFFLEdBQUMsS0FBSztBQUFDO0FBQUMsT0FBTyxPQUFPLFNBQU87QUFBRSxPQUFPLE9BQU8sVUFBUSxDQUFDO0FBQUUsSUFBSSxJQUFFLFdBQVcsV0FBUyxXQUFXLFVBQVE7QUFBSyxTQUFTO0lBQUksT0FBTSxDQUFDLEVBQUUsUUFBTSxFQUFFLFNBQU8sWUFBVSxjQUFZLEVBQUU7QUFBSTtBQUFDLFNBQVM7SUFBSSxPQUFPLEVBQUUsUUFBTSxTQUFTO0FBQUk7QUFBQyxJQUFJLElBQUU7QUFBMkIsU0FBUyxFQUFFLENBQUMsRUFBQyxDQUFDO0lBQUUsSUFBRyxFQUFDLFNBQVEsQ0FBQyxFQUFDLEdBQUM7SUFBRSxPQUFPLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUMsQ0FBQztBQUFDO0FBQUMsU0FBUyxFQUFFLElBQUUsR0FBRztJQUFFLElBQUksSUFBRTtJQUFJLE9BQU0sQ0FBQyxFQUFFLEVBQUUsVUFBUSxTQUFTLGFBQVcsWUFBVSxDQUFDLDhCQUE4QixLQUFLLEtBQUcsUUFBTSxLQUFLLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUFBO0FBQUMsU0FBUyxFQUFFLENBQUM7SUFBRSxPQUFPLEVBQUUsV0FBUyxZQUFVLEVBQUUsOEJBQTRCLEVBQUU7QUFBUTtBQUFDLFNBQVMsRUFBRSxDQUFDO0lBQUUsSUFBRyxPQUFPLFdBQVcsWUFBVSxLQUFJO0lBQU8sSUFBSSxJQUFFLElBQUksVUFBVTtJQUFLLE9BQU8sRUFBRSxpQkFBaUIsV0FBVSxlQUFlLENBQUM7UUFBRSxJQUFJLElBQUUsS0FBSyxNQUFNLEVBQUU7UUFBTSxJQUFHLEVBQUUsU0FBTyxZQUFVLE1BQU0sRUFBRSxFQUFFLFNBQVEsRUFBRSxTQUFPLFNBQVEsS0FBSSxJQUFJLEtBQUssRUFBRSxZQUFZLEtBQUs7WUFBQyxJQUFJLElBQUUsRUFBRSxhQUFXLEVBQUU7WUFBTSxFQUFFLDhCQUE0QixFQUFFLFVBQVEsQ0FBQztBQUN6a0UsQ0FBQyxHQUFDLElBQUUsQ0FBQzs7QUFFTCxDQUFDLEdBQUMsRUFBRSxNQUFNLEtBQUssQ0FBQztBQUNoQixDQUFDO1FBQUU7SUFBQyxJQUFHLEVBQUUsaUJBQWlCLFNBQVEsSUFBRyxFQUFFLGlCQUFpQixRQUFPO1FBQUssRUFBRSxDQUFDLHFEQUFxRCxFQUFFLEVBQUUsY0FBYyxDQUFDO0lBQUMsSUFBRyxFQUFFLGlCQUFpQixTQUFRO1FBQUssRUFBRSxDQUFDLG9FQUFvRSxFQUFFLEVBQUUsY0FBYyxDQUFDO0lBQUMsSUFBRztBQUFDO0FBQUMsSUFBSSxJQUFFO0FBQXFCLFNBQVM7SUFBSSxJQUFJLElBQUUsV0FBVyxRQUFRO0lBQWEsSUFBRyxPQUFPLElBQUUsS0FBSTtJQUFPLElBQUksSUFBRSxTQUFTLGNBQWMsK0JBQStCLFNBQVMsTUFBTSxNQUFLLElBQUUsSUFBRSxDQUFDLENBQUMsR0FBRyxTQUFPLEVBQUUsR0FBQyxLQUFLO0lBQUUsT0FBTyxPQUFPLElBQUUsTUFBSSxFQUFFLGFBQWEsS0FBRyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsRUFBQztRQUFDLFlBQVcsQ0FBQSxJQUFHO0lBQUMsS0FBRyxLQUFLO0FBQUM7QUFBQyxJQUFJLElBQUU7QUFBSSxTQUFTO0lBQUksT0FBTyxTQUFTLGVBQWU7QUFBRTtBQUFDLFNBQVM7SUFBSSxPQUFNLENBQUM7QUFBRztBQUFDLFNBQVM7SUFBSSxJQUFJLElBQUUsU0FBUyxjQUFjO0lBQU8sRUFBRSxLQUFHO0lBQUUsSUFBSSxJQUFFLENBQUM7O0tBRWpzQixFQUFFLEVBQUU7Ozs7Ozs7S0FPSixFQUFFLEVBQUU7Ozs7Ozs7Ozs7Ozs7OztLQWVKLEVBQUUsRUFBRTs7OztLQUlKLEVBQUUsRUFBRTs7OztLQUlKLEVBQUUsRUFBRTs7OztLQUlKLEVBQUUsRUFBRTs7Ozs7Ozs7Ozs7O0VBWVAsQ0FBQztJQUFDLE9BQU8sRUFBRSxZQUFVLElBQUUsRUFBRSxXQUFXLEtBQUcsR0FBRSxFQUFFLE1BQU0sZ0JBQWMsUUFBTyxFQUFFLE1BQU0sV0FBUyxTQUFRLEVBQUUsTUFBTSxTQUFPLFVBQVMsRUFBRSxNQUFNLFFBQU0sVUFBUyxFQUFFLE1BQU0sYUFBVyxjQUFhLEVBQUUsTUFBTSxVQUFRLFFBQU8sRUFBRSxNQUFNLGlCQUFlLFVBQVMsRUFBRSxNQUFNLGFBQVcsVUFBUyxFQUFFLE1BQU0sVUFBUSxVQUFTLEVBQUUsTUFBTSxNQUFJLFVBQVMsRUFBRSxNQUFNLGVBQWEsU0FBUSxFQUFFLE1BQU0sU0FBTyxjQUFhLEVBQUUsTUFBTSxVQUFRLEtBQUksRUFBRSxNQUFNLGFBQVcseUJBQXdCO0FBQUM7QUFBQyxTQUFTLEVBQUUsQ0FBQztJQUFFLE9BQU8sSUFBSSxRQUFRLENBQUE7UUFBSSxTQUFTLGtCQUFpQixDQUFBLE9BQU0sQ0FBQSxTQUFTLGdCQUFnQixZQUFZLElBQUcsR0FBRSxHQUFHLEdBQUUsSUFBRyxXQUFXLGlCQUFpQixvQkFBbUI7WUFBSyxPQUFLLFNBQVMsZ0JBQWdCLFlBQVksSUFBRztRQUFHO0lBQUU7QUFBRTtBQUFDLElBQUksSUFBRTtJQUFLLElBQUk7SUFBRSxJQUFHLEtBQUk7UUFBQyxJQUFJLElBQUU7UUFBSSxJQUFFLEVBQUU7SUFBRTtJQUFDLE9BQU07UUFBQyxNQUFLLE9BQU0sRUFBQyxjQUFhLElBQUUsQ0FBQyxDQUFDLEVBQUMsR0FBQyxDQUFDLENBQUM7WUFBSSxNQUFNO1lBQUUsSUFBSSxJQUFFO1lBQUksRUFBRSxNQUFNLFVBQVEsS0FBSSxLQUFJLENBQUEsRUFBRSxVQUFRLENBQUE7Z0JBQUksRUFBRSxtQkFBa0IsV0FBVyxTQUFTO1lBQVEsR0FBRSxFQUFFLGNBQWMsUUFBUSxVQUFVLE9BQU8sV0FBVSxFQUFFLE1BQU0sU0FBTyxXQUFVLEVBQUUsTUFBTSxnQkFBYyxLQUFJO1FBQUU7UUFBRSxNQUFLO1lBQVUsTUFBTTtZQUFFLElBQUksSUFBRTtZQUFJLEVBQUUsTUFBTSxVQUFRO1FBQUc7SUFBQztBQUFDO0FBQUUsSUFBSSxJQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsT0FBTyxHQUFHLEVBQUUsQ0FBQyxFQUFDLEdBQUUsSUFBRSxDQUFDLEdBQUUsSUFBRTtBQUFJLGVBQWU7SUFBSSxFQUFFLCtCQUE4QixJQUFFLFdBQVcsVUFBVSxhQUFXLEVBQUUsS0FBSztRQUFDLGNBQWEsQ0FBQztJQUFDO0FBQUU7QUFBQyxTQUFTO0lBQUksR0FBRyxjQUFhLElBQUUsR0FBRyxRQUFRLFFBQVE7UUFBQyxNQUFLO0lBQUMsSUFBRyxFQUFFLGFBQWEsWUFBWTtRQUFLO0lBQUcsSUFBRyxFQUFFLFVBQVUsWUFBWSxDQUFBO1FBQUksRUFBRSx3QkFBc0IsS0FBSSxFQUFFLDRCQUEyQixDQUFBLElBQUUsQ0FBQyxDQUFBO0lBQUU7QUFBRTtBQUFDLFNBQVM7SUFBSSxJQUFHLEdBQUcsU0FBUSxJQUFHO1FBQUMsS0FBSSxZQUFZLEdBQUU7SUFBSyxFQUFDLE9BQUs7UUFBQztJQUFNO0FBQUM7QUFBQztBQUFJLEVBQUUsT0FBTTtJQUFJLEVBQUUsdUNBQXNDLEVBQUUsT0FBTyxDQUFBLElBQUcsRUFBRSxZQUFVLEVBQUUsU0FBUyxLQUFLLENBQUEsSUFBRyxFQUFFLE9BQU8sUUFBTyxFQUFFLFFBQU8sQ0FBQSxFQUFFLFFBQU8sR0FBRyxVQUFRLEVBQUUsWUFBWTtRQUFDLHVCQUFzQixDQUFDO0lBQUMsS0FBRyxXQUFXO1FBQUs7SUFBRyxHQUFFLEtBQUk7QUFBRTs7O0FDcEQ3bEQsOENBQThDO0FBRTlDLGdDQUFnQzs7OzRDQUVuQjtBQUFOLE1BQU0sU0FBUztJQUNwQixTQUFTO1FBQUM7S0FBbUQ7QUFFL0Q7QUFFQSxRQUFRLElBQUk7QUFFWixTQUFTO0lBQ1AsT0FBTyxPQUFPO0FBQ2hCO0FBRUEsZUFBZTtJQUNiLFFBQVEsSUFBSTtJQUNaLE1BQU0sT0FBTyxNQUFNLFFBQVEsSUFBSTtJQUMvQixRQUFRLElBQUk7SUFDWixPQUFPO0FBQ1Q7QUFFQSxlQUFlO0lBQ2IsTUFBTSxNQUFNLE1BQU0sUUFBUSxPQUFPO0lBQ2pDLFFBQVEsSUFBSTtJQUNaLGFBQWEsV0FBVztBQUMxQjtBQUVBLGVBQWU7SUFDYixNQUFNLE9BQU8sTUFBTTtJQUNuQixvREFBb0Q7SUFDcEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLFFBQVEsU0FBUyxLQUFLLFdBQVcsR0FBRztRQUN0RCxRQUFRLE1BQU07UUFDZCxPQUFPO0lBQ1Q7SUFFQSxJQUFJLGlCQUFpQixlQUFlLFFBQVE7SUFDNUMsSUFBSSxDQUFDLGdCQUFnQjtRQUNuQixpQkFBaUI7UUFDakIsZUFBZSxRQUFRLGtCQUFrQjtJQUMzQztJQUVBLElBQUksYUFBYSxLQUFLLE1BQU0sYUFBYSxRQUFRLGtCQUFrQixFQUFFO0lBQ3JFLElBQUksbUJBQ0YsS0FBSyxNQUFNLGFBQWEsUUFBUSx1QkFBdUIsRUFBRTtJQUUzRCxJQUFJLFdBQVcsVUFBVSxLQUFLLFFBQVE7UUFDcEMsUUFBUSxNQUFNO1FBQ2QsYUFBYSxRQUFRLG1CQUFtQjtRQUN4QyxhQUFhLFdBQVc7UUFDeEIsZUFBZSxXQUFXO1FBQzFCLE1BQU07UUFFTixhQUFhLFdBQVc7UUFDeEIsT0FBTztRQUNQLE1BQU07SUFFTixlQUFlO0lBQ2pCO0lBRUEsSUFBSSxjQUFjO0lBRWxCLDZCQUE2QjtJQUM3QixJQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLElBQy9CLElBQUksQ0FBQyxXQUFXLFNBQVMsSUFBSTtRQUMzQixjQUFjLElBQUksQ0FBQyxFQUFFO1FBQ3JCLFdBQVcsS0FBSztRQUNoQixpQkFBaUIsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7UUFDOUIsYUFBYSxRQUFRLG1CQUFtQixLQUFLLFVBQVU7UUFDdkQsYUFBYSxRQUFRLGNBQWMsS0FBSyxVQUFVO1FBQ2xELGFBQWEsUUFBUSxnQkFBZ0IsS0FBSyxVQUFVO1FBQ3BELFFBQVEsSUFBSSxxQkFBcUI7UUFDakM7SUFDRjtJQUdGLElBQUksQ0FBQyxhQUFhO1FBQ2hCLFFBQVEsTUFBTTtRQUNkLE9BQU87SUFDVDtJQUVBLFFBQVEsSUFBSSxnQkFBZ0I7SUFDNUIsUUFBUSxJQUFJLGlCQUFpQjtJQUM3QixPQUFPO0FBQ1Q7QUFFQSxlQUFlLG9CQUFvQixTQUFTO0lBQzFDLFdBQVc7UUFDVCxJQUFJLGNBQWMsU0FBUyxjQUN6QjtRQUVGLFFBQVEsSUFBSSxlQUFlO1FBRTNCLElBQUksY0FBYyxZQUFZLGNBQWM7UUFDNUMsUUFBUSxJQUFJLGVBQWU7UUFFM0IsSUFBSSxPQUFPLFlBQVksY0FDckI7UUFFRixRQUFRLElBQUk7UUFFWixJQUFJLFlBQVksS0FBSyxjQUNuQjtRQUVGLFFBQVEsSUFBSTtRQUVaLElBQUksUUFBUSxVQUFVLGNBQWM7UUFDcEMsUUFBUSxJQUFJO1FBRVosSUFBSSxLQUFLLE1BQU0saUJBQWlCO1FBRWhDLEdBQUcsUUFBUSxDQUFDO1lBQ1YsUUFBUSxJQUFJO1lBQ1osSUFBSSxXQUFXLElBQUksaUJBQWlCO1lBQ3BDLFFBQVEsSUFBSSxZQUFZO1lBQ3hCLFNBQVMsUUFBUSxDQUFDO2dCQUNoQixNQUFNLE1BQU0sT0FBTyxjQUFjO2dCQUNqQyxRQUFRLElBQUksS0FBSyxtQ0FBbUM7O2dCQUNwRCxJQUFJLE9BQU8sSUFBSSxZQUFZLFVBQVUsV0FBVztvQkFDOUMsUUFBUSxJQUFJLElBQUk7b0JBRWhCLE9BQU8sY0FBYztvQkFDckIsT0FBTztvQkFDUCxXQUFXO29CQUNYO2dCQUNGO1lBQ0Y7UUFDRjtJQUNGLEdBQUc7QUFDTDtBQUVBLFNBQVMsV0FBVyxJQUFJO0lBQ3RCLElBQUksWUFBWSxLQUFLLGNBQWM7SUFDbkMsUUFBUSxJQUFJLGFBQWE7SUFDekIsSUFBSSxvQkFBb0IsVUFBVSxjQUNoQztJQUVGLFFBQVEsSUFBSSxxQkFBcUI7SUFFakMsZUFBZSxrQkFBa0IsY0FBYztJQUMvQyxRQUFRLElBQUksZ0JBQWdCO0lBRTVCLElBQUksY0FBYyxhQUFhLGlCQUFpQjtJQUVoRCxRQUFRLElBQUksZUFBZTtJQUMzQixZQUFZLFFBQVEsQ0FBQztRQUNuQixJQUFJLE9BQU8sbUJBQW1CLGNBQzVCO1FBRUYsUUFBUSxJQUFJO1FBRVosSUFBSSxRQUFRLEtBQUssY0FBYztRQUMvQixJQUFHLE9BQU87WUFDVixRQUFRLElBQUksU0FBUztZQUNyQixLQUFLO1FBQ0w7SUFDRjtJQUVBLFdBQVc7UUFDVCxJQUFJLE9BQU8sU0FBUyxjQUFjO1FBQ2xDLFFBQVEsSUFBSSxRQUFRO1FBQ3BCLElBQUksU0FBUyxLQUFLLGNBQWM7UUFDaEMsUUFBUSxJQUFJLG1CQUFtQjtRQUMvQixJQUFJLGVBQWUsT0FBTyxjQUFjO1FBQ3hDLElBQUksU0FBUyxhQUFhLGNBQWM7UUFDeEMsUUFBUSxJQUFJO1FBQ1osSUFBSSxRQUNGLElBQUk7WUFDRixPQUFPO1FBQ1AscUJBQXFCO1FBQ3JCLHlDQUF5QztRQUN6QyxtQkFBbUI7UUFDbkIsWUFBWTtRQUNaLDJDQUEyQztRQUM3QyxFQUFFLE9BQU8sT0FBTztZQUNkLFFBQVEsSUFBSTtZQUNaLFFBQVEsTUFBTTtZQUNkLE9BQU87UUFDVDthQUVBLFFBQVEsTUFBTTtJQUVsQixHQUFHO0lBQ0g7QUFDRjtBQUVBLGVBQWUsaUJBQWlCLFNBQVM7SUFDdkMsT0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTO1FBQzNCLElBQUksV0FBVztZQUNiLE1BQU0sV0FBVyxJQUFJLGlCQUFpQixDQUFDLGVBQWU7Z0JBQ3BELEtBQUssSUFBSSxZQUFZLGNBQ25CLElBQUksU0FBUyxTQUFTLGFBQWE7b0JBQ2pDLElBQUksaUJBQWlCLFVBQVUsY0FBYztvQkFDN0MsSUFBSSxnQkFBZ0I7d0JBQ2xCLFFBQVEsSUFBSSwyQkFBMkI7d0JBQ3ZDLDhDQUE4Qzt3QkFDOUMsSUFBSSxZQUFZLFVBQVUsVUFBVTt3QkFDcEMsUUFBUSxJQUFJLGVBQWU7d0JBQzNCLCtEQUErRDt3QkFDL0QsU0FBUzt3QkFDVCwyRUFBMkU7d0JBQzNFLFFBQVEsV0FBVywwQ0FBMEM7O3dCQUM3RDtvQkFDRjtnQkFDRjtZQUVKO1lBRUEsU0FBUyxRQUFRLFdBQVc7Z0JBQzFCLFdBQVc7Z0JBQ1gsU0FBUztZQUNYO1FBQ0YsT0FDRSxPQUFPO0lBRVg7QUFDRjtBQUVBLGVBQWU7SUFDYixpRUFBaUU7SUFFakUseUJBQXlCO0lBQ3pCLGlEQUFpRDtJQUNqRCw4REFBOEQ7SUFDOUQsSUFBSTtJQUVKLHNDQUFzQztJQUN0QyxjQUFjO0lBQ2QsMkRBQTJEO0lBQzNELDZDQUE2QztJQUM3QyxtQkFBbUI7SUFDbkIsSUFBSTtJQUVKLFdBQVc7UUFDVCxRQUFRLElBQUk7UUFFWixJQUFJLE9BQU8sU0FBUyxjQUFjO1FBQ2xDLFFBQVEsSUFBSTtRQUNaLElBQUksT0FBTyxLQUFLLGNBQWM7UUFFOUIsTUFBTSxTQUFTLFNBQVMsY0FBYztRQUN0QyxPQUFPLGNBQWMsQ0FBQzs7Ozs7Ozs7UUFRbEIsQ0FBQztRQUNMLFNBQVMsS0FBSyxZQUFZO1FBRTFCLFFBQVEsSUFBSTtRQUNaLElBQUksVUFBVSxLQUFLLGNBQ2pCO1FBRUYsUUFBUSxJQUFJO1FBQ1osSUFBSSxXQUFXLFFBQVEsY0FBYztRQUNyQyxRQUFRLElBQUk7UUFDWixJQUFJLGdCQUFnQixTQUFTLGNBQWM7UUFDM0MsUUFBUSxJQUFJO1FBQ1osSUFBSSxlQUNGLGNBQWM7UUFLaEIsSUFBSSxhQUFhLEtBQUssY0FDcEI7UUFFRixRQUFRLElBQUk7UUFDWixJQUFJLFlBQ0YsV0FBVztRQUdiLElBQUksZUFBZSxLQUFLLGlCQUFpQjtRQUN6QyxRQUFRLElBQUk7UUFFWixhQUFhLFFBQVEsQ0FBQyxPQUFPO1lBQzNCLFFBQVEsSUFBSTtZQUNaLFFBQVEsSUFBSTtZQUNaLElBQUksU0FBUyxHQUFHO2dCQUNkLElBQUksUUFBUSxNQUFNLGNBQWM7Z0JBQ2hDLElBQUksZ0JBQWdCLE1BQU0sY0FBYztnQkFDeEMsUUFBUSxJQUFJO2dCQUNaLFFBQVEsSUFBSTtnQkFDWixJQUFJLFNBQVMsTUFBTSxpQkFBaUI7Z0JBQ3BDLElBQUksVUFBVSxjQUFjLGlCQUFpQjtnQkFDN0MsT0FBTyxRQUFRLENBQUMsT0FBTztvQkFDckIsSUFBSSxPQUFPO3dCQUNULFFBQVEsSUFBSSxNQUFNO3dCQUNsQixJQUFJLE1BQU0sVUFBVSxTQUFTLGdCQUFnQjs0QkFDM0MsSUFBSSxRQUFRLE1BQU0sY0FBYzs0QkFFaEMsUUFBUSxJQUFJOzRCQUNaLE1BQU0sUUFBUTs0QkFDZCxrQkFBa0I7NEJBQ2xCLE1BQU0sY0FBYyxJQUFJLE1BQU0sU0FBUztnQ0FBRSxTQUFTOzRCQUFLOzRCQUN2RCxNQUFNLGNBQWMsSUFBSSxNQUFNLFVBQVU7Z0NBQUUsU0FBUzs0QkFBSzt3QkFDMUQsT0FBTyxJQUFJLE1BQU0sVUFBVSxTQUFTLGVBQWU7NEJBQ2pELElBQUksUUFBUSxNQUFNLGNBQWM7NEJBRWhDLFFBQVEsSUFBSTs0QkFDWixNQUFNLFFBQVE7NEJBQ2QsaUJBQWlCOzRCQUNqQixNQUFNLGNBQWMsSUFBSSxNQUFNLFNBQVM7Z0NBQUUsU0FBUzs0QkFBSzs0QkFDdkQsTUFBTSxjQUFjLElBQUksTUFBTSxVQUFVO2dDQUFFLFNBQVM7NEJBQUs7d0JBQzFEO29CQUNGO2dCQUNGO2dCQUVBLFFBQVEsUUFBUSxDQUFDLE9BQU87b0JBQ3RCLElBQUksT0FBTzt3QkFDVCxRQUFRLElBQUksTUFBTTt3QkFDbEIsSUFBSSxNQUFNLFVBQVUsU0FBUyxxQkFBcUI7NEJBQ2hELElBQUksUUFBUSxNQUFNLGNBQWM7NEJBRWhDLFFBQVEsSUFBSTs0QkFDWixNQUFNLFFBQVE7NEJBQ2QsdUJBQXVCOzRCQUN2QixNQUFNLGNBQWMsSUFBSSxNQUFNLFNBQVM7Z0NBQUUsU0FBUzs0QkFBSzs0QkFDdkQsTUFBTSxjQUFjLElBQUksTUFBTSxVQUFVO2dDQUFFLFNBQVM7NEJBQUs7d0JBQzFELE9BQU8sSUFBSSxNQUFNLFVBQVUsU0FBUyxzQkFBc0I7NEJBQ3hELElBQUksUUFBUSxNQUFNLGNBQWM7NEJBRWhDLFFBQVEsSUFBSTs0QkFDWixNQUFNLFFBQVE7NEJBQ2QseUJBQXlCOzRCQUN6QixNQUFNLGNBQWMsSUFBSSxNQUFNLFNBQVM7Z0NBQUUsU0FBUzs0QkFBSzs0QkFDdkQsTUFBTSxjQUFjLElBQUksTUFBTSxVQUFVO2dDQUFFLFNBQVM7NEJBQUs7d0JBQzFEO29CQUNGO2dCQUNGO1lBQ0Y7WUFFQSxJQUFJLFNBQVMsR0FBRztnQkFDZCxRQUFRLElBQUk7Z0JBQ1osSUFBSSxTQUFTLE1BQU0saUJBQWlCO2dCQUNwQyxPQUFPLFFBQVEsQ0FBQyxPQUFPO29CQUNyQixJQUFJLE9BQU87d0JBQ1QsUUFBUSxJQUFJLE1BQU07d0JBQ2xCLElBQUksTUFBTSxVQUFVLFNBQVMsV0FBVzs0QkFDdEMsSUFBSSxRQUFRLE1BQU0sY0FBYzs0QkFFaEMsUUFBUSxJQUFJOzRCQUNaLE1BQU0sUUFBUTs0QkFDZCxjQUFjOzRCQUNkLE1BQU0sY0FBYyxJQUFJLE1BQU0sU0FBUztnQ0FBRSxTQUFTOzRCQUFLOzRCQUN2RCxNQUFNLGNBQWMsSUFBSSxNQUFNLFVBQVU7Z0NBQUUsU0FBUzs0QkFBSzt3QkFDMUQsT0FBTyxJQUFJLE1BQU0sVUFBVSxTQUFTLFdBQVc7NEJBQzdDLElBQUksUUFBUSxNQUFNLGNBQWM7NEJBRWhDLFFBQVEsSUFBSTs0QkFDWixNQUFNLFFBQVE7NEJBQ2QsY0FBYzs0QkFDZCxNQUFNLGNBQWMsSUFBSSxNQUFNLFNBQVM7Z0NBQUUsU0FBUzs0QkFBSzs0QkFDdkQsTUFBTSxjQUFjLElBQUksTUFBTSxVQUFVO2dDQUFFLFNBQVM7NEJBQUs7d0JBQzFEO29CQUNGO2dCQUNGO1lBQ0Y7WUFFQSxJQUFJLFNBQVMsR0FBRztnQkFDZCxJQUFJLGdCQUFnQixNQUFNLGNBQ3hCO2dCQUVGLFFBQVEsSUFBSTtnQkFFWixJQUFJLFNBQVMsY0FBYyxpQkFBaUI7Z0JBQzVDLFFBQVEsSUFBSTtnQkFFWixPQUFPLFFBQVEsQ0FBQyxPQUFPO29CQUNyQixJQUFJLFNBQVMsR0FBRzt3QkFDZCxJQUFJLFdBQVcsTUFBTSxjQUFjO3dCQUNuQyxJQUFJLFNBQVMsU0FBUyxjQUNwQjt3QkFFRixRQUFRLElBQUk7d0JBQ1osSUFBSSxRQUFRLE9BQU8sY0FBYzt3QkFDakMsUUFBUSxJQUFJO3dCQUNaLDRDQUE0Qzt3QkFDNUMscUJBQXFCO3dCQUNyQixNQUFNLFFBQVE7d0JBQ2QsTUFBTTt3QkFFTixNQUFNLGNBQWMsSUFBSSxNQUFNLFNBQVM7NEJBQUUsU0FBUzt3QkFBSzt3QkFDdkQsTUFBTSxjQUFjLElBQUksTUFBTSxVQUFVOzRCQUFFLFNBQVM7d0JBQUs7d0JBRXhELElBQUksYUFBYSxJQUFJLGNBQWMsV0FBVzs0QkFDNUMsU0FBUzs0QkFDVCxZQUFZOzRCQUNaLEtBQUs7NEJBQ0wsU0FBUzt3QkFDWDt3QkFDQSxNQUFNLGNBQWM7b0JBQ3RCLE9BQU8sSUFBSSxTQUFTLEdBQUc7d0JBQ3JCLElBQUksY0FBYyxNQUFNLGNBQ3RCO3dCQUVGLFFBQVEsSUFBSTt3QkFFWixJQUFJLGNBQWMsWUFBWSxjQUFjO3dCQUM1QyxRQUFRLElBQUksZUFBZTt3QkFDM0IsSUFBSSxRQUFRLFlBQVksY0FDdEI7d0JBRUYsUUFBUSxJQUFJLFNBQVM7d0JBQ3JCLE1BQU07d0JBRU4scUNBQXFDO3dCQUVyQyxJQUFJLGdCQUFnQixTQUFTLGNBQWM7d0JBQzNDLFFBQVEsSUFBSTt3QkFDWixJQUFJLFlBQVksY0FBYyxjQUM1Qjt3QkFFRixRQUFRLElBQUk7d0JBQ1osSUFBSSxPQUFPLFVBQVUsY0FDbkI7d0JBRUYsUUFBUSxJQUFJO3dCQUNaLHlCQUF5Qjt3QkFDekIsSUFBSSxRQUFRLEtBQUssaUJBQWlCO3dCQUNsQyxRQUFRLElBQUksU0FBUzt3QkFDckIsTUFBTSxRQUFRLENBQUM7NEJBQ2IsMkJBQTJCOzRCQUMzQixJQUFJLGVBQWUsUUFBUSxpQkFDekI7NEJBRUYsUUFBUSxJQUFJLGdCQUFnQjs0QkFDNUIsYUFBYSxRQUFRLENBQUM7Z0NBQ3BCLElBQUksWUFBWSxTQUFTLGNBQ3ZCO2dDQUVGLFFBQVEsSUFBSTtnQ0FDWixJQUFJLGFBQWEsTUFBTSwwREFBMEQ7O2dDQUVqRixpQkFBaUIsV0FDZCxLQUFLLE9BQU87b0NBQ1gsc0NBQXNDO29DQUN0QyxRQUFRLElBQUk7b0NBQ1osUUFBUSxJQUFJO29DQUNaLGFBQWE7b0NBQ2IsTUFBTSxvQkFBb0I7b0NBRTFCO2dDQUNGLEdBQ0MsTUFBTSxDQUFDO29DQUNOLFFBQVEsTUFBTTtnQ0FDaEI7Z0NBRUYsUUFBUSxJQUFJOzRCQUNaLG1CQUFtQjs0QkFDbkIsMkNBQTJDOzRCQUMzQyxxQ0FBcUM7NEJBQ3JDLDhDQUE4Qzs0QkFDOUMsaUNBQWlDOzRCQUNqQywrQ0FBK0M7NEJBQy9DLGlDQUFpQzs0QkFDakMsa0RBQWtEOzRCQUNsRCxrQ0FBa0M7NEJBQ2xDLDJCQUEyQjs0QkFDM0IsMkNBQTJDOzRCQUMzQywrQkFBK0I7NEJBQy9CLGdCQUFnQjs0QkFDaEIsNkRBQTZEOzRCQUM3RCx5REFBeUQ7NEJBQ3pELG9EQUFvRDs0QkFDcEQsOEVBQThFOzRCQUM5RSxvQ0FBb0M7NEJBQ3BDLHNGQUFzRjs0QkFDdEYsd0JBQXdCOzRCQUN4QixnRUFBZ0U7NEJBQ2hFLG9DQUFvQzs0QkFDcEMsd0NBQXdDOzRCQUN4QyxrQ0FBa0M7NEJBQ2xDLGdEQUFnRDs0QkFDaEQsb0RBQW9EOzRCQUNwRCwrQkFBK0I7NEJBQy9CLHFDQUFxQzs0QkFDckMsdUNBQXVDOzRCQUN2QyxpRUFBaUU7NEJBRWpFLDZDQUE2Qzs0QkFDN0Msc0NBQXNDOzRCQUN0QyxtQ0FBbUM7NEJBRW5DLDhCQUE4Qjs0QkFDOUIsaUZBQWlGOzRCQUNqRixxQ0FBcUM7NEJBQ3JDLCtEQUErRDs0QkFDL0QscUNBQXFDOzRCQUNyQywrQkFBK0I7NEJBQy9CLHlCQUF5Qjs0QkFDekIsb0NBQW9DOzRCQUNwQyx3Q0FBd0M7NEJBQ3hDLHlEQUF5RDs0QkFDekQsc0NBQXNDOzRCQUN0QywrQkFBK0I7NEJBQy9CLGlFQUFpRTs0QkFDakUscUNBQXFDOzRCQUNyQyxzREFBc0Q7NEJBQ3RELDBDQUEwQzs0QkFDMUMsb0NBQW9DOzRCQUNwQyxxQkFBcUI7NEJBQ3JCLDBCQUEwQjs0QkFDMUIsa0NBQWtDOzRCQUNsQyw0REFBNEQ7NEJBQzVELHFCQUFxQjs0QkFDckIsbUJBQW1COzRCQUNuQixzRUFBc0U7NEJBRXRFLHFCQUFxQjs0QkFDckIsY0FBYzs0QkFDZCxZQUFZOzRCQUNaLFVBQVU7NEJBQ1YsUUFBUTs0QkFDUixNQUFNOzRCQUVOLGtDQUFrQzs0QkFDbEMsdUJBQXVCOzRCQUN2QixvQkFBb0I7NEJBQ3BCLE9BQU87NEJBQ1AsSUFBSTs0QkFFSix5QkFBeUI7NEJBQzNCO3dCQUNGO29CQUNGO2dCQUNGO1lBQ0Y7UUFDRjtRQUVBLFFBQVEsSUFBSTtJQUNkLEdBQUc7QUFDTDtBQUVBLE9BQU8saUJBQWlCLFFBQVE7SUFDOUIsSUFBSSxnQkFBZ0I7SUFDcEI7SUFDQSxZQUFZO1FBQ1YsSUFBSSxlQUNGLE9BQU8sU0FBUyxPQUFPLE9BQU8sU0FBUztJQUUzQyxHQUFHO0FBQ0w7OztBQ2ppQkEsUUFBUSxpQkFBaUIsU0FBVSxDQUFDO0lBQ2xDLE9BQU8sS0FBSyxFQUFFLGFBQWEsSUFBSTtRQUFDLFNBQVM7SUFBQztBQUM1QztBQUVBLFFBQVEsb0JBQW9CLFNBQVUsQ0FBQztJQUNyQyxPQUFPLGVBQWUsR0FBRyxjQUFjO1FBQUMsT0FBTztJQUFJO0FBQ3JEO0FBRUEsUUFBUSxZQUFZLFNBQVUsTUFBTSxFQUFFLElBQUk7SUFDeEMsT0FBTyxLQUFLLFFBQVEsUUFBUSxTQUFVLEdBQUc7UUFDdkMsSUFBSSxRQUFRLGFBQWEsUUFBUSxnQkFBZ0IsS0FBSyxlQUFlLE1BQ25FO1FBR0YsT0FBTyxlQUFlLE1BQU0sS0FBSztZQUMvQixZQUFZO1lBQ1osS0FBSztnQkFDSCxPQUFPLE1BQU0sQ0FBQyxJQUFJO1lBQ3BCO1FBQ0Y7SUFDRjtJQUVBLE9BQU87QUFDVDtBQUVBLFFBQVEsU0FBUyxTQUFVLElBQUksRUFBRSxRQUFRLEVBQUUsR0FBRztJQUM1QyxPQUFPLGVBQWUsTUFBTSxVQUFVO1FBQ3BDLFlBQVk7UUFDWixLQUFLO0lBQ1A7QUFDRiIsInNvdXJjZXMiOlsibm9kZV9tb2R1bGVzLy5wbnBtL0BwbGFzbW9ocStwYXJjZWwtcnVudGltZUAwLjI1LjAvbm9kZV9tb2R1bGVzL0BwbGFzbW9ocS9wYXJjZWwtcnVudGltZS9kaXN0L3J1bnRpbWUtMjI4N2RjYjI5ZDBhM2U5MC5qcyIsImNvbnRlbnRzL2Zvcm1maWxsLmpzIiwibm9kZV9tb2R1bGVzLy5wbnBtL0BwYXJjZWwrdHJhbnNmb3JtZXItanNAMi45LjNfQHBhcmNlbCtjb3JlQDIuOS4zL25vZGVfbW9kdWxlcy9AcGFyY2VsL3RyYW5zZm9ybWVyLWpzL3NyYy9lc21vZHVsZS1oZWxwZXJzLmpzIl0sInNvdXJjZXNDb250ZW50IjpbInZhciBkPXR5cGVvZiBnbG9iYWxUaGlzLnByb2Nlc3M8XCJ1XCI/Z2xvYmFsVGhpcy5wcm9jZXNzLmFyZ3Y6W107dmFyIHk9KCk9PnR5cGVvZiBnbG9iYWxUaGlzLnByb2Nlc3M8XCJ1XCI/Z2xvYmFsVGhpcy5wcm9jZXNzLmVudjp7fTt2YXIgSD1uZXcgU2V0KGQpLF89ZT0+SC5oYXMoZSksRz1kLmZpbHRlcihlPT5lLnN0YXJ0c1dpdGgoXCItLVwiKSYmZS5pbmNsdWRlcyhcIj1cIikpLm1hcChlPT5lLnNwbGl0KFwiPVwiKSkucmVkdWNlKChlLFt0LG9dKT0+KGVbdF09byxlKSx7fSk7dmFyIFo9XyhcIi0tZHJ5LXJ1blwiKSxwPSgpPT5fKFwiLS12ZXJib3NlXCIpfHx5KCkuVkVSQk9TRT09PVwidHJ1ZVwiLHE9cCgpO3ZhciB1PShlPVwiXCIsLi4udCk9PmNvbnNvbGUubG9nKGUucGFkRW5kKDkpLFwifFwiLC4uLnQpO3ZhciB4PSguLi5lKT0+Y29uc29sZS5lcnJvcihcIlxcdXsxRjUzNH0gRVJST1JcIi5wYWRFbmQoOSksXCJ8XCIsLi4uZSksYj0oLi4uZSk9PnUoXCJcXHV7MUY1MzV9IElORk9cIiwuLi5lKSxtPSguLi5lKT0+dShcIlxcdXsxRjdFMH0gV0FSTlwiLC4uLmUpLFM9MCxjPSguLi5lKT0+cCgpJiZ1KGBcXHV7MUY3RTF9ICR7UysrfWAsLi4uZSk7dmFyIHM9e1wiaXNDb250ZW50U2NyaXB0XCI6dHJ1ZSxcImlzQmFja2dyb3VuZFwiOmZhbHNlLFwiaXNSZWFjdFwiOmZhbHNlLFwicnVudGltZXNcIjpbXCJzY3JpcHQtcnVudGltZVwiXSxcImhvc3RcIjpcImxvY2FsaG9zdFwiLFwicG9ydFwiOjE4MTUsXCJlbnRyeUZpbGVQYXRoXCI6XCJDOlxcXFxVc2Vyc1xcXFxzaGlyaXNpXFxcXERlc2t0b3BcXFxcZXh0ZW5zaW9uXFxcXGVtYmFzc3ktb2YtbW9sZG92YVxcXFxjb250ZW50c1xcXFxmb3JtZmlsbC5qc1wiLFwiYnVuZGxlSWRcIjpcImJhYmU5ZGQ4ZTRlODIyZTNcIixcImVudkhhc2hcIjpcImQ5OWE1ZmZhNTdhY2Q2MzhcIixcInZlcmJvc2VcIjpcImZhbHNlXCIsXCJzZWN1cmVcIjpmYWxzZSxcInNlcnZlclBvcnRcIjoxMDEyfTttb2R1bGUuYnVuZGxlLkhNUl9CVU5ETEVfSUQ9cy5idW5kbGVJZDtnbG9iYWxUaGlzLnByb2Nlc3M9e2FyZ3Y6W10sZW52OntWRVJCT1NFOnMudmVyYm9zZX19O3ZhciBEPW1vZHVsZS5idW5kbGUuTW9kdWxlO2Z1bmN0aW9uIEkoZSl7RC5jYWxsKHRoaXMsZSksdGhpcy5ob3Q9e2RhdGE6bW9kdWxlLmJ1bmRsZS5ob3REYXRhW2VdLF9hY2NlcHRDYWxsYmFja3M6W10sX2Rpc3Bvc2VDYWxsYmFja3M6W10sYWNjZXB0OmZ1bmN0aW9uKHQpe3RoaXMuX2FjY2VwdENhbGxiYWNrcy5wdXNoKHR8fGZ1bmN0aW9uKCl7fSl9LGRpc3Bvc2U6ZnVuY3Rpb24odCl7dGhpcy5fZGlzcG9zZUNhbGxiYWNrcy5wdXNoKHQpfX0sbW9kdWxlLmJ1bmRsZS5ob3REYXRhW2VdPXZvaWQgMH1tb2R1bGUuYnVuZGxlLk1vZHVsZT1JO21vZHVsZS5idW5kbGUuaG90RGF0YT17fTt2YXIgbD1nbG9iYWxUaGlzLmJyb3dzZXJ8fGdsb2JhbFRoaXMuY2hyb21lfHxudWxsO2Z1bmN0aW9uIHYoKXtyZXR1cm4hcy5ob3N0fHxzLmhvc3Q9PT1cIjAuMC4wLjBcIj9cImxvY2FsaG9zdFwiOnMuaG9zdH1mdW5jdGlvbiBDKCl7cmV0dXJuIHMucG9ydHx8bG9jYXRpb24ucG9ydH12YXIgRT1cIl9fcGxhc21vX3J1bnRpbWVfc2NyaXB0X1wiO2Z1bmN0aW9uIEwoZSx0KXtsZXR7bW9kdWxlczpvfT1lO3JldHVybiBvPyEhb1t0XTohMX1mdW5jdGlvbiBPKGU9QygpKXtsZXQgdD12KCk7cmV0dXJuYCR7cy5zZWN1cmV8fGxvY2F0aW9uLnByb3RvY29sPT09XCJodHRwczpcIiYmIS9sb2NhbGhvc3R8MTI3LjAuMC4xfDAuMC4wLjAvLnRlc3QodCk/XCJ3c3NcIjpcIndzXCJ9Oi8vJHt0fToke2V9L2B9ZnVuY3Rpb24gQihlKXt0eXBlb2YgZS5tZXNzYWdlPT1cInN0cmluZ1wiJiZ4KFwiW3BsYXNtby9wYXJjZWwtcnVudGltZV06IFwiK2UubWVzc2FnZSl9ZnVuY3Rpb24gVChlKXtpZih0eXBlb2YgZ2xvYmFsVGhpcy5XZWJTb2NrZXQ+XCJ1XCIpcmV0dXJuO2xldCB0PW5ldyBXZWJTb2NrZXQoTygpKTtyZXR1cm4gdC5hZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLGFzeW5jIGZ1bmN0aW9uKG8pe2xldCByPUpTT04ucGFyc2Uoby5kYXRhKTtpZihyLnR5cGU9PT1cInVwZGF0ZVwiJiZhd2FpdCBlKHIuYXNzZXRzKSxyLnR5cGU9PT1cImVycm9yXCIpZm9yKGxldCBhIG9mIHIuZGlhZ25vc3RpY3MuYW5zaSl7bGV0IHc9YS5jb2RlZnJhbWV8fGEuc3RhY2s7bShcIltwbGFzbW8vcGFyY2VsLXJ1bnRpbWVdOiBcIithLm1lc3NhZ2UrYFxuYCt3K2BcblxuYCthLmhpbnRzLmpvaW4oYFxuYCkpfX0pLHQuYWRkRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsQiksdC5hZGRFdmVudExpc3RlbmVyKFwib3BlblwiLCgpPT57YihgW3BsYXNtby9wYXJjZWwtcnVudGltZV06IENvbm5lY3RlZCB0byBITVIgc2VydmVyIGZvciAke3MuZW50cnlGaWxlUGF0aH1gKX0pLHQuYWRkRXZlbnRMaXN0ZW5lcihcImNsb3NlXCIsKCk9PnttKGBbcGxhc21vL3BhcmNlbC1ydW50aW1lXTogQ29ubmVjdGlvbiB0byB0aGUgSE1SIHNlcnZlciBpcyBjbG9zZWQgZm9yICR7cy5lbnRyeUZpbGVQYXRofWApfSksdH12YXIgbj1cIl9fcGxhc21vLWxvYWRpbmdfX1wiO2Z1bmN0aW9uICQoKXtsZXQgZT1nbG9iYWxUaGlzLndpbmRvdz8udHJ1c3RlZFR5cGVzO2lmKHR5cGVvZiBlPlwidVwiKXJldHVybjtsZXQgdD1kb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdtZXRhW25hbWU9XCJ0cnVzdGVkLXR5cGVzXCJdJyk/LmNvbnRlbnQ/LnNwbGl0KFwiIFwiKSxvPXQ/dFt0Py5sZW5ndGgtMV06dm9pZCAwO3JldHVybiB0eXBlb2YgZTxcInVcIj9lLmNyZWF0ZVBvbGljeShvfHxgdHJ1c3RlZC1odG1sLSR7bn1gLHtjcmVhdGVIVE1MOmE9PmF9KTp2b2lkIDB9dmFyIFA9JCgpO2Z1bmN0aW9uIGcoKXtyZXR1cm4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQobil9ZnVuY3Rpb24gZigpe3JldHVybiFnKCl9ZnVuY3Rpb24gRigpe2xldCBlPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7ZS5pZD1uO2xldCB0PWBcbiAgPHN0eWxlPlxuICAgICMke259IHtcbiAgICAgIGJhY2tncm91bmQ6ICNmM2YzZjM7XG4gICAgICBjb2xvcjogIzMzMztcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkICMzMzM7XG4gICAgICBib3gtc2hhZG93OiAjMzMzIDQuN3B4IDQuN3B4O1xuICAgIH1cblxuICAgICMke259OmhvdmVyIHtcbiAgICAgIGJhY2tncm91bmQ6ICNlM2UzZTM7XG4gICAgICBjb2xvcjogIzQ0NDtcbiAgICB9XG5cbiAgICBAa2V5ZnJhbWVzIHBsYXNtby1sb2FkaW5nLWFuaW1hdGUtc3ZnLWZpbGwge1xuICAgICAgMCUge1xuICAgICAgICBmaWxsOiB0cmFuc3BhcmVudDtcbiAgICAgIH1cbiAgICBcbiAgICAgIDEwMCUge1xuICAgICAgICBmaWxsOiAjMzMzO1xuICAgICAgfVxuICAgIH1cblxuICAgICMke259IC5zdmctZWxlbS0xIHtcbiAgICAgIGFuaW1hdGlvbjogcGxhc21vLWxvYWRpbmctYW5pbWF0ZS1zdmctZmlsbCAxLjQ3cyBjdWJpYy1iZXppZXIoMC40NywgMCwgMC43NDUsIDAuNzE1KSAwLjhzIGJvdGggaW5maW5pdGU7XG4gICAgfVxuXG4gICAgIyR7bn0gLnN2Zy1lbGVtLTIge1xuICAgICAgYW5pbWF0aW9uOiBwbGFzbW8tbG9hZGluZy1hbmltYXRlLXN2Zy1maWxsIDEuNDdzIGN1YmljLWJlemllcigwLjQ3LCAwLCAwLjc0NSwgMC43MTUpIDAuOXMgYm90aCBpbmZpbml0ZTtcbiAgICB9XG4gICAgXG4gICAgIyR7bn0gLnN2Zy1lbGVtLTMge1xuICAgICAgYW5pbWF0aW9uOiBwbGFzbW8tbG9hZGluZy1hbmltYXRlLXN2Zy1maWxsIDEuNDdzIGN1YmljLWJlemllcigwLjQ3LCAwLCAwLjc0NSwgMC43MTUpIDFzIGJvdGggaW5maW5pdGU7XG4gICAgfVxuXG4gICAgIyR7bn0gLmhpZGRlbiB7XG4gICAgICBkaXNwbGF5OiBub25lO1xuICAgIH1cblxuICA8L3N0eWxlPlxuICBcbiAgPHN2ZyBoZWlnaHQ9XCIzMlwiIHdpZHRoPVwiMzJcIiB2aWV3Qm94PVwiMCAwIDI2NCAzNTRcIiBmaWxsPVwibm9uZVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICA8cGF0aCBkPVwiTTEzOS4yMjEgMjgyLjI0M0MxNTQuMjUyIDI4Mi4yNDMgMTY2LjkwMyAyOTQuODQ5IDE2MS4zMzggMzA4LjgxMkMxNTkuNDg5IDMxMy40NTQgMTU3LjE1IDMxNy45MTMgMTU0LjM0NyAzMjIuMTA5QzE0Ni40NjQgMzMzLjkwOSAxMzUuMjYgMzQzLjEwNyAxMjIuMTUxIDM0OC41MzhDMTA5LjA0MyAzNTMuOTY5IDk0LjYxODIgMzU1LjM5IDgwLjcwMjIgMzUyLjYyMUM2Ni43ODYxIDM0OS44NTIgNTQuMDAzNCAzNDMuMDE4IDQzLjk3MDUgMzMyLjk4M0MzMy45Mzc1IDMyMi45NDcgMjcuMTA1IDMxMC4xNjIgMjQuMzM2OSAyOTYuMjQyQzIxLjU2ODkgMjgyLjMyMyAyMi45ODk1IDI2Ny44OTUgMjguNDE5MyAyNTQuNzgzQzMzLjg0OTEgMjQxLjY3MSA0My4wNDQxIDIzMC40NjQgNTQuODQxNiAyMjIuNTc5QzU5LjAzNTMgMjE5Ljc3NyA2My40OTA4IDIxNy40MzggNjguMTI5NSAyMTUuNTg4QzgyLjA5MTUgMjEwLjAyMSA5NC42OTc4IDIyMi42NzEgOTQuNjk3OCAyMzcuNzAzTDk0LjY5NzggMjU1LjAyN0M5NC42OTc4IDI3MC4wNTggMTA2Ljg4MyAyODIuMjQzIDEyMS45MTQgMjgyLjI0M0gxMzkuMjIxWlwiIGZpbGw9XCIjMzMzXCIgY2xhc3M9XCJzdmctZWxlbS0xXCIgPjwvcGF0aD5cbiAgICA8cGF0aCBkPVwiTTE5Mi4yNjEgMTQyLjAyOEMxOTIuMjYxIDEyNi45OTYgMjA0Ljg2NyAxMTQuMzQ2IDIxOC44MjkgMTE5LjkxM0MyMjMuNDY4IDEyMS43NjMgMjI3LjkyMyAxMjQuMTAyIDIzMi4xMTcgMTI2LjkwNEMyNDMuOTE1IDEzNC43ODkgMjUzLjExIDE0NS45OTYgMjU4LjUzOSAxNTkuMTA4QzI2My45NjkgMTcyLjIyIDI2NS4zOSAxODYuNjQ4IDI2Mi42MjIgMjAwLjU2N0MyNTkuODU0IDIxNC40ODcgMjUzLjAyMSAyMjcuMjcyIDI0Mi45ODggMjM3LjMwOEMyMzIuOTU1IDI0Ny4zNDMgMjIwLjE3MyAyNTQuMTc3IDIwNi4yNTYgMjU2Ljk0NkMxOTIuMzQgMjU5LjcxNSAxNzcuOTE2IDI1OC4yOTQgMTY0LjgwNyAyNTIuODYzQzE1MS42OTkgMjQ3LjQzMiAxNDAuNDk1IDIzOC4yMzQgMTMyLjYxMiAyMjYuNDM0QzEyOS44MDggMjIyLjIzOCAxMjcuNDcgMjE3Ljc3OSAxMjUuNjIgMjEzLjEzN0MxMjAuMDU2IDE5OS4xNzQgMTMyLjcwNyAxODYuNTY4IDE0Ny43MzggMTg2LjU2OEwxNjUuMDQ0IDE4Ni41NjhDMTgwLjA3NiAxODYuNTY4IDE5Mi4yNjEgMTc0LjM4MyAxOTIuMjYxIDE1OS4zNTJMMTkyLjI2MSAxNDIuMDI4WlwiIGZpbGw9XCIjMzMzXCIgY2xhc3M9XCJzdmctZWxlbS0yXCIgPjwvcGF0aD5cbiAgICA8cGF0aCBkPVwiTTk1LjY1MjIgMTY0LjEzNUM5NS42NTIyIDE3OS4xNjcgODMuMjI3OSAxOTEuNzI1IDY4LjgwMTMgMTg3LjUwNUM1OS41MTQ1IDE4NC43ODggNTAuNjQzMiAxODAuNjYzIDQyLjUxMDYgMTc1LjIyN0MyNi43ODA2IDE2NC43MTQgMTQuNTIwNiAxNDkuNzcyIDcuMjgwODkgMTMyLjI4OUMwLjA0MTE4MyAxMTQuODA3IC0xLjg1MzA1IDk1LjU2OTcgMS44Mzc3MiA3Ny4wMTA0QzUuNTI4NDkgNTguNDUxMSAxNC42Mzg1IDQxLjQwMzMgMjguMDE1NyAyOC4wMjI4QzQxLjM5MyAxNC42NDIzIDU4LjQzNjYgNS41MzAwNiA3Ni45OTE0IDEuODM4MzlDOTUuNTQ2MSAtMS44NTMyOSAxMTQuNzc5IDAuMDQxNDE2MiAxMzIuMjU3IDcuMjgyOUMxNDkuNzM1IDE0LjUyNDQgMTY0LjY3NCAyNi43ODc0IDE3NS4xODQgNDIuNTIxMkMxODAuNjIgNTAuNjU3NiAxODQuNzQ0IDU5LjUzMzIgMTg3LjQ2IDY4LjgyNDVDMTkxLjY3OCA4My4yNTE5IDE3OS4xMTkgOTUuNjc1OSAxNjQuMDg4IDk1LjY3NTlMMTIyLjg2OSA5NS42NzU5QzEwNy44MzcgOTUuNjc1OSA5NS42NTIyIDEwNy44NjEgOTUuNjUyMiAxMjIuODkyTDk1LjY1MjIgMTY0LjEzNVpcIiBmaWxsPVwiIzMzM1wiIGNsYXNzPVwic3ZnLWVsZW0tM1wiPjwvcGF0aD5cbiAgPC9zdmc+XG4gIDxzcGFuIGNsYXNzPVwiaGlkZGVuXCI+Q29udGV4dCBJbnZhbGlkYXRlZCwgUHJlc3MgdG8gUmVsb2FkPC9zcGFuPlxuICBgO3JldHVybiBlLmlubmVySFRNTD1QP1AuY3JlYXRlSFRNTCh0KTp0LGUuc3R5bGUucG9pbnRlckV2ZW50cz1cIm5vbmVcIixlLnN0eWxlLnBvc2l0aW9uPVwiZml4ZWRcIixlLnN0eWxlLmJvdHRvbT1cIjE0LjdweFwiLGUuc3R5bGUucmlnaHQ9XCIxNC43cHhcIixlLnN0eWxlLmZvbnRGYW1pbHk9XCJzYW5zLXNlcmlmXCIsZS5zdHlsZS5kaXNwbGF5PVwiZmxleFwiLGUuc3R5bGUuanVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIixlLnN0eWxlLmFsaWduSXRlbXM9XCJjZW50ZXJcIixlLnN0eWxlLnBhZGRpbmc9XCIxNC43cHhcIixlLnN0eWxlLmdhcD1cIjE0LjdweFwiLGUuc3R5bGUuYm9yZGVyUmFkaXVzPVwiNC43cHhcIixlLnN0eWxlLnpJbmRleD1cIjIxNDc0ODM2NDdcIixlLnN0eWxlLm9wYWNpdHk9XCIwXCIsZS5zdHlsZS50cmFuc2l0aW9uPVwiYWxsIDAuNDdzIGVhc2UtaW4tb3V0XCIsZX1mdW5jdGlvbiBOKGUpe3JldHVybiBuZXcgUHJvbWlzZSh0PT57ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50PyhmKCkmJihkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuYXBwZW5kQ2hpbGQoZSksdCgpKSx0KCkpOmdsb2JhbFRoaXMuYWRkRXZlbnRMaXN0ZW5lcihcIkRPTUNvbnRlbnRMb2FkZWRcIiwoKT0+e2YoKSYmZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmFwcGVuZENoaWxkKGUpLHQoKX0pfSl9dmFyIGs9KCk9PntsZXQgZTtpZihmKCkpe2xldCB0PUYoKTtlPU4odCl9cmV0dXJue3Nob3c6YXN5bmMoe3JlbG9hZEJ1dHRvbjp0PSExfT17fSk9Pnthd2FpdCBlO2xldCBvPWcoKTtvLnN0eWxlLm9wYWNpdHk9XCIxXCIsdCYmKG8ub25jbGljaz1yPT57ci5zdG9wUHJvcGFnYXRpb24oKSxnbG9iYWxUaGlzLmxvY2F0aW9uLnJlbG9hZCgpfSxvLnF1ZXJ5U2VsZWN0b3IoXCJzcGFuXCIpLmNsYXNzTGlzdC5yZW1vdmUoXCJoaWRkZW5cIiksby5zdHlsZS5jdXJzb3I9XCJwb2ludGVyXCIsby5zdHlsZS5wb2ludGVyRXZlbnRzPVwiYWxsXCIpfSxoaWRlOmFzeW5jKCk9Pnthd2FpdCBlO2xldCB0PWcoKTt0LnN0eWxlLm9wYWNpdHk9XCIwXCJ9fX07dmFyIFc9YCR7RX0ke21vZHVsZS5pZH1fX2AsaSxBPSExLE09aygpO2FzeW5jIGZ1bmN0aW9uIGgoKXtjKFwiU2NyaXB0IFJ1bnRpbWUgLSByZWxvYWRpbmdcIiksQT9nbG9iYWxUaGlzLmxvY2F0aW9uPy5yZWxvYWQ/LigpOk0uc2hvdyh7cmVsb2FkQnV0dG9uOiEwfSl9ZnVuY3Rpb24gUigpe2k/LmRpc2Nvbm5lY3QoKSxpPWw/LnJ1bnRpbWUuY29ubmVjdCh7bmFtZTpXfSksaS5vbkRpc2Nvbm5lY3QuYWRkTGlzdGVuZXIoKCk9PntoKCl9KSxpLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihlPT57ZS5fX3BsYXNtb19jc19yZWxvYWRfXyYmaCgpLGUuX19wbGFzbW9fY3NfYWN0aXZlX3RhYl9fJiYoQT0hMCl9KX1mdW5jdGlvbiBqKCl7aWYobD8ucnVudGltZSl0cnl7UigpLHNldEludGVydmFsKFIsMjRlMyl9Y2F0Y2h7cmV0dXJufX1qKCk7VChhc3luYyBlPT57YyhcIlNjcmlwdCBydW50aW1lIC0gb24gdXBkYXRlZCBhc3NldHNcIiksZS5maWx0ZXIobz0+by5lbnZIYXNoPT09cy5lbnZIYXNoKS5zb21lKG89PkwobW9kdWxlLmJ1bmRsZSxvLmlkKSkmJihNLnNob3coKSxsPy5ydW50aW1lP2kucG9zdE1lc3NhZ2Uoe19fcGxhc21vX2NzX2NoYW5nZWRfXzohMH0pOnNldFRpbWVvdXQoKCk9PntoKCl9LDQ3MDApKX0pO1xuIiwiLy8gaW1wb3J0IHsgU3RvcmFnZSB9IGZyb20gXCJAcGxhc21vaHEvc3RvcmFnZVwiXHJcblxyXG4vLyBjb25zdCBzdG9yYWdlID0gbmV3IFN0b3JhZ2UoKVxyXG5cclxuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IHtcclxuICBtYXRjaGVzOiBbXCJodHRwczovL3Byb2dyYW1hcmkuZ292Lm1kL2VuL21hZWllL2FwcG9pbnRtZW50cypcIl1cclxuICBcclxufVxyXG5cclxuY29uc29sZS5sb2coXCJpbiBmb3JtZmlsbFwiKVxyXG5cclxuZnVuY3Rpb24gZ2VuZXJhdGVVbmlxdWVJZGVudGlmaWVyKCkge1xyXG4gIHJldHVybiBjcnlwdG8ucmFuZG9tVVVJRCgpXHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldHZhbHVlKCkge1xyXG4gIGNvbnNvbGUubG9nKFwiaW5zaWRlIGZvcm0gcGFnZVwiKVxyXG4gIGNvbnN0IGRhdGEgPSBhd2FpdCBzdG9yYWdlLmdldChcInVzZXJzZGF0YVwiKVxyXG4gIGNvbnNvbGUubG9nKGRhdGEpXHJcbiAgcmV0dXJuIGRhdGFcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gY2xlYXJEYXRhKCkge1xyXG4gIGNvbnN0IHZhbCA9IGF3YWl0IHN0b3JhZ2UucmVtb3ZlKFwidXNlcnNkYXRhXCIpXHJcbiAgY29uc29sZS5sb2codmFsKVxyXG4gIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwidXNlZEFycmF5c1wiKVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRVbmlxdWVBcnJheSgpIHtcclxuICBjb25zdCBkYXRhID0gYXdhaXQgZ2V0dmFsdWUoKVxyXG4gIC8vIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdhcnJheXNFeGhhdXN0ZWQnLCAnZmFsc2UnKTtcclxuICBpZiAoIWRhdGEgfHwgIUFycmF5LmlzQXJyYXkoZGF0YSkgfHwgZGF0YS5sZW5ndGggPT09IDApIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJJbnZhbGlkIG9yIGVtcHR5IGRhdGEgcmV0cmlldmVkLlwiKVxyXG4gICAgcmV0dXJuIG51bGxcclxuICB9XHJcblxyXG4gIGxldCBwYWdlSWRlbnRpZmllciA9IHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oXCJwYWdlSWRlbnRpZmllclwiKVxyXG4gIGlmICghcGFnZUlkZW50aWZpZXIpIHtcclxuICAgIHBhZ2VJZGVudGlmaWVyID0gZ2VuZXJhdGVVbmlxdWVJZGVudGlmaWVyKClcclxuICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oXCJwYWdlSWRlbnRpZmllclwiLCBwYWdlSWRlbnRpZmllcilcclxuICB9XHJcblxyXG4gIGxldCB1c2VkQXJyYXlzID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZWRBcnJheXNcIikpIHx8IFtdXHJcbiAgbGV0IHVzZWRBcnJheXNfdmFsdWUgPVxyXG4gICAgSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZWRBcnJheXNWYWx1ZVwiKSkgfHwgW11cclxuXHJcbiAgaWYgKHVzZWRBcnJheXMubGVuZ3RoID49IGRhdGEubGVuZ3RoKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiTm8gbW9yZSB1bmlxdWUgYXJyYXlzIGF2YWlsYWJsZS5cIilcclxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYXJyYXlzRXhoYXVzdGVkXCIsIFwidHJ1ZVwiKVxyXG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJwYWdlSWRlbnRpZmllclwiKVxyXG4gICAgc2Vzc2lvblN0b3JhZ2UucmVtb3ZlSXRlbShcInBhZ2VJZGVudGlmaWVyXCIpXHJcbiAgICBhd2FpdCBjbGVhckRhdGEoKVxyXG5cclxuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwidW5pcXVlQXJyYXlcIilcclxuICAgIHdpbmRvdy5jbG9zZSgpXHJcbiAgICBhbGVydChcImFsbCB2YWx1ZXMgYXJlIGZpbGxlZCBub3cgc3RhcnQgYWdhaW5cIilcclxuXHJcbiAgICAvLyByZXR1cm4gbnVsbDtcclxuICB9XHJcblxyXG4gIGxldCB1bmlxdWVBcnJheSA9IG51bGxcclxuXHJcbiAgLy8gRmluZCBhbiB1bnVzZWQgYXJyYXkgaW5kZXhcclxuICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgIGlmICghdXNlZEFycmF5cy5pbmNsdWRlcyhpKSkge1xyXG4gICAgICB1bmlxdWVBcnJheSA9IGRhdGFbaV1cclxuICAgICAgdXNlZEFycmF5cy5wdXNoKGkpXHJcbiAgICAgIHVzZWRBcnJheXNfdmFsdWUucHVzaFtkYXRhW2ldXVxyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInVzZWRBcnJheXNWYWx1ZVwiLCBKU09OLnN0cmluZ2lmeSh1c2VkQXJyYXlzX3ZhbHVlKSlcclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJ1c2VkQXJyYXlzXCIsIEpTT04uc3RyaW5naWZ5KHVzZWRBcnJheXMpKVxyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShwYWdlSWRlbnRpZmllciwgSlNPTi5zdHJpbmdpZnkodW5pcXVlQXJyYXkpKVxyXG4gICAgICBjb25zb2xlLmxvZyhcIlVzZWQgYXJyYXkgaW5kZXg6XCIsIGkpXHJcbiAgICAgIGJyZWFrXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBpZiAoIXVuaXF1ZUFycmF5KSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiTm8gdW51c2VkIGFycmF5IGZvdW5kLlwiKVxyXG4gICAgcmV0dXJuIG51bGxcclxuICB9XHJcblxyXG4gIGNvbnNvbGUubG9nKFwiVXNlZCBhcnJheXM6XCIsIHVzZWRBcnJheXMpXHJcbiAgY29uc29sZS5sb2coXCJVbmlxdWUgYXJyYXk6XCIsIHVuaXF1ZUFycmF5KVxyXG4gIHJldHVybiB1bmlxdWVBcnJheVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBmaW5kZGF0ZWFuZHRpbWVzbG90KGRhdGVWYWx1ZSkge1xyXG4gIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgbGV0IGNkY29udGFpbmVyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcclxuICAgICAgJ2RpdltjbGFzcz1cImNkay1vdmVybGF5LWNvbnRhaW5lclwiXSdcclxuICAgIClcclxuICAgIGNvbnNvbGUubG9nKFwiY2Rjb250YWluZXJcIiwgY2Rjb250YWluZXIpXHJcblxyXG4gICAgbGV0IGNka19vdmVybGF5ID0gY2Rjb250YWluZXIucXVlcnlTZWxlY3RvcignZGl2ID4gZGl2W2lkPVwiY2RrLW92ZXJsYXktMFwiXScpXHJcbiAgICBjb25zb2xlLmxvZyhcImNka19vdmVybGF5XCIsIGNka19vdmVybGF5KVxyXG5cclxuICAgIGxldCBtZW51ID0gY2RrX292ZXJsYXkucXVlcnlTZWxlY3RvcihcclxuICAgICAgJ2Rpdltyb2xlPVwibWVudVwiXSA+IGRpdiA+IGRpdltjbGFzcyo9XCJkYXRlLXRpbWUtcGlja2VyLXdyYXBwZXJcIl0nXHJcbiAgICApXHJcbiAgICBjb25zb2xlLmxvZyhtZW51KVxyXG5cclxuICAgIGxldCBzY3JvbGxiYXIgPSBtZW51LnF1ZXJ5U2VsZWN0b3IoXHJcbiAgICAgIFwibWF0LWNhbGVuZGFyID4gZGl2W2Nka21vbml0b3JzdWJ0cmVlZm9jdXNdXCJcclxuICAgIClcclxuICAgIGNvbnNvbGUubG9nKHNjcm9sbGJhcilcclxuXHJcbiAgICBsZXQgdGFibGUgPSBzY3JvbGxiYXIucXVlcnlTZWxlY3RvcigndGFibGVbcm9sZT1cImdyaWRcIl0gPiB0Ym9keScpXHJcbiAgICBjb25zb2xlLmxvZyh0YWJsZSlcclxuXHJcbiAgICBsZXQgdHIgPSB0YWJsZS5xdWVyeVNlbGVjdG9yQWxsKCd0cltyb2xlPVwicm93XCJdJylcclxuXHJcbiAgICB0ci5mb3JFYWNoKChyb3cpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coXCJyZXBlYXRcIilcclxuICAgICAgbGV0IGFsbGRhdGVzID0gcm93LnF1ZXJ5U2VsZWN0b3JBbGwoXCJ0ZCA+IGJ1dHRvblwiKVxyXG4gICAgICBjb25zb2xlLmxvZyhcImFsbGRhdGVzXCIsIGFsbGRhdGVzKVxyXG4gICAgICBhbGxkYXRlcy5mb3JFYWNoKChidXR0b24pID0+IHtcclxuICAgICAgICBjb25zdCBkaXYgPSBidXR0b24ucXVlcnlTZWxlY3RvcignZGl2W2NsYXNzKj1cIm1hdC1mb2N1cy1pbmRpY2F0b3JcIl0nKVxyXG4gICAgICAgIGNvbnNvbGUubG9nKGRpdikgLy8gQWRqdXN0IHRoZSBzZWxlY3RvciBpZiBuZWNlc3NhcnlcclxuICAgICAgICBpZiAoZGl2ICYmIGRpdi50ZXh0Q29udGVudC50cmltKCkgPT0gZGF0ZVZhbHVlKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhkaXYudGV4dENvbnRlbnQpXHJcblxyXG4gICAgICAgICAgYnV0dG9uLmFyaWFQcmVzc2VkID0gXCJ0cnVlXCJcclxuICAgICAgICAgIGJ1dHRvbi5jbGljaygpXHJcbiAgICAgICAgICB0aW1lU2VsZWN0KG1lbnUpXHJcbiAgICAgICAgICByZXR1cm5cclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICB9KVxyXG4gIH0sIDQwMDApXHJcbn1cclxuXHJcbmZ1bmN0aW9uIHRpbWVTZWxlY3QobWVudSkge1xyXG4gIGxldCBzY3JvbGxiYXIgPSBtZW51LnF1ZXJ5U2VsZWN0b3IoXCJuZy1zY3JvbGxiYXJcIilcclxuICBjb25zb2xlLmxvZyhcInNjcm9sbGJhclwiLCBzY3JvbGxiYXIpXHJcbiAgbGV0IG13bF9jYWxlbmRhcl93ZWVrID0gc2Nyb2xsYmFyLnF1ZXJ5U2VsZWN0b3IoXHJcbiAgICAnbXdsLWNhbGVuZGFyLWRheS12aWV3ID4gbXdsLWNhbGVuZGFyLXdlZWstdmlldyA+IGRpdltyb2xlPVwiZ3JpZFwiXSdcclxuICApXHJcbiAgY29uc29sZS5sb2coXCJtd2xfY2FsZW5kYXJfd2Vla1wiLCBtd2xfY2FsZW5kYXJfd2VlaylcclxuXHJcbiAgbXdsZHJvcHBhYmxlID0gbXdsX2NhbGVuZGFyX3dlZWsucXVlcnlTZWxlY3RvcignZGl2W2NsYXNzPVwiY2FsLXRpbWUtZXZlbnRzXCJdJylcclxuICBjb25zb2xlLmxvZyhcIm13bGRyb3BwYWJsZVwiLCBtd2xkcm9wcGFibGUpXHJcblxyXG4gIGxldCBwcmVzZW50aG91ciA9IG13bGRyb3BwYWJsZS5xdWVyeVNlbGVjdG9yQWxsKCdkaXZbY2xhc3MqPVwiY2FsLWhvdXJcIl0nKVxyXG5cclxuICBjb25zb2xlLmxvZyhcInByZXNlbnRob3VyXCIsIHByZXNlbnRob3VyKVxyXG4gIHByZXNlbnRob3VyLmZvckVhY2goKGVhY2h0aW1lYXZhaWxjaGVjaykgPT4ge1xyXG4gICAgbGV0IHRpbWUgPSBlYWNodGltZWF2YWlsY2hlY2sucXVlcnlTZWxlY3RvcihcclxuICAgICAgJ213bC1jYWxlbmRhci13ZWVrLXZpZXctaG91ci1zZWdtZW50ID4gZGl2W2NsYXNzKj1cInRpbWUtY2VsbFwiXSdcclxuICAgIClcclxuICAgIGNvbnNvbGUubG9nKHRpbWUpXHJcblxyXG4gICAgbGV0IGJhZGdlID0gdGltZS5xdWVyeVNlbGVjdG9yKCdzcGFuW2NsYXNzPVwiYmFkZ2VcIl0nKVxyXG4gICAgaWYoYmFkZ2UpIHtcclxuICAgIGNvbnNvbGUubG9nKFwiYmFkZ2VcIiwgYmFkZ2UpXHJcbiAgICB0aW1lLmNsaWNrKClcclxuICAgIH1cclxuICB9KVxyXG5cclxuICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgIGxldCBtYWluID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignbWFpbltyb2xlPVwibWFpblwiXSA+IGVhcC1hcHBvaW50bWVudHMgPiBkaXZbY2xhc3MqPVwiY29udGFpbmVyXCJdJylcclxuICAgIGNvbnNvbGUubG9nKFwibWFpblwiLCBtYWluKVxyXG4gICAgbGV0IGJ1dHRvbiA9IG1haW4ucXVlcnlTZWxlY3RvcignZGl2W2NsYXNzPVwiY29udGVudFwiXScpXHJcbiAgICBjb25zb2xlLmxvZyhcImJ1dHRvbmZvcnN1Ym1pdFwiLCBidXR0b24pXHJcbiAgICBsZXQgYnV0dG9uc2VsZWN0ID0gYnV0dG9uLnF1ZXJ5U2VsZWN0b3IoJ2RpdltjbGFzcz1cImxlZnRcIl0nKVxyXG4gICAgbGV0IHN1Ym1pdCA9IGJ1dHRvbnNlbGVjdC5xdWVyeVNlbGVjdG9yKFwiYnV0dG9uW21hdC1yYWlzZWQtYnV0dG9uXVwiKVxyXG4gICAgY29uc29sZS5sb2coc3VibWl0KVxyXG4gICAgaWYgKHN1Ym1pdCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHN1Ym1pdC5jbGljaygpXHJcbiAgICAgICAgLy8gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgLy8gLy8gICBhbGVydChcImZvcm0gZmlsbGVkIHN1Y2Nlc3NmdWxseVwiKVxyXG4gICAgICAgIC8vICAgd2luZG93LmNsb3NlKClcclxuICAgICAgICAvLyB9LCAyMDAwMClcclxuICAgICAgICAvLyBQcm9ncmFtbWF0aWNhbGx5IGNsaWNrIHRoZSBzdWJtaXQgYnV0dG9uXHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJoZXJlIGluc2lkZSBlcnJvclwiKVxyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpXHJcbiAgICAgICAgd2luZG93LmNsb3NlKClcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIlN1Ym1pdCBidXR0b24gbm90IGZvdW5kIGluIHRoZSBmb3JtLlwiKVxyXG4gICAgfVxyXG4gIH0sIDEwMDApXHJcbiAgcmV0dXJuXHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHdhaXRGb3JEYXRlVmFsdWUoZm91bmRkYXRlKSB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgIGlmIChmb3VuZGRhdGUpIHtcclxuICAgICAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigobXV0YXRpb25zTGlzdCwgb2JzZXJ2ZXIpID0+IHtcclxuICAgICAgICBmb3IgKGxldCBtdXRhdGlvbiBvZiBtdXRhdGlvbnNMaXN0KSB7XHJcbiAgICAgICAgICBpZiAobXV0YXRpb24udHlwZSA9PT0gXCJjaGlsZExpc3RcIikge1xyXG4gICAgICAgICAgICBsZXQgY2hlY2tkYXRlYXZhaWwgPSBmb3VuZGRhdGUucXVlcnlTZWxlY3RvcihcIm1hdC1pY29uXCIpXHJcbiAgICAgICAgICAgIGlmIChjaGVja2RhdGVhdmFpbCkge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwibWF0LWljb24gZWxlbWVudCBmb3VuZDpcIiwgY2hlY2tkYXRlYXZhaWwpXHJcbiAgICAgICAgICAgICAgLy8gRXh0cmFjdCB0aGUgaW5uZXIgdGV4dCB2YWx1ZSBmcm9tIGZvdW5kZGF0ZVxyXG4gICAgICAgICAgICAgIGxldCBkYXRlVmFsdWUgPSBmb3VuZGRhdGUuaW5uZXJUZXh0LnRyaW0oKVxyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRGF0ZSB2YWx1ZTpcIiwgZGF0ZVZhbHVlKVxyXG4gICAgICAgICAgICAgIC8vIE9wdGlvbmFsbHkgZGlzY29ubmVjdCB0aGUgb2JzZXJ2ZXIgYWZ0ZXIgZmluZGluZyB0aGUgZWxlbWVudFxyXG4gICAgICAgICAgICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKVxyXG4gICAgICAgICAgICAgIC8vICAgc2xvdEJvb2tlZCA9IHRydWUgLy8gU2V0IHNsb3RCb29rZWQgdG8gdHJ1ZSB0byBzdG9wIGZ1cnRoZXIgcHJvY2Vzc2luZ1xyXG4gICAgICAgICAgICAgIHJlc29sdmUoZGF0ZVZhbHVlKSAvLyBSZXNvbHZlIHRoZSBwcm9taXNlIHdpdGggdGhlIGRhdGUgdmFsdWVcclxuICAgICAgICAgICAgICByZXR1cm5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuXHJcbiAgICAgIG9ic2VydmVyLm9ic2VydmUoZm91bmRkYXRlLCB7XHJcbiAgICAgICAgY2hpbGRMaXN0OiB0cnVlLFxyXG4gICAgICAgIHN1YnRyZWU6IHRydWVcclxuICAgICAgfSlcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlamVjdChcImZvdW5kZGF0ZSBlbGVtZW50IGlzIG5vdCBkZWZpbmVkXCIpXHJcbiAgICB9XHJcbiAgfSlcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZmlsbHNhbmRzdWJtaXRzdmFsdWUoKSB7XHJcbiAgLy8gbGV0IHBhZ2VJZGVudGlmaWVyID0gc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSgncGFnZUlkZW50aWZpZXInKTtcclxuXHJcbiAgLy8gaWYgKCFwYWdlSWRlbnRpZmllcikge1xyXG4gIC8vICAgcGFnZUlkZW50aWZpZXIgPSBnZW5lcmF0ZVVuaXF1ZUlkZW50aWZpZXIoKTtcclxuICAvLyAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ3BhZ2VJZGVudGlmaWVyJywgcGFnZUlkZW50aWZpZXIpO1xyXG4gIC8vIH1cclxuXHJcbiAgLy8gY29uc3QgdmFsID0gYXdhaXQgZ2V0VW5pcXVlQXJyYXkoKTtcclxuICAvLyBpZiAoIXZhbCkge1xyXG4gIC8vICAgYWxlcnQoJ2ZpbGwgdGhlIHZhbHVlcyBpbiBleGNlbCBzaGVldCBhbmQgdGhlbiByZXRyeScpXHJcbiAgLy8gICBjb25zb2xlLmVycm9yKCdObyB1bmlxdWUgYXJyYXkgZm91bmQuJyk7XHJcbiAgLy8gICB3aW5kb3cuY2xvc2UoKVxyXG4gIC8vIH1cclxuXHJcbiAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhcImhlcmUgaW5zaWRlIHRpbWVvdXRcIilcclxuXHJcbiAgICBsZXQgbWFpbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ21haW5bcm9sZT1cIm1haW5cIl0nKVxyXG4gICAgY29uc29sZS5sb2cobWFpbilcclxuICAgIGxldCBmb3JtID0gbWFpbi5xdWVyeVNlbGVjdG9yKFwiZm9ybVwiKVxyXG5cclxuICAgIGNvbnN0IHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzY3JpcHRcIilcclxuICAgIHNjcmlwdC50ZXh0Q29udGVudCA9IGAoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgbGV0IGZvcm0gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFxyXG4gICAgJ2Zvcm0nKVxyXG4gICAgIGZvcm0uc2V0QXR0cmlidXRlKCdub3ZhbGlkYXRlJywgdHJ1ZSk7XHJcbiAgICAgZm9ybS5hZGRFdmVudExpc3RlbmVyKCdzdWJtaXQnLCBmdW5jdGlvbihlKSB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpOyAvLyBQcmV2ZW50IGRlZmF1bHQgZm9ybSBzdWJtaXNzaW9uXHJcbiAgICAgICAgLy8gQWRkaXRpb25hbCBsb2dpYyBmb3IgaGFuZGxpbmcgZm9ybSBzdWJtaXNzaW9uIGhlcmUgaWYgbmVlZGVkXHJcbiAgICAgfSk7XHJcbiAgICB9KSgpYFxyXG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChzY3JpcHQpXHJcblxyXG4gICAgY29uc29sZS5sb2coZm9ybSlcclxuICAgIGxldCBjaXRpemVuID0gZm9ybS5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAnZGl2W2NsYXNzKj1cImVhcC1jYXJkXCJdID4gZGl2Om50aC1jaGlsZCgxKSdcclxuICAgIClcclxuICAgIGNvbnNvbGUubG9nKGNpdGl6ZW4pXHJcbiAgICBsZXQgY2hlY2tib3ggPSBjaXRpemVuLnF1ZXJ5U2VsZWN0b3IoXCJtYXQtY2hlY2tib3ggPiBsYWJlbFwiKVxyXG4gICAgY29uc29sZS5sb2coY2hlY2tib3gpXHJcbiAgICBsZXQgaW5wdXRjaGVja2JveCA9IGNoZWNrYm94LnF1ZXJ5U2VsZWN0b3IoJ2lucHV0W3R5cGU9XCJjaGVja2JveFwiXScpXHJcbiAgICBjb25zb2xlLmxvZyhpbnB1dGNoZWNrYm94KVxyXG4gICAgaWYgKGlucHV0Y2hlY2tib3gpIHtcclxuICAgICAgaW5wdXRjaGVja2JveC5jbGljaygpXHJcbiAgICAgIC8vICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJpbnB1dFwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpO1xyXG4gICAgICAvLyAgIGlucHV0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiY2hlY2tlZFwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBBZ3JlZVRlcm1zID0gZm9ybS5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAnbGFiZWwgPiBzcGFuID4gaW5wdXRbaWQ9XCJtYXQtY2hlY2tib3gtMS1pbnB1dFwiXSdcclxuICAgIClcclxuICAgIGNvbnNvbGUubG9nKEFncmVlVGVybXMpXHJcbiAgICBpZiAoQWdyZWVUZXJtcykge1xyXG4gICAgICBBZ3JlZVRlcm1zLmNsaWNrKClcclxuICAgIH1cclxuXHJcbiAgICBsZXQgc2VjdGlvbmlucHV0ID0gZm9ybS5xdWVyeVNlbGVjdG9yQWxsKFwic2VjdGlvblwiKVxyXG4gICAgY29uc29sZS5sb2coc2VjdGlvbmlucHV0KVxyXG5cclxuICAgIHNlY3Rpb25pbnB1dC5mb3JFYWNoKChmaWVsZCwgaW5kZXgpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coaW5kZXgpXHJcbiAgICAgIGNvbnNvbGUubG9nKGZpZWxkKVxyXG4gICAgICBpZiAoaW5kZXggPT0gMCkge1xyXG4gICAgICAgIGxldCBuYW1lcyA9IGZpZWxkLnF1ZXJ5U2VsZWN0b3IoJ2Rpdltmb3JtZ3JvdXBuYW1lPVwidXNlclwiXScpXHJcbiAgICAgICAgbGV0IG51bWFuZGFkZHJlc3MgPSBmaWVsZC5xdWVyeVNlbGVjdG9yKCdkaXZbY2xhc3M9XCJncm91cGVkLWZpZWxkc1wiXScpXHJcbiAgICAgICAgY29uc29sZS5sb2cobmFtZXMpXHJcbiAgICAgICAgY29uc29sZS5sb2cobnVtYW5kYWRkcmVzcylcclxuICAgICAgICBsZXQgbGFiZWxzID0gbmFtZXMucXVlcnlTZWxlY3RvckFsbChcImxhYmVsXCIpXHJcbiAgICAgICAgbGV0IHJsYWJlbHMgPSBudW1hbmRhZGRyZXNzLnF1ZXJ5U2VsZWN0b3JBbGwoXCJsYWJlbFwiKVxyXG4gICAgICAgIGxhYmVscy5mb3JFYWNoKChsYWJlbCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgIGlmIChsYWJlbCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhsYWJlbC5pbm5lclRleHQpXHJcbiAgICAgICAgICAgIGlmIChsYWJlbC5pbm5lclRleHQuaW5jbHVkZXMoXCJGaXJzdCBuYW1lKlwiKSkge1xyXG4gICAgICAgICAgICAgIGxldCBpbnB1dCA9IGxhYmVsLnF1ZXJ5U2VsZWN0b3IoXCJpbnB1dFwiKVxyXG5cclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhpbnB1dClcclxuICAgICAgICAgICAgICBpbnB1dC52YWx1ZSA9IFwia3Jpc2huYVwiXHJcbiAgICAgICAgICAgICAgLy8gICB2YWwuRmlyc3RuYW1lXHJcbiAgICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJpbnB1dFwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpXHJcbiAgICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKVxyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGxhYmVsLmlubmVyVGV4dC5pbmNsdWRlcyhcIkxhc3QgbmFtZSpcIikpIHtcclxuICAgICAgICAgICAgICBsZXQgaW5wdXQgPSBsYWJlbC5xdWVyeVNlbGVjdG9yKFwiaW5wdXRcIilcclxuXHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coaW5wdXQpXHJcbiAgICAgICAgICAgICAgaW5wdXQudmFsdWUgPSBcImxhbGFcIlxyXG4gICAgICAgICAgICAgIC8vICAgdmFsLkxhc3RuYW1lXHJcbiAgICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJpbnB1dFwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpXHJcbiAgICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuXHJcbiAgICAgICAgcmxhYmVscy5mb3JFYWNoKChsYWJlbCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgIGlmIChsYWJlbCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhsYWJlbC5pbm5lclRleHQpXHJcbiAgICAgICAgICAgIGlmIChsYWJlbC5pbm5lclRleHQuaW5jbHVkZXMoXCJQYXNzcG9ydCBudW1iZXIqXCIpKSB7XHJcbiAgICAgICAgICAgICAgbGV0IGlucHV0ID0gbGFiZWwucXVlcnlTZWxlY3RvcihcImlucHV0XCIpXHJcblxyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKGlucHV0KVxyXG4gICAgICAgICAgICAgIGlucHV0LnZhbHVlID0gXCIxMTIzNDU2Nzg5XCJcclxuICAgICAgICAgICAgICAvLyAgIHZhbC5QYXNzcG9ydG51bWJlclxyXG4gICAgICAgICAgICAgIGlucHV0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiaW5wdXRcIiwgeyBidWJibGVzOiB0cnVlIH0pKVxyXG4gICAgICAgICAgICAgIGlucHV0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiY2hhbmdlXCIsIHsgYnViYmxlczogdHJ1ZSB9KSlcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChsYWJlbC5pbm5lclRleHQuaW5jbHVkZXMoXCJSZXNpZGVuY2UgYWRkcmVzc1wiKSkge1xyXG4gICAgICAgICAgICAgIGxldCBpbnB1dCA9IGxhYmVsLnF1ZXJ5U2VsZWN0b3IoXCJpbnB1dFwiKVxyXG5cclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhpbnB1dClcclxuICAgICAgICAgICAgICBpbnB1dC52YWx1ZSA9IFwibWF0dXJhXCJcclxuICAgICAgICAgICAgICAvLyAgIHZhbC5SZXNpZGVuY2VhZGRyZXNzXHJcbiAgICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJpbnB1dFwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpXHJcbiAgICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKGluZGV4ID09IDEpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcImh5XCIpXHJcbiAgICAgICAgbGV0IGxhYmVscyA9IGZpZWxkLnF1ZXJ5U2VsZWN0b3JBbGwoXCJsYWJlbFwiKVxyXG4gICAgICAgIGxhYmVscy5mb3JFYWNoKChsYWJlbCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgIGlmIChsYWJlbCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhsYWJlbC5pbm5lclRleHQpXHJcbiAgICAgICAgICAgIGlmIChsYWJlbC5pbm5lclRleHQuaW5jbHVkZXMoXCJQaG9uZSpcIikpIHtcclxuICAgICAgICAgICAgICBsZXQgaW5wdXQgPSBsYWJlbC5xdWVyeVNlbGVjdG9yKFwiaW5wdXRcIilcclxuXHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coaW5wdXQpXHJcbiAgICAgICAgICAgICAgaW5wdXQudmFsdWUgPSBcIjkyNjM3NDQ0MDRcIlxyXG4gICAgICAgICAgICAgIC8vICAgdmFsLnBob25lXHJcbiAgICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJpbnB1dFwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpXHJcbiAgICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKVxyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGxhYmVsLmlubmVyVGV4dC5pbmNsdWRlcyhcIkVtYWlsKlwiKSkge1xyXG4gICAgICAgICAgICAgIGxldCBpbnB1dCA9IGxhYmVsLnF1ZXJ5U2VsZWN0b3IoXCJpbnB1dFwiKVxyXG5cclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhpbnB1dClcclxuICAgICAgICAgICAgICBpbnB1dC52YWx1ZSA9IFwia2FuaGFAZ2V0TWF4TGlzdGVuZXJzLmNvbVwiXHJcbiAgICAgICAgICAgICAgLy8gICB2YWwuZW1haWxcclxuICAgICAgICAgICAgICBpbnB1dC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImlucHV0XCIsIHsgYnViYmxlczogdHJ1ZSB9KSlcclxuICAgICAgICAgICAgICBpbnB1dC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImNoYW5nZVwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoaW5kZXggPT0gMikge1xyXG4gICAgICAgIGxldCBpbnNpZGVzZWN0aW9uID0gZmllbGQucXVlcnlTZWxlY3RvcihcclxuICAgICAgICAgICdkaXZbY2xhc3MqPVwiZ3JvdXBlZC1maWVsZHMgbmctc3Rhci1pbnNlcnRlZFwiXSdcclxuICAgICAgICApXHJcbiAgICAgICAgY29uc29sZS5sb2coaW5zaWRlc2VjdGlvbilcclxuXHJcbiAgICAgICAgbGV0IGxhYmVscyA9IGluc2lkZXNlY3Rpb24ucXVlcnlTZWxlY3RvckFsbChcImxhYmVsXCIpXHJcbiAgICAgICAgY29uc29sZS5sb2cobGFiZWxzKVxyXG5cclxuICAgICAgICBsYWJlbHMuZm9yRWFjaCgobGFiZWwsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICBpZiAoaW5kZXggPT0gMCkge1xyXG4gICAgICAgICAgICBsZXQgbmdzZWxlY3QgPSBsYWJlbC5xdWVyeVNlbGVjdG9yKFwibmctc2VsZWN0XCIpXHJcbiAgICAgICAgICAgIGxldCBzZWxlY3QgPSBuZ3NlbGVjdC5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAgICAgICAgICdkaXYgPiBkaXZbY2xhc3M9XCJuZy12YWx1ZS1jb250YWluZXJcIl0nXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgICAgY29uc29sZS5sb2coc2VsZWN0KVxyXG4gICAgICAgICAgICBsZXQgaW5wdXQgPSBzZWxlY3QucXVlcnlTZWxlY3RvcignZGl2W3JvbGU9XCJjb21ib2JveFwiXSA+IGlucHV0JylcclxuICAgICAgICAgICAgY29uc29sZS5sb2coaW5wdXQpXHJcbiAgICAgICAgICAgIC8vIGxldCBpbnB1dCA9IHNlbGVjdC5xdWVyeVNlbGVjdG9yKCdpbnB1dCcpXHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGlucHV0KVxyXG4gICAgICAgICAgICBpbnB1dC52YWx1ZSA9IFwiVmlzYVwiXHJcbiAgICAgICAgICAgIGlucHV0LmZvY3VzKClcclxuXHJcbiAgICAgICAgICAgIGlucHV0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiaW5wdXRcIiwgeyBidWJibGVzOiB0cnVlIH0pKVxyXG4gICAgICAgICAgICBpbnB1dC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImNoYW5nZVwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpXHJcblxyXG4gICAgICAgICAgICBsZXQgZW50ZXJFdmVudCA9IG5ldyBLZXlib2FyZEV2ZW50KFwia2V5ZG93blwiLCB7XHJcbiAgICAgICAgICAgICAgYnViYmxlczogdHJ1ZSxcclxuICAgICAgICAgICAgICBjYW5jZWxhYmxlOiB0cnVlLFxyXG4gICAgICAgICAgICAgIGtleTogXCJFbnRlclwiLFxyXG4gICAgICAgICAgICAgIGtleUNvZGU6IDEzXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIGlucHV0LmRpc3BhdGNoRXZlbnQoZW50ZXJFdmVudClcclxuICAgICAgICAgIH0gZWxzZSBpZiAoaW5kZXggPT0gMSkge1xyXG4gICAgICAgICAgICBsZXQgZGF0ZWFuZHRpbWUgPSBsYWJlbC5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAgICAgICAgICdkaXZbY2xhc3MqPVwibWF0LWZvcm0tZmllbGQtd3JhcHBlclwiXSdcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRlYW5kdGltZSlcclxuXHJcbiAgICAgICAgICAgIGxldCBjbGlja3NlbGVjdCA9IGRhdGVhbmR0aW1lLnF1ZXJ5U2VsZWN0b3IoXCJkaXZcIilcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJjbGlja3NlbGVjdFwiLCBjbGlja3NlbGVjdClcclxuICAgICAgICAgICAgbGV0IGNsaWNrID0gY2xpY2tzZWxlY3QucXVlcnlTZWxlY3RvcihcclxuICAgICAgICAgICAgICAnZGl2W2NsYXNzKj1cIm1hdC1mb3JtLWZpZWxkLWluZml4XCJdJ1xyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiY2xpY2tcIiwgY2xpY2spXHJcbiAgICAgICAgICAgIGNsaWNrLmNsaWNrKClcclxuXHJcbiAgICAgICAgICAgIC8vIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoc2NyaXB0KTtcclxuXHJcbiAgICAgICAgICAgIGxldCBjaGVja2luZ2F2YWlsID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignZGl2W2NsYXNzPVwicmlnaHRcIl0nKVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhjaGVja2luZ2F2YWlsKVxyXG4gICAgICAgICAgICBsZXQgc3RpY2t5Y2FsID0gY2hlY2tpbmdhdmFpbC5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAgICAgICAgICdkaXZbY2xhc3MqPVwic3RpY2t5LWNhbGVuZGFyXCJdID4gZWFwLXNlcnZpY2VzLWNhbGVuZGFyJ1xyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHN0aWNreWNhbClcclxuICAgICAgICAgICAgbGV0IGRhdGUgPSBzdGlja3ljYWwucXVlcnlTZWxlY3RvcihcclxuICAgICAgICAgICAgICAnbXdsLWNhbGVuZGFyLW1vbnRoLXZpZXcgPiBkaXZbcm9sZT1cImdyaWRcIl0gPiBkaXZbY2xhc3M9XCJjYWwtZGF5c1wiXSdcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRlKVxyXG4gICAgICAgICAgICAvLyBsZXQgc2xvdEJvb2tlZCA9IGZhbHNlXHJcbiAgICAgICAgICAgIGxldCBhdmFpbCA9IGRhdGUucXVlcnlTZWxlY3RvckFsbCgnZGl2W2NsYXNzPVwibmctc3Rhci1pbnNlcnRlZFwiXScpXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYXZhaWxcIiwgYXZhaWwpXHJcbiAgICAgICAgICAgIGF2YWlsLmZvckVhY2goKGRhdGVyb3cpID0+IHtcclxuICAgICAgICAgICAgICAvLyAgIGlmIChzbG90Qm9va2VkKSByZXR1cm5cclxuICAgICAgICAgICAgICBsZXQgbXdsX2NhbGVuZGFyID0gZGF0ZXJvdy5xdWVyeVNlbGVjdG9yQWxsKFxyXG4gICAgICAgICAgICAgICAgJ2Rpdltyb2xlPVwicm93XCJdID4gbXdsLWNhbGVuZGFyLW1vbnRoLWNlbGwnXHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwibXdsX2NhbGVuZGFyXCIsIG13bF9jYWxlbmRhcilcclxuICAgICAgICAgICAgICBtd2xfY2FsZW5kYXIuZm9yRWFjaCgoY2FsZW5kYXIpID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCBmb3VuZGRhdGUgPSBjYWxlbmRhci5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAgICAgICAgICAgICAnZGl2ID4gZGl2W2NsYXNzPVwiZGF0ZVwiXSdcclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGZvdW5kZGF0ZSlcclxuICAgICAgICAgICAgICAgIGxldCBzbG90Qm9va2VkID0gZmFsc2UgLy8gRW5zdXJlIHNsb3RCb29rZWQgaXMgZGVmaW5lZCBvdXRzaWRlIHRoZSBmdW5jdGlvbiBzY29wZVxyXG5cclxuICAgICAgICAgICAgICAgIHdhaXRGb3JEYXRlVmFsdWUoZm91bmRkYXRlKVxyXG4gICAgICAgICAgICAgICAgICAudGhlbihhc3luYyAoZGF0ZVZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gcGVyZm9ybUZ1cnRoZXJPcGVyYXRpb25zKGRhdGVWYWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImhlcmVcIilcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRlVmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgc2xvdEJvb2tlZCA9IHRydWVcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBmaW5kZGF0ZWFuZHRpbWVzbG90KGRhdGVWYWx1ZSlcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuXHJcbiAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKVxyXG4gICAgICAgICAgICAgICAgICB9KVxyXG5cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwib3V0IG9uIGFzeW5jIGF3YWl0XCIpXHJcbiAgICAgICAgICAgICAgICAvLyBpZiAoZm91bmRkYXRlKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgIGNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgKG11dGF0aW9uc0xpc3QsIG9ic2VydmVyKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICBmb3IgKGxldCBtdXRhdGlvbiBvZiBtdXRhdGlvbnNMaXN0KSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIGlmIChzbG90Qm9va2VkKSByZXR1cm5cclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgaWYgKG11dGF0aW9uLnR5cGUgPT09IFwiY2hpbGRMaXN0XCIpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICBsZXQgY2hlY2tkYXRlYXZhaWwgPVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgZm91bmRkYXRlLnF1ZXJ5U2VsZWN0b3IoXCJtYXQtaWNvblwiKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgIGlmIChjaGVja2RhdGVhdmFpbCkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgY29uc29sZS5sb2coXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgIFwibWF0LWljb24gZWxlbWVudCBmb3VuZDpcIixcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgY2hlY2tkYXRlYXZhaWxcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIEV4dHJhY3QgdGhlIGlubmVyIHRleHQgdmFsdWUgZnJvbSBmb3VuZGRhdGVcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIGxldCBkYXRlVmFsdWUgPSBmb3VuZGRhdGUuaW5uZXJUZXh0LnRyaW0oKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgY29uc29sZS5sb2coXCJEYXRlIHZhbHVlOlwiLCBkYXRlVmFsdWUpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyBPcHRpb25hbGx5IGRpc2Nvbm5lY3QgdGhlIG9ic2VydmVyIGFmdGVyIGZpbmRpbmcgdGhlIGVsZW1lbnRcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgc2xvdEJvb2tlZCA9IHRydWU7IC8vIFNldCBzbG90Qm9va2VkIHRvIHRydWUgdG8gc3RvcCBmdXJ0aGVyIHByb2Nlc3NpbmdcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gbGV0IGlucHV0ID0gZGF0ZWFuZHRpbWUucXVlcnlTZWxlY3RvcihcImlucHV0XCIpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhpbnB1dClcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIGNvbnN0IG5vdyA9IG5ldyBEYXRlKClcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKG5vdylcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIGNvbnN0IHllYXIgPSBub3cuZ2V0RnVsbFllYXIoKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gY29uc3QgbW9udGggPSAobm93LmdldE1vbnRoKCkgKyAxKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICAucGFkU3RhcnQoMiwgXCIwXCIpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyBjb25zdCBkYXkgPSBkYXRlVmFsdWVcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIGNvbnN0IGZvcm1hdHRlZERhdGUgPSBgJHtkYXl9LiR7bW9udGh9LiR7eWVhcn1gXHJcblxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gaW5wdXQudmFsdWUgPSBmb3JtYXR0ZWREYXRlXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyBidXR0b25jbGlja2VkID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gc2xvdEJvb2tlZCA9IHRydWVcclxuXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyBsZXQgYnV0dG9uID1cclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vICAgbWFpbi5xdWVyeVNlbGVjdG9yKCdkaXZbY2xhc3M9XCJjb250ZW50XCJdID4gZGl2W2NsYXNzPVwibGVmdF0nKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gY29uc29sZS5sb2coYnV0dG9uKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gY29uc3Qgc3VibWl0ID0gYnV0dG9uLnF1ZXJ5U2VsZWN0b3IoXCJidXR0b25cIilcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHN1Ym1pdClcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIGlmIChzdWJtaXQpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vICAgICBzdWJtaXQuY2xpY2soKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICAgICAgYWxlcnQoXCJmb3JtIGZpbGxlZCBzdWNjZXNzZnVsbHlcIilcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vICAgICAgIHdpbmRvdy5jbG9zZSgpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgICAgfSwgMTAwMDApXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgICAgLy8gUHJvZ3JhbW1hdGljYWxseSBjbGljayB0aGUgc3VibWl0IGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKFwiaGVyZSBpbnNpZGUgZXJyb3JcIilcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vICAgICBjb25zb2xlLmVycm9yKGVycm9yKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICAgIHdpbmRvdy5jbG9zZSgpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgIGNvbnNvbGUuZXJyb3IoXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgICAgXCJTdWJtaXQgYnV0dG9uIG5vdCBmb3VuZCBpbiB0aGUgZm9ybS5cIlxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICApXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyB0aGlzIGNvZGUgcmVzcG9uc2libGUgZm9yIHJlcXVlc3RpbmcgdGhlIEFwcG9pbnRtZW50XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgcmV0dXJuXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICApXHJcblxyXG4gICAgICAgICAgICAgICAgLy8gICBvYnNlcnZlci5vYnNlcnZlKGZvdW5kZGF0ZSwge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgIGNoaWxkTGlzdDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIC8vICAgICBzdWJ0cmVlOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAvLyAgIH0pXHJcbiAgICAgICAgICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coZGF0ZVZhbHVlKVxyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgfSlcclxuXHJcbiAgICBjb25zb2xlLmxvZyhcImxldHMgc3VibWl0IHRoZSBmb3JtXCIpXHJcbiAgfSwgNTAwMClcclxufVxyXG5cclxud2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJsb2FkXCIsICgpID0+IHtcclxuICBsZXQgYnV0dG9uY2xpY2tlZCA9IGZhbHNlXHJcbiAgZmlsbHNhbmRzdWJtaXRzdmFsdWUoKVxyXG4gIHNldEludGVydmFsKCgpID0+IHtcclxuICAgIGlmIChidXR0b25jbGlja2VkKSB7XHJcbiAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gd2luZG93LmxvY2F0aW9uLmhyZWZcclxuICAgIH1cclxuICB9LCAyMDAwMClcclxufSlcclxuIiwiZXhwb3J0cy5pbnRlcm9wRGVmYXVsdCA9IGZ1bmN0aW9uIChhKSB7XG4gIHJldHVybiBhICYmIGEuX19lc01vZHVsZSA/IGEgOiB7ZGVmYXVsdDogYX07XG59O1xuXG5leHBvcnRzLmRlZmluZUludGVyb3BGbGFnID0gZnVuY3Rpb24gKGEpIHtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGEsICdfX2VzTW9kdWxlJywge3ZhbHVlOiB0cnVlfSk7XG59O1xuXG5leHBvcnRzLmV4cG9ydEFsbCA9IGZ1bmN0aW9uIChzb3VyY2UsIGRlc3QpIHtcbiAgT2JqZWN0LmtleXMoc291cmNlKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHtcbiAgICBpZiAoa2V5ID09PSAnZGVmYXVsdCcgfHwga2V5ID09PSAnX19lc01vZHVsZScgfHwgZGVzdC5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGRlc3QsIGtleSwge1xuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gc291cmNlW2tleV07XG4gICAgICB9LFxuICAgIH0pO1xuICB9KTtcblxuICByZXR1cm4gZGVzdDtcbn07XG5cbmV4cG9ydHMuZXhwb3J0ID0gZnVuY3Rpb24gKGRlc3QsIGRlc3ROYW1lLCBnZXQpIHtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGRlc3QsIGRlc3ROYW1lLCB7XG4gICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICBnZXQ6IGdldCxcbiAgfSk7XG59O1xuIl0sIm5hbWVzIjpbXSwidmVyc2lvbiI6MywiZmlsZSI6ImZvcm1maWxsLmU0ZTgyMmUzLmpzLm1hcCJ9
 globalThis.define=__define;  })(globalThis.define);