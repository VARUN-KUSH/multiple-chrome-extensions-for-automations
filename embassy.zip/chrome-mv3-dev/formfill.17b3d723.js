(function(define){var __define; typeof define === "function" && (__define=define,define=null);
// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"dJmo0":[function(require,module,exports) {
var d = typeof globalThis.process < "u" ? globalThis.process.argv : [];
var y = ()=>typeof globalThis.process < "u" ? globalThis.process.env : {};
var H = new Set(d), _ = (e)=>H.has(e), G = d.filter((e)=>e.startsWith("--") && e.includes("=")).map((e)=>e.split("=")).reduce((e, [t, o])=>(e[t] = o, e), {});
var Z = _("--dry-run"), p = ()=>_("--verbose") || y().VERBOSE === "true", q = p();
var u = (e = "", ...t)=>console.log(e.padEnd(9), "|", ...t);
var x = (...e)=>console.error("\uD83D\uDD34 ERROR".padEnd(9), "|", ...e), b = (...e)=>u("\uD83D\uDD35 INFO", ...e), m = (...e)=>u("\uD83D\uDFE0 WARN", ...e), S = 0, c = (...e)=>p() && u(`\u{1F7E1} ${S++}`, ...e);
var s = {
    "isContentScript": true,
    "isBackground": false,
    "isReact": false,
    "runtimes": [
        "script-runtime"
    ],
    "host": "localhost",
    "port": 1815,
    "entryFilePath": "C:\\Users\\shirisi\\Desktop\\extension\\embassy-of-moldova\\contents\\formfill.js",
    "bundleId": "10e15b2317b3d723",
    "envHash": "e792fbbdaa78ee84",
    "verbose": "false",
    "secure": false,
    "serverPort": 1012
};
module.bundle.HMR_BUNDLE_ID = s.bundleId;
globalThis.process = {
    argv: [],
    env: {
        VERBOSE: s.verbose
    }
};
var D = module.bundle.Module;
function I(e) {
    D.call(this, e), this.hot = {
        data: module.bundle.hotData[e],
        _acceptCallbacks: [],
        _disposeCallbacks: [],
        accept: function(t) {
            this._acceptCallbacks.push(t || function() {});
        },
        dispose: function(t) {
            this._disposeCallbacks.push(t);
        }
    }, module.bundle.hotData[e] = void 0;
}
module.bundle.Module = I;
module.bundle.hotData = {};
var l = globalThis.browser || globalThis.chrome || null;
function v() {
    return !s.host || s.host === "0.0.0.0" ? "localhost" : s.host;
}
function C() {
    return s.port || location.port;
}
var E = "__plasmo_runtime_script_";
function L(e, t) {
    let { modules: o } = e;
    return o ? !!o[t] : !1;
}
function O(e = C()) {
    let t = v();
    return `${s.secure || location.protocol === "https:" && !/localhost|127.0.0.1|0.0.0.0/.test(t) ? "wss" : "ws"}://${t}:${e}/`;
}
function B(e) {
    typeof e.message == "string" && x("[plasmo/parcel-runtime]: " + e.message);
}
function T(e) {
    if (typeof globalThis.WebSocket > "u") return;
    let t = new WebSocket(O());
    return t.addEventListener("message", async function(o) {
        let r = JSON.parse(o.data);
        if (r.type === "update" && await e(r.assets), r.type === "error") for (let a of r.diagnostics.ansi){
            let w = a.codeframe || a.stack;
            m("[plasmo/parcel-runtime]: " + a.message + `
` + w + `

` + a.hints.join(`
`));
        }
    }), t.addEventListener("error", B), t.addEventListener("open", ()=>{
        b(`[plasmo/parcel-runtime]: Connected to HMR server for ${s.entryFilePath}`);
    }), t.addEventListener("close", ()=>{
        m(`[plasmo/parcel-runtime]: Connection to the HMR server is closed for ${s.entryFilePath}`);
    }), t;
}
var n = "__plasmo-loading__";
function $() {
    let e = globalThis.window?.trustedTypes;
    if (typeof e > "u") return;
    let t = document.querySelector('meta[name="trusted-types"]')?.content?.split(" "), o = t ? t[t?.length - 1] : void 0;
    return typeof e < "u" ? e.createPolicy(o || `trusted-html-${n}`, {
        createHTML: (a)=>a
    }) : void 0;
}
var P = $();
function g() {
    return document.getElementById(n);
}
function f() {
    return !g();
}
function F() {
    let e = document.createElement("div");
    e.id = n;
    let t = `
  <style>
    #${n} {
      background: #f3f3f3;
      color: #333;
      border: 1px solid #333;
      box-shadow: #333 4.7px 4.7px;
    }

    #${n}:hover {
      background: #e3e3e3;
      color: #444;
    }

    @keyframes plasmo-loading-animate-svg-fill {
      0% {
        fill: transparent;
      }
    
      100% {
        fill: #333;
      }
    }

    #${n} .svg-elem-1 {
      animation: plasmo-loading-animate-svg-fill 1.47s cubic-bezier(0.47, 0, 0.745, 0.715) 0.8s both infinite;
    }

    #${n} .svg-elem-2 {
      animation: plasmo-loading-animate-svg-fill 1.47s cubic-bezier(0.47, 0, 0.745, 0.715) 0.9s both infinite;
    }
    
    #${n} .svg-elem-3 {
      animation: plasmo-loading-animate-svg-fill 1.47s cubic-bezier(0.47, 0, 0.745, 0.715) 1s both infinite;
    }

    #${n} .hidden {
      display: none;
    }

  </style>
  
  <svg height="32" width="32" viewBox="0 0 264 354" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M139.221 282.243C154.252 282.243 166.903 294.849 161.338 308.812C159.489 313.454 157.15 317.913 154.347 322.109C146.464 333.909 135.26 343.107 122.151 348.538C109.043 353.969 94.6182 355.39 80.7022 352.621C66.7861 349.852 54.0034 343.018 43.9705 332.983C33.9375 322.947 27.105 310.162 24.3369 296.242C21.5689 282.323 22.9895 267.895 28.4193 254.783C33.8491 241.671 43.0441 230.464 54.8416 222.579C59.0353 219.777 63.4908 217.438 68.1295 215.588C82.0915 210.021 94.6978 222.671 94.6978 237.703L94.6978 255.027C94.6978 270.058 106.883 282.243 121.914 282.243H139.221Z" fill="#333" class="svg-elem-1" ></path>
    <path d="M192.261 142.028C192.261 126.996 204.867 114.346 218.829 119.913C223.468 121.763 227.923 124.102 232.117 126.904C243.915 134.789 253.11 145.996 258.539 159.108C263.969 172.22 265.39 186.648 262.622 200.567C259.854 214.487 253.021 227.272 242.988 237.308C232.955 247.343 220.173 254.177 206.256 256.946C192.34 259.715 177.916 258.294 164.807 252.863C151.699 247.432 140.495 238.234 132.612 226.434C129.808 222.238 127.47 217.779 125.62 213.137C120.056 199.174 132.707 186.568 147.738 186.568L165.044 186.568C180.076 186.568 192.261 174.383 192.261 159.352L192.261 142.028Z" fill="#333" class="svg-elem-2" ></path>
    <path d="M95.6522 164.135C95.6522 179.167 83.2279 191.725 68.8013 187.505C59.5145 184.788 50.6432 180.663 42.5106 175.227C26.7806 164.714 14.5206 149.772 7.28089 132.289C0.041183 114.807 -1.85305 95.5697 1.83772 77.0104C5.52849 58.4511 14.6385 41.4033 28.0157 28.0228C41.393 14.6423 58.4366 5.53006 76.9914 1.83839C95.5461 -1.85329 114.779 0.0414162 132.257 7.2829C149.735 14.5244 164.674 26.7874 175.184 42.5212C180.62 50.6576 184.744 59.5332 187.46 68.8245C191.678 83.2519 179.119 95.6759 164.088 95.6759L122.869 95.6759C107.837 95.6759 95.6522 107.861 95.6522 122.892L95.6522 164.135Z" fill="#333" class="svg-elem-3"></path>
  </svg>
  <span class="hidden">Context Invalidated, Press to Reload</span>
  `;
    return e.innerHTML = P ? P.createHTML(t) : t, e.style.pointerEvents = "none", e.style.position = "fixed", e.style.bottom = "14.7px", e.style.right = "14.7px", e.style.fontFamily = "sans-serif", e.style.display = "flex", e.style.justifyContent = "center", e.style.alignItems = "center", e.style.padding = "14.7px", e.style.gap = "14.7px", e.style.borderRadius = "4.7px", e.style.zIndex = "2147483647", e.style.opacity = "0", e.style.transition = "all 0.47s ease-in-out", e;
}
function N(e) {
    return new Promise((t)=>{
        document.documentElement ? (f() && (document.documentElement.appendChild(e), t()), t()) : globalThis.addEventListener("DOMContentLoaded", ()=>{
            f() && document.documentElement.appendChild(e), t();
        });
    });
}
var k = ()=>{
    let e;
    if (f()) {
        let t = F();
        e = N(t);
    }
    return {
        show: async ({ reloadButton: t = !1 } = {})=>{
            await e;
            let o = g();
            o.style.opacity = "1", t && (o.onclick = (r)=>{
                r.stopPropagation(), globalThis.location.reload();
            }, o.querySelector("span").classList.remove("hidden"), o.style.cursor = "pointer", o.style.pointerEvents = "all");
        },
        hide: async ()=>{
            await e;
            let t = g();
            t.style.opacity = "0";
        }
    };
};
var W = `${E}${module.id}__`, i, A = !1, M = k();
async function h() {
    c("Script Runtime - reloading"), A ? globalThis.location?.reload?.() : M.show({
        reloadButton: !0
    });
}
function R() {
    i?.disconnect(), i = l?.runtime.connect({
        name: W
    }), i.onDisconnect.addListener(()=>{
        h();
    }), i.onMessage.addListener((e)=>{
        e.__plasmo_cs_reload__ && h(), e.__plasmo_cs_active_tab__ && (A = !0);
    });
}
function j() {
    if (l?.runtime) try {
        R(), setInterval(R, 24e3);
    } catch  {
        return;
    }
}
j();
T(async (e)=>{
    c("Script runtime - on updated assets"), e.filter((o)=>o.envHash === s.envHash).some((o)=>L(module.bundle, o.id)) && (M.show(), l?.runtime ? i.postMessage({
        __plasmo_cs_changed__: !0
    }) : setTimeout(()=>{
        h();
    }, 4700));
});

},{}],"8agKO":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "config", ()=>config);
var _storage = require("@plasmohq/storage");
const storage = new (0, _storage.Storage)();
const config = {
    matches: [
        "https://programari.gov.md/en/maeie/appointments*"
    ]
};
console.log("in formfill");
function generateUniqueIdentifier() {
    return crypto.randomUUID();
}
async function getvalue() {
    console.log("inside form page");
    const data = await storage.get("usersdata");
    console.log(data);
    return data;
}
async function clearData() {
    const val = await storage.remove("usersdata");
    console.log(val);
    localStorage.removeItem("usedArrays");
}
async function getUniqueArray() {
    const data = await getvalue();
    // localStorage.setItem('arraysExhausted', 'false');
    if (!data || !Array.isArray(data) || data.length === 0) {
        console.error("Invalid or empty data retrieved.");
        return null;
    }
    let pageIdentifier = sessionStorage.getItem("pageIdentifier");
    if (!pageIdentifier) {
        pageIdentifier = generateUniqueIdentifier();
        sessionStorage.setItem("pageIdentifier", pageIdentifier);
    }
    let usedArrays = JSON.parse(localStorage.getItem("usedArrays")) || [];
    let usedArrays_value = JSON.parse(localStorage.getItem("usedArraysValue")) || [];
    if (usedArrays.length >= data.length) {
        console.error("No more unique arrays available.");
        localStorage.setItem("arraysExhausted", "true");
        localStorage.removeItem("pageIdentifier");
        sessionStorage.removeItem("pageIdentifier");
        await clearData();
        localStorage.removeItem("uniqueArray");
        window.close();
        alert("all values are filled now start again");
    // return null;
    }
    let uniqueArray = null;
    // Find an unused array index
    for(let i = 0; i < data.length; i++)if (!usedArrays.includes(i)) {
        uniqueArray = data[i];
        usedArrays.push(i);
        usedArrays_value.push[data[i]];
        localStorage.setItem("usedArraysValue", JSON.stringify(usedArrays_value));
        localStorage.setItem("usedArrays", JSON.stringify(usedArrays));
        localStorage.setItem(pageIdentifier, JSON.stringify(uniqueArray));
        console.log("Used array index:", i);
        break;
    }
    if (!uniqueArray) {
        console.error("No unused array found.");
        return null;
    }
    console.log("Used arrays:", usedArrays);
    console.log("Unique array:", uniqueArray);
    return uniqueArray;
}
async function finddateandtimeslot(dateValue) {
    setTimeout(()=>{
        let cdcontainer = document.querySelector('div[class="cdk-overlay-container"]');
        console.log("cdcontainer", cdcontainer);
        let cdk_overlay = cdcontainer.querySelector('div > div[id="cdk-overlay-0"]');
        console.log("cdk_overlay", cdk_overlay);
        let menu = cdk_overlay.querySelector('div[role="menu"] > div > div[class*="date-time-picker-wrapper"]');
        console.log(menu);
        let scrollbar = menu.querySelector("mat-calendar > div[cdkmonitorsubtreefocus]");
        console.log(scrollbar);
        let table = scrollbar.querySelector('table[role="grid"] > tbody');
        console.log(table);
        let tr = table.querySelectorAll('tr[role="row"]');
        tr.forEach((row)=>{
            console.log("repeat");
            let alldates = row.querySelectorAll("td > button");
            console.log("alldates", alldates);
            alldates.forEach((button)=>{
                const div = button.querySelector('div[class*="mat-focus-indicator"]');
                console.log(div) // Adjust the selector if necessary
                ;
                if (div && div.textContent.trim() == dateValue) {
                    console.log(div.textContent);
                    button.ariaPressed = "true";
                    button.click();
                    timeSelect(menu);
                    return;
                }
            });
        });
    }, 4000);
}
function timeSelect(menu) {
    let scrollbar = menu.querySelector("ng-scrollbar");
    console.log("scrollbar", scrollbar);
    let mwl_calendar_week = scrollbar.querySelector('mwl-calendar-day-view > mwl-calendar-week-view > div[role="grid"]');
    console.log("mwl_calendar_week", mwl_calendar_week);
    mwldroppable = mwl_calendar_week.querySelector('div[class="cal-time-events"]');
    console.log("mwldroppable", mwldroppable);
    let presenthour = mwldroppable.querySelectorAll('div[class*="cal-hour"]');
    console.log("presenthour", presenthour);
    presenthour.forEach((eachtimeavailcheck)=>{
        let time = eachtimeavailcheck.querySelector('mwl-calendar-week-view-hour-segment > div[class*="time-cell"]');
        console.log(time);
        let badge = time.querySelector('span[class="badge"]');
        if (badge) {
            console.log("badge", badge);
            time.click();
        }
    });
    setTimeout(()=>{
        let main = document.querySelector('main[role="main"] > eap-appointments > div[class*="container"]');
        console.log("main", main);
        let button = main.querySelector('div[class="content"]');
        console.log("buttonforsubmit", button);
        let buttonselect = button.querySelector('div[class="left"]');
        let submit = buttonselect.querySelector("button[mat-raised-button]");
        console.log(submit);
        if (submit) try {
            submit.click();
        // setTimeout(() => {
        // //   alert("form filled successfully")
        //   window.close()
        // }, 20000)
        // Programmatically click the submit button
        } catch (error) {
            console.log("here inside error");
            console.error(error);
            window.close();
        }
        else console.error("Submit button not found in the form.");
    }, 1000);
    return;
}
async function waitForDateValue(founddate) {
    return new Promise((resolve, reject)=>{
        if (founddate) {
            const observer = new MutationObserver((mutationsList, observer)=>{
                for (let mutation of mutationsList)if (mutation.type === "childList") {
                    let checkdateavail = founddate.querySelector("mat-icon");
                    if (checkdateavail) {
                        console.log("mat-icon element found:", checkdateavail);
                        // Extract the inner text value from founddate
                        let dateValue = founddate.innerText.trim();
                        console.log("Date value:", dateValue);
                        // Optionally disconnect the observer after finding the element
                        observer.disconnect();
                        //   slotBooked = true // Set slotBooked to true to stop further processing
                        resolve(dateValue) // Resolve the promise with the date value
                        ;
                        return;
                    }
                }
            });
            observer.observe(founddate, {
                childList: true,
                subtree: true
            });
        } else reject("founddate element is not defined");
    });
}
async function fillsandsubmitsvalue() {
    let pageIdentifier = sessionStorage.getItem("pageIdentifier");
    if (!pageIdentifier) {
        pageIdentifier = generateUniqueIdentifier();
        sessionStorage.setItem("pageIdentifier", pageIdentifier);
    }
    const val = await getUniqueArray();
    if (!val) {
        alert("fill the values in excel sheet and then retry");
        console.error("No unique array found.");
        window.close();
    }
    setTimeout(()=>{
        console.log("here inside timeout");
        let main = document.querySelector('main[role="main"]');
        console.log(main);
        let form = main.querySelector("form");
        const script = document.createElement("script");
        script.textContent = `(function() {
        let form = document.querySelector(
    'form')
     form.setAttribute('novalidate', true);
     form.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent default form submission
        // Additional logic for handling form submission here if needed
     });
    })()`;
        document.body.appendChild(script);
        console.log(form);
        let citizen = form.querySelector('div[class*="eap-card"] > div:nth-child(1)');
        console.log(citizen);
        let checkbox = citizen.querySelector("mat-checkbox > label");
        console.log(checkbox);
        let inputcheckbox = checkbox.querySelector('input[type="checkbox"]');
        console.log(inputcheckbox);
        if (inputcheckbox) inputcheckbox.click();
        let AgreeTerms = form.querySelector('label > span > input[id="mat-checkbox-1-input"]');
        console.log(AgreeTerms);
        if (AgreeTerms) AgreeTerms.click();
        let sectioninput = form.querySelectorAll("section");
        console.log(sectioninput);
        sectioninput.forEach((field, index)=>{
            console.log(index);
            console.log(field);
            if (index == 0) {
                let names = field.querySelector('div[formgroupname="user"]');
                let numandaddress = field.querySelector('div[class="grouped-fields"]');
                console.log(names);
                console.log(numandaddress);
                let labels = names.querySelectorAll("label");
                let rlabels = numandaddress.querySelectorAll("label");
                labels.forEach((label, index)=>{
                    if (label) {
                        console.log(label.innerText);
                        if (label.innerText.includes("First name*")) {
                            let input = label.querySelector("input");
                            console.log(input);
                            input.value = val.Firstname;
                            input.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                        } else if (label.innerText.includes("Last name*")) {
                            let input = label.querySelector("input");
                            console.log(input);
                            input.value = val.Lastname;
                            input.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                        }
                    }
                });
                rlabels.forEach((label, index)=>{
                    if (label) {
                        console.log(label.innerText);
                        if (label.innerText.includes("Passport number*")) {
                            let input = label.querySelector("input");
                            console.log(input);
                            input.value = val.Passportnumber;
                            input.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                        } else if (label.innerText.includes("Residence address")) {
                            let input = label.querySelector("input");
                            console.log(input);
                            input.value = val.Residenceaddress;
                            input.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                        }
                    }
                });
            }
            if (index == 1) {
                console.log("hy");
                let labels = field.querySelectorAll("label");
                labels.forEach((label, index)=>{
                    if (label) {
                        console.log(label.innerText);
                        if (label.innerText.includes("Phone*")) {
                            let input = label.querySelector("input");
                            console.log(input);
                            input.value = val.phone;
                            input.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                        } else if (label.innerText.includes("Email*")) {
                            let input = label.querySelector("input");
                            console.log(input);
                            input.value = val.email;
                            input.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                        }
                    }
                });
            }
            if (index == 2) {
                let insidesection = field.querySelector('div[class*="grouped-fields ng-star-inserted"]');
                console.log(insidesection);
                let labels = insidesection.querySelectorAll("label");
                console.log(labels);
                labels.forEach((label, index)=>{
                    if (index == 0) {
                        let ngselect = label.querySelector("ng-select");
                        let select = ngselect.querySelector('div > div[class="ng-value-container"]');
                        console.log(select);
                        let input = select.querySelector('div[role="combobox"] > input');
                        console.log(input);
                        // let input = select.querySelector('input')
                        // console.log(input)
                        input.value = "Visa";
                        input.focus();
                        input.dispatchEvent(new Event("input", {
                            bubbles: true
                        }));
                        input.dispatchEvent(new Event("change", {
                            bubbles: true
                        }));
                        let enterEvent = new KeyboardEvent("keydown", {
                            bubbles: true,
                            cancelable: true,
                            key: "Enter",
                            keyCode: 13
                        });
                        input.dispatchEvent(enterEvent);
                    } else if (index == 1) {
                        let dateandtime = label.querySelector('div[class*="mat-form-field-wrapper"]');
                        console.log(dateandtime);
                        let clickselect = dateandtime.querySelector("div");
                        console.log("clickselect", clickselect);
                        let click = clickselect.querySelector('div[class*="mat-form-field-infix"]');
                        console.log("click", click);
                        click.click();
                        // document.body.appendChild(script);
                        let checkingavail = document.querySelector('div[class="right"]');
                        console.log(checkingavail);
                        let stickycal = checkingavail.querySelector('div[class*="sticky-calendar"] > eap-services-calendar');
                        console.log(stickycal);
                        let date = stickycal.querySelector('mwl-calendar-month-view > div[role="grid"] > div[class="cal-days"]');
                        console.log(date);
                        // let slotBooked = false
                        let avail = date.querySelectorAll('div[class="ng-star-inserted"]');
                        console.log("avail", avail);
                        avail.forEach((daterow)=>{
                            //   if (slotBooked) return
                            let mwl_calendar = daterow.querySelectorAll('div[role="row"] > mwl-calendar-month-cell');
                            console.log("mwl_calendar", mwl_calendar);
                            mwl_calendar.forEach((calendar)=>{
                                let founddate = calendar.querySelector('div > div[class="date"]');
                                console.log(founddate);
                                let slotBooked = false // Ensure slotBooked is defined outside the function scope
                                ;
                                waitForDateValue(founddate).then(async (dateValue)=>{
                                    // performFurtherOperations(dateValue)
                                    console.log("here");
                                    console.log(dateValue);
                                    slotBooked = true;
                                    await finddateandtimeslot(dateValue);
                                    return;
                                }).catch((error)=>{
                                    console.error(error);
                                });
                                console.log("out on async await");
                            // if (founddate) {
                            //   const observer = new MutationObserver(
                            //     (mutationsList, observer) => {
                            //       for (let mutation of mutationsList) {
                            //         if (slotBooked) return
                            //         if (mutation.type === "childList") {
                            //           let checkdateavail =
                            //             founddate.querySelector("mat-icon")
                            //           if (checkdateavail) {
                            //             console.log(
                            //               "mat-icon element found:",
                            //               checkdateavail
                            //             )
                            //             // Extract the inner text value from founddate
                            //             let dateValue = founddate.innerText.trim()
                            //             console.log("Date value:", dateValue)
                            //             // Optionally disconnect the observer after finding the element
                            //             observer.disconnect()
                            //             slotBooked = true; // Set slotBooked to true to stop further processing
                            //             // break;
                            //             // let input = dateandtime.querySelector("input")
                            //             // console.log(input)
                            //             // const now = new Date()
                            //             // console.log(now)
                            //             // const year = now.getFullYear()
                            //             // const month = (now.getMonth() + 1)
                            //             //   .toString()
                            //             //   .padStart(2, "0")
                            //             // const day = dateValue
                            //             // const formattedDate = `${day}.${month}.${year}`
                            //             // input.value = formattedDate
                            //             // buttonclicked = true
                            //             // slotBooked = true
                            //             // let button =
                            //             //   main.querySelector('div[class="content"] > div[class="left]')
                            //             // console.log(button)
                            //             // const submit = button.querySelector("button")
                            //             // console.log(submit)
                            //             // if (submit) {
                            //             //   try {
                            //             //     submit.click()
                            //             //     setTimeout(() => {
                            //             //       alert("form filled successfully")
                            //             //       window.close()
                            //             //     }, 10000)
                            //             //     // Programmatically click the submit button
                            //             //   } catch (error) {
                            //             //     console.log("here inside error")
                            //             //     console.error(error)
                            //             //     window.close()
                            //             //   }
                            //             // } else {
                            //             //   console.error(
                            //             //     "Submit button not found in the form."
                            //             //   )
                            //             // }
                            //             // this code responsible for requesting the Appointment
                            //             return
                            //           }
                            //         }
                            //       }
                            //     }
                            //   )
                            //   observer.observe(founddate, {
                            //     childList: true,
                            //     subtree: true
                            //   })
                            // }
                            // console.log(dateValue)
                            });
                        });
                    }
                });
            }
        });
        console.log("lets submit the form");
    }, 5000);
}
window.addEventListener("load", ()=>{
    fillsandsubmitsvalue();
    setInterval(()=>{
        window.location.href = "https://programari.gov.md/en/maeie/appointments/69a7a79e-b44c-49de-8e96-0ccfb564f65a";
    }, 20000);
});

},{"@plasmohq/storage":"bt11J","@parcel/transformer-js/src/esmodule-helpers.js":"6dfwG"}],"bt11J":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "BaseStorage", ()=>o);
parcelHelpers.export(exports, "Storage", ()=>g);
var _pify = require("pify");
var _pifyDefault = parcelHelpers.interopDefault(_pify);
var l = ()=>{
    try {
        let e = globalThis.navigator?.userAgent.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
        if (e[1] === "Chrome") return parseInt(e[2]) < 100 || globalThis.chrome.runtime?.getManifest()?.manifest_version === 2;
    } catch  {
        return !1;
    }
    return !1;
};
var o = class {
    #r;
    #e;
    get primaryClient() {
        return this.#e;
    }
    #t;
    get secondaryClient() {
        return this.#t;
    }
    #a;
    get area() {
        return this.#a;
    }
    get hasWebApi() {
        try {
            return typeof window < "u" && !!window.localStorage;
        } catch (e) {
            return console.error(e), !1;
        }
    }
    #s = new Map;
    #i;
    get copiedKeySet() {
        return this.#i;
    }
    isCopied = (e)=>this.hasWebApi && (this.allCopied || this.copiedKeySet.has(e));
    #n = !1;
    get allCopied() {
        return this.#n;
    }
    getExtStorageApi = ()=>globalThis.browser?.storage || globalThis.chrome?.storage;
    get hasExtensionApi() {
        try {
            return !!this.getExtStorageApi();
        } catch (e) {
            return console.error(e), !1;
        }
    }
    isWatchSupported = ()=>this.hasExtensionApi;
    keyNamespace = "";
    isValidKey = (e)=>e.startsWith(this.keyNamespace);
    getNamespacedKey = (e)=>`${this.keyNamespace}${e}`;
    getUnnamespacedKey = (e)=>e.slice(this.keyNamespace.length);
    serde = {
        serializer: JSON.stringify,
        deserializer: JSON.parse
    };
    constructor({ area: e = "sync", allCopied: t = !1, copiedKeyList: s = [], serde: r = {} } = {}){
        this.setCopiedKeySet(s), this.#a = e, this.#n = t, this.serde = {
            ...this.serde,
            ...r
        };
        try {
            this.hasWebApi && (t || s.length > 0) && (this.#t = window.localStorage);
        } catch  {}
        try {
            this.hasExtensionApi && (this.#r = this.getExtStorageApi(), l() ? this.#e = (0, _pifyDefault.default)(this.#r[this.area], {
                exclude: [
                    "getBytesInUse"
                ],
                errorFirst: !1
            }) : this.#e = this.#r[this.area]);
        } catch  {}
    }
    setCopiedKeySet(e) {
        this.#i = new Set(e);
    }
    rawGetAll = ()=>this.#e?.get();
    getAll = async ()=>{
        let e = await this.rawGetAll();
        return Object.entries(e).filter(([t])=>this.isValidKey(t)).reduce((t, [s, r])=>(t[this.getUnnamespacedKey(s)] = r, t), {});
    };
    copy = async (e)=>{
        let t = e === void 0;
        if (!t && !this.copiedKeySet.has(e) || !this.allCopied || !this.hasExtensionApi) return !1;
        let s = this.allCopied ? await this.rawGetAll() : await this.#e.get((t ? [
            ...this.copiedKeySet
        ] : [
            e
        ]).map(this.getNamespacedKey));
        if (!s) return !1;
        let r = !1;
        for(let a in s){
            let i = s[a], n = this.#t?.getItem(a);
            this.#t?.setItem(a, i), r ||= i !== n;
        }
        return r;
    };
    rawGet = async (e)=>this.hasExtensionApi ? (await this.#e.get(e))[e] : this.isCopied(e) ? this.#t?.getItem(e) : null;
    rawSet = async (e, t)=>(this.isCopied(e) && this.#t?.setItem(e, t), this.hasExtensionApi && await this.#e.set({
            [e]: t
        }), null);
    clear = async (e = !1)=>{
        e && this.#t?.clear(), await this.#e.clear();
    };
    rawRemove = async (e)=>{
        this.isCopied(e) && this.#t?.removeItem(e), this.hasExtensionApi && await this.#e.remove(e);
    };
    removeAll = async ()=>{
        let e = await this.getAll(), t = Object.keys(e);
        await Promise.all(t.map(this.remove));
    };
    watch = (e)=>{
        let t = this.isWatchSupported();
        return t && this.#o(e), t;
    };
    #o = (e)=>{
        for(let t in e){
            let s = this.getNamespacedKey(t), r = this.#s.get(s)?.callbackSet || new Set;
            if (r.add(e[t]), r.size > 1) continue;
            let a = (i, n)=>{
                if (n !== this.area || !i[s]) return;
                let h = this.#s.get(s);
                if (!h) throw new Error(`Storage comms does not exist for nsKey: ${s}`);
                Promise.all([
                    this.parseValue(i[s].newValue),
                    this.parseValue(i[s].oldValue)
                ]).then(([p, d])=>{
                    for (let m of h.callbackSet)m({
                        newValue: p,
                        oldValue: d
                    }, n);
                });
            };
            this.#r.onChanged.addListener(a), this.#s.set(s, {
                callbackSet: r,
                listener: a
            });
        }
    };
    unwatch = (e)=>{
        let t = this.isWatchSupported();
        return t && this.#c(e), t;
    };
    #c(e) {
        for(let t in e){
            let s = this.getNamespacedKey(t), r = e[t], a = this.#s.get(s);
            a && (a.callbackSet.delete(r), a.callbackSet.size === 0 && (this.#s.delete(s), this.#r.onChanged.removeListener(a.listener)));
        }
    }
    unwatchAll = ()=>this.#h();
    #h() {
        this.#s.forEach(({ listener: e })=>this.#r.onChanged.removeListener(e)), this.#s.clear();
    }
    async getItem(e) {
        return this.get(e);
    }
    async setItem(e, t) {
        await this.set(e, t);
    }
    async removeItem(e) {
        return this.remove(e);
    }
}, g = class extends o {
    get = async (e)=>{
        let t = this.getNamespacedKey(e), s = await this.rawGet(t);
        return this.parseValue(s);
    };
    set = async (e, t)=>{
        let s = this.getNamespacedKey(e), r = this.serde.serializer(t);
        return this.rawSet(s, r);
    };
    remove = async (e)=>{
        let t = this.getNamespacedKey(e);
        return this.rawRemove(t);
    };
    setNamespace = (e)=>{
        this.keyNamespace = e;
    };
    parseValue = async (e)=>{
        try {
            if (e !== void 0) return this.serde.deserializer(e);
        } catch (t) {
            console.error(t);
        }
    };
};

},{"pify":"lXTmq","@parcel/transformer-js/src/esmodule-helpers.js":"6dfwG"}],"lXTmq":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>pify);
const processFunction = (function_, options, proxy, unwrapped)=>function(...arguments_) {
        const P = options.promiseModule;
        return new P((resolve, reject)=>{
            if (options.multiArgs) arguments_.push((...result)=>{
                if (options.errorFirst) {
                    if (result[0]) reject(result);
                    else {
                        result.shift();
                        resolve(result);
                    }
                } else resolve(result);
            });
            else if (options.errorFirst) arguments_.push((error, result)=>{
                if (error) reject(error);
                else resolve(result);
            });
            else arguments_.push(resolve);
            const self = this === proxy ? unwrapped : this;
            Reflect.apply(function_, self, arguments_);
        });
    };
const filterCache = new WeakMap();
function pify(input, options) {
    options = {
        exclude: [
            /.+(?:Sync|Stream)$/
        ],
        errorFirst: true,
        promiseModule: Promise,
        ...options
    };
    const objectType = typeof input;
    if (!(input !== null && (objectType === "object" || objectType === "function"))) throw new TypeError(`Expected \`input\` to be a \`Function\` or \`Object\`, got \`${input === null ? "null" : objectType}\``);
    const filter = (target, key)=>{
        let cached = filterCache.get(target);
        if (!cached) {
            cached = {};
            filterCache.set(target, cached);
        }
        if (key in cached) return cached[key];
        const match = (pattern)=>typeof pattern === "string" || typeof key === "symbol" ? key === pattern : pattern.test(key);
        const descriptor = Reflect.getOwnPropertyDescriptor(target, key);
        const writableOrConfigurableOwn = descriptor === undefined || descriptor.writable || descriptor.configurable;
        const included = options.include ? options.include.some((element)=>match(element)) : !options.exclude.some((element)=>match(element));
        const shouldFilter = included && writableOrConfigurableOwn;
        cached[key] = shouldFilter;
        return shouldFilter;
    };
    const cache = new WeakMap();
    const proxy = new Proxy(input, {
        apply (target, thisArg, args) {
            const cached = cache.get(target);
            if (cached) return Reflect.apply(cached, thisArg, args);
            const pified = options.excludeMain ? target : processFunction(target, options, proxy, target);
            cache.set(target, pified);
            return Reflect.apply(pified, thisArg, args);
        },
        get (target, key) {
            const property = target[key];
            // eslint-disable-next-line no-use-extend-native/no-use-extend-native
            if (!filter(target, key) || property === Function.prototype[key]) return property;
            const cached = cache.get(property);
            if (cached) return cached;
            if (typeof property === "function") {
                const pified = processFunction(property, options, proxy, target);
                cache.set(property, pified);
                return pified;
            }
            return property;
        }
    });
    return proxy;
}

},{"@parcel/transformer-js/src/esmodule-helpers.js":"6dfwG"}],"6dfwG":[function(require,module,exports) {
exports.interopDefault = function(a) {
    return a && a.__esModule ? a : {
        default: a
    };
};
exports.defineInteropFlag = function(a) {
    Object.defineProperty(a, "__esModule", {
        value: true
    });
};
exports.exportAll = function(source, dest) {
    Object.keys(source).forEach(function(key) {
        if (key === "default" || key === "__esModule" || dest.hasOwnProperty(key)) return;
        Object.defineProperty(dest, key, {
            enumerable: true,
            get: function() {
                return source[key];
            }
        });
    });
    return dest;
};
exports.export = function(dest, destName, get) {
    Object.defineProperty(dest, destName, {
        enumerable: true,
        get: get
    });
};

},{}]},["dJmo0","8agKO"], "8agKO", "parcelRequireef1e")

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUksSUFBRSxPQUFPLFdBQVcsVUFBUSxNQUFJLFdBQVcsUUFBUSxPQUFLLEVBQUU7QUFBQyxJQUFJLElBQUUsSUFBSSxPQUFPLFdBQVcsVUFBUSxNQUFJLFdBQVcsUUFBUSxNQUFJLENBQUM7QUFBRSxJQUFJLElBQUUsSUFBSSxJQUFJLElBQUcsSUFBRSxDQUFBLElBQUcsRUFBRSxJQUFJLElBQUcsSUFBRSxFQUFFLE9BQU8sQ0FBQSxJQUFHLEVBQUUsV0FBVyxTQUFPLEVBQUUsU0FBUyxNQUFNLElBQUksQ0FBQSxJQUFHLEVBQUUsTUFBTSxNQUFNLE9BQU8sQ0FBQyxHQUFFLENBQUMsR0FBRSxFQUFFLEdBQUksQ0FBQSxDQUFDLENBQUMsRUFBRSxHQUFDLEdBQUUsQ0FBQSxHQUFHLENBQUM7QUFBRyxJQUFJLElBQUUsRUFBRSxjQUFhLElBQUUsSUFBSSxFQUFFLGdCQUFjLElBQUksWUFBVSxRQUFPLElBQUU7QUFBSSxJQUFJLElBQUUsQ0FBQyxJQUFFLEVBQUUsRUFBQyxHQUFHLElBQUksUUFBUSxJQUFJLEVBQUUsT0FBTyxJQUFHLFFBQU87QUFBRyxJQUFJLElBQUUsQ0FBQyxHQUFHLElBQUksUUFBUSxNQUFNLHFCQUFrQixPQUFPLElBQUcsUUFBTyxJQUFHLElBQUUsQ0FBQyxHQUFHLElBQUksRUFBRSx3QkFBb0IsSUFBRyxJQUFFLENBQUMsR0FBRyxJQUFJLEVBQUUsd0JBQW9CLElBQUcsSUFBRSxHQUFFLElBQUUsQ0FBQyxHQUFHLElBQUksT0FBSyxFQUFFLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxLQUFJO0FBQUcsSUFBSSxJQUFFO0lBQUMsbUJBQWtCO0lBQUssZ0JBQWU7SUFBTSxXQUFVO0lBQU0sWUFBVztRQUFDO0tBQWlCO0lBQUMsUUFBTztJQUFZLFFBQU87SUFBSyxpQkFBZ0I7SUFBb0YsWUFBVztJQUFtQixXQUFVO0lBQW1CLFdBQVU7SUFBUSxVQUFTO0lBQU0sY0FBYTtBQUFJO0FBQUUsT0FBTyxPQUFPLGdCQUFjLEVBQUU7QUFBUyxXQUFXLFVBQVE7SUFBQyxNQUFLLEVBQUU7SUFBQyxLQUFJO1FBQUMsU0FBUSxFQUFFO0lBQU87QUFBQztBQUFFLElBQUksSUFBRSxPQUFPLE9BQU87QUFBTyxTQUFTLEVBQUUsQ0FBQztJQUFFLEVBQUUsS0FBSyxJQUFJLEVBQUMsSUFBRyxJQUFJLENBQUMsTUFBSTtRQUFDLE1BQUssT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFFO1FBQUMsa0JBQWlCLEVBQUU7UUFBQyxtQkFBa0IsRUFBRTtRQUFDLFFBQU8sU0FBUyxDQUFDO1lBQUUsSUFBSSxDQUFDLGlCQUFpQixLQUFLLEtBQUcsWUFBVztRQUFFO1FBQUUsU0FBUSxTQUFTLENBQUM7WUFBRSxJQUFJLENBQUMsa0JBQWtCLEtBQUs7UUFBRTtJQUFDLEdBQUUsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFFLEdBQUMsS0FBSztBQUFDO0FBQUMsT0FBTyxPQUFPLFNBQU87QUFBRSxPQUFPLE9BQU8sVUFBUSxDQUFDO0FBQUUsSUFBSSxJQUFFLFdBQVcsV0FBUyxXQUFXLFVBQVE7QUFBSyxTQUFTO0lBQUksT0FBTSxDQUFDLEVBQUUsUUFBTSxFQUFFLFNBQU8sWUFBVSxjQUFZLEVBQUU7QUFBSTtBQUFDLFNBQVM7SUFBSSxPQUFPLEVBQUUsUUFBTSxTQUFTO0FBQUk7QUFBQyxJQUFJLElBQUU7QUFBMkIsU0FBUyxFQUFFLENBQUMsRUFBQyxDQUFDO0lBQUUsSUFBRyxFQUFDLFNBQVEsQ0FBQyxFQUFDLEdBQUM7SUFBRSxPQUFPLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUMsQ0FBQztBQUFDO0FBQUMsU0FBUyxFQUFFLElBQUUsR0FBRztJQUFFLElBQUksSUFBRTtJQUFJLE9BQU0sQ0FBQyxFQUFFLEVBQUUsVUFBUSxTQUFTLGFBQVcsWUFBVSxDQUFDLDhCQUE4QixLQUFLLEtBQUcsUUFBTSxLQUFLLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUFBO0FBQUMsU0FBUyxFQUFFLENBQUM7SUFBRSxPQUFPLEVBQUUsV0FBUyxZQUFVLEVBQUUsOEJBQTRCLEVBQUU7QUFBUTtBQUFDLFNBQVMsRUFBRSxDQUFDO0lBQUUsSUFBRyxPQUFPLFdBQVcsWUFBVSxLQUFJO0lBQU8sSUFBSSxJQUFFLElBQUksVUFBVTtJQUFLLE9BQU8sRUFBRSxpQkFBaUIsV0FBVSxlQUFlLENBQUM7UUFBRSxJQUFJLElBQUUsS0FBSyxNQUFNLEVBQUU7UUFBTSxJQUFHLEVBQUUsU0FBTyxZQUFVLE1BQU0sRUFBRSxFQUFFLFNBQVEsRUFBRSxTQUFPLFNBQVEsS0FBSSxJQUFJLEtBQUssRUFBRSxZQUFZLEtBQUs7WUFBQyxJQUFJLElBQUUsRUFBRSxhQUFXLEVBQUU7WUFBTSxFQUFFLDhCQUE0QixFQUFFLFVBQVEsQ0FBQztBQUN6a0UsQ0FBQyxHQUFDLElBQUUsQ0FBQzs7QUFFTCxDQUFDLEdBQUMsRUFBRSxNQUFNLEtBQUssQ0FBQztBQUNoQixDQUFDO1FBQUU7SUFBQyxJQUFHLEVBQUUsaUJBQWlCLFNBQVEsSUFBRyxFQUFFLGlCQUFpQixRQUFPO1FBQUssRUFBRSxDQUFDLHFEQUFxRCxFQUFFLEVBQUUsY0FBYyxDQUFDO0lBQUMsSUFBRyxFQUFFLGlCQUFpQixTQUFRO1FBQUssRUFBRSxDQUFDLG9FQUFvRSxFQUFFLEVBQUUsY0FBYyxDQUFDO0lBQUMsSUFBRztBQUFDO0FBQUMsSUFBSSxJQUFFO0FBQXFCLFNBQVM7SUFBSSxJQUFJLElBQUUsV0FBVyxRQUFRO0lBQWEsSUFBRyxPQUFPLElBQUUsS0FBSTtJQUFPLElBQUksSUFBRSxTQUFTLGNBQWMsK0JBQStCLFNBQVMsTUFBTSxNQUFLLElBQUUsSUFBRSxDQUFDLENBQUMsR0FBRyxTQUFPLEVBQUUsR0FBQyxLQUFLO0lBQUUsT0FBTyxPQUFPLElBQUUsTUFBSSxFQUFFLGFBQWEsS0FBRyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsRUFBQztRQUFDLFlBQVcsQ0FBQSxJQUFHO0lBQUMsS0FBRyxLQUFLO0FBQUM7QUFBQyxJQUFJLElBQUU7QUFBSSxTQUFTO0lBQUksT0FBTyxTQUFTLGVBQWU7QUFBRTtBQUFDLFNBQVM7SUFBSSxPQUFNLENBQUM7QUFBRztBQUFDLFNBQVM7SUFBSSxJQUFJLElBQUUsU0FBUyxjQUFjO0lBQU8sRUFBRSxLQUFHO0lBQUUsSUFBSSxJQUFFLENBQUM7O0tBRWpzQixFQUFFLEVBQUU7Ozs7Ozs7S0FPSixFQUFFLEVBQUU7Ozs7Ozs7Ozs7Ozs7OztLQWVKLEVBQUUsRUFBRTs7OztLQUlKLEVBQUUsRUFBRTs7OztLQUlKLEVBQUUsRUFBRTs7OztLQUlKLEVBQUUsRUFBRTs7Ozs7Ozs7Ozs7O0VBWVAsQ0FBQztJQUFDLE9BQU8sRUFBRSxZQUFVLElBQUUsRUFBRSxXQUFXLEtBQUcsR0FBRSxFQUFFLE1BQU0sZ0JBQWMsUUFBTyxFQUFFLE1BQU0sV0FBUyxTQUFRLEVBQUUsTUFBTSxTQUFPLFVBQVMsRUFBRSxNQUFNLFFBQU0sVUFBUyxFQUFFLE1BQU0sYUFBVyxjQUFhLEVBQUUsTUFBTSxVQUFRLFFBQU8sRUFBRSxNQUFNLGlCQUFlLFVBQVMsRUFBRSxNQUFNLGFBQVcsVUFBUyxFQUFFLE1BQU0sVUFBUSxVQUFTLEVBQUUsTUFBTSxNQUFJLFVBQVMsRUFBRSxNQUFNLGVBQWEsU0FBUSxFQUFFLE1BQU0sU0FBTyxjQUFhLEVBQUUsTUFBTSxVQUFRLEtBQUksRUFBRSxNQUFNLGFBQVcseUJBQXdCO0FBQUM7QUFBQyxTQUFTLEVBQUUsQ0FBQztJQUFFLE9BQU8sSUFBSSxRQUFRLENBQUE7UUFBSSxTQUFTLGtCQUFpQixDQUFBLE9BQU0sQ0FBQSxTQUFTLGdCQUFnQixZQUFZLElBQUcsR0FBRSxHQUFHLEdBQUUsSUFBRyxXQUFXLGlCQUFpQixvQkFBbUI7WUFBSyxPQUFLLFNBQVMsZ0JBQWdCLFlBQVksSUFBRztRQUFHO0lBQUU7QUFBRTtBQUFDLElBQUksSUFBRTtJQUFLLElBQUk7SUFBRSxJQUFHLEtBQUk7UUFBQyxJQUFJLElBQUU7UUFBSSxJQUFFLEVBQUU7SUFBRTtJQUFDLE9BQU07UUFBQyxNQUFLLE9BQU0sRUFBQyxjQUFhLElBQUUsQ0FBQyxDQUFDLEVBQUMsR0FBQyxDQUFDLENBQUM7WUFBSSxNQUFNO1lBQUUsSUFBSSxJQUFFO1lBQUksRUFBRSxNQUFNLFVBQVEsS0FBSSxLQUFJLENBQUEsRUFBRSxVQUFRLENBQUE7Z0JBQUksRUFBRSxtQkFBa0IsV0FBVyxTQUFTO1lBQVEsR0FBRSxFQUFFLGNBQWMsUUFBUSxVQUFVLE9BQU8sV0FBVSxFQUFFLE1BQU0sU0FBTyxXQUFVLEVBQUUsTUFBTSxnQkFBYyxLQUFJO1FBQUU7UUFBRSxNQUFLO1lBQVUsTUFBTTtZQUFFLElBQUksSUFBRTtZQUFJLEVBQUUsTUFBTSxVQUFRO1FBQUc7SUFBQztBQUFDO0FBQUUsSUFBSSxJQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsT0FBTyxHQUFHLEVBQUUsQ0FBQyxFQUFDLEdBQUUsSUFBRSxDQUFDLEdBQUUsSUFBRTtBQUFJLGVBQWU7SUFBSSxFQUFFLCtCQUE4QixJQUFFLFdBQVcsVUFBVSxhQUFXLEVBQUUsS0FBSztRQUFDLGNBQWEsQ0FBQztJQUFDO0FBQUU7QUFBQyxTQUFTO0lBQUksR0FBRyxjQUFhLElBQUUsR0FBRyxRQUFRLFFBQVE7UUFBQyxNQUFLO0lBQUMsSUFBRyxFQUFFLGFBQWEsWUFBWTtRQUFLO0lBQUcsSUFBRyxFQUFFLFVBQVUsWUFBWSxDQUFBO1FBQUksRUFBRSx3QkFBc0IsS0FBSSxFQUFFLDRCQUEyQixDQUFBLElBQUUsQ0FBQyxDQUFBO0lBQUU7QUFBRTtBQUFDLFNBQVM7SUFBSSxJQUFHLEdBQUcsU0FBUSxJQUFHO1FBQUMsS0FBSSxZQUFZLEdBQUU7SUFBSyxFQUFDLE9BQUs7UUFBQztJQUFNO0FBQUM7QUFBQztBQUFJLEVBQUUsT0FBTTtJQUFJLEVBQUUsdUNBQXNDLEVBQUUsT0FBTyxDQUFBLElBQUcsRUFBRSxZQUFVLEVBQUUsU0FBUyxLQUFLLENBQUEsSUFBRyxFQUFFLE9BQU8sUUFBTyxFQUFFLFFBQU8sQ0FBQSxFQUFFLFFBQU8sR0FBRyxVQUFRLEVBQUUsWUFBWTtRQUFDLHVCQUFzQixDQUFDO0lBQUMsS0FBRyxXQUFXO1FBQUs7SUFBRyxHQUFFLEtBQUk7QUFBRTs7Ozs7NENDaERobEQ7QUFKYjtBQUVBLE1BQU0sVUFBVSxJQUFJLENBQUEsR0FBQSxnQkFBTTtBQUVuQixNQUFNLFNBQVM7SUFDcEIsU0FBUztRQUFDO0tBQW1EO0FBRS9EO0FBRUEsUUFBUSxJQUFJO0FBRVosU0FBUztJQUNQLE9BQU8sT0FBTztBQUNoQjtBQUVBLGVBQWU7SUFDYixRQUFRLElBQUk7SUFDWixNQUFNLE9BQU8sTUFBTSxRQUFRLElBQUk7SUFDL0IsUUFBUSxJQUFJO0lBQ1osT0FBTztBQUNUO0FBRUEsZUFBZTtJQUNiLE1BQU0sTUFBTSxNQUFNLFFBQVEsT0FBTztJQUNqQyxRQUFRLElBQUk7SUFDWixhQUFhLFdBQVc7QUFDMUI7QUFFQSxlQUFlO0lBQ2IsTUFBTSxPQUFPLE1BQU07SUFDbkIsb0RBQW9EO0lBQ3BELElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxRQUFRLFNBQVMsS0FBSyxXQUFXLEdBQUc7UUFDdEQsUUFBUSxNQUFNO1FBQ2QsT0FBTztJQUNUO0lBRUEsSUFBSSxpQkFBaUIsZUFBZSxRQUFRO0lBQzVDLElBQUksQ0FBQyxnQkFBZ0I7UUFDbkIsaUJBQWlCO1FBQ2pCLGVBQWUsUUFBUSxrQkFBa0I7SUFDM0M7SUFFQSxJQUFJLGFBQWEsS0FBSyxNQUFNLGFBQWEsUUFBUSxrQkFBa0IsRUFBRTtJQUNyRSxJQUFJLG1CQUNGLEtBQUssTUFBTSxhQUFhLFFBQVEsdUJBQXVCLEVBQUU7SUFFM0QsSUFBSSxXQUFXLFVBQVUsS0FBSyxRQUFRO1FBQ3BDLFFBQVEsTUFBTTtRQUNkLGFBQWEsUUFBUSxtQkFBbUI7UUFDeEMsYUFBYSxXQUFXO1FBQ3hCLGVBQWUsV0FBVztRQUMxQixNQUFNO1FBRU4sYUFBYSxXQUFXO1FBQ3hCLE9BQU87UUFDUCxNQUFNO0lBRU4sZUFBZTtJQUNqQjtJQUVBLElBQUksY0FBYztJQUVsQiw2QkFBNkI7SUFDN0IsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxJQUMvQixJQUFJLENBQUMsV0FBVyxTQUFTLElBQUk7UUFDM0IsY0FBYyxJQUFJLENBQUMsRUFBRTtRQUNyQixXQUFXLEtBQUs7UUFDaEIsaUJBQWlCLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO1FBQzlCLGFBQWEsUUFBUSxtQkFBbUIsS0FBSyxVQUFVO1FBQ3ZELGFBQWEsUUFBUSxjQUFjLEtBQUssVUFBVTtRQUNsRCxhQUFhLFFBQVEsZ0JBQWdCLEtBQUssVUFBVTtRQUNwRCxRQUFRLElBQUkscUJBQXFCO1FBQ2pDO0lBQ0Y7SUFHRixJQUFJLENBQUMsYUFBYTtRQUNoQixRQUFRLE1BQU07UUFDZCxPQUFPO0lBQ1Q7SUFFQSxRQUFRLElBQUksZ0JBQWdCO0lBQzVCLFFBQVEsSUFBSSxpQkFBaUI7SUFDN0IsT0FBTztBQUNUO0FBRUEsZUFBZSxvQkFBb0IsU0FBUztJQUMxQyxXQUFXO1FBQ1QsSUFBSSxjQUFjLFNBQVMsY0FDekI7UUFFRixRQUFRLElBQUksZUFBZTtRQUUzQixJQUFJLGNBQWMsWUFBWSxjQUFjO1FBQzVDLFFBQVEsSUFBSSxlQUFlO1FBRTNCLElBQUksT0FBTyxZQUFZLGNBQ3JCO1FBRUYsUUFBUSxJQUFJO1FBRVosSUFBSSxZQUFZLEtBQUssY0FDbkI7UUFFRixRQUFRLElBQUk7UUFFWixJQUFJLFFBQVEsVUFBVSxjQUFjO1FBQ3BDLFFBQVEsSUFBSTtRQUVaLElBQUksS0FBSyxNQUFNLGlCQUFpQjtRQUVoQyxHQUFHLFFBQVEsQ0FBQztZQUNWLFFBQVEsSUFBSTtZQUNaLElBQUksV0FBVyxJQUFJLGlCQUFpQjtZQUNwQyxRQUFRLElBQUksWUFBWTtZQUN4QixTQUFTLFFBQVEsQ0FBQztnQkFDaEIsTUFBTSxNQUFNLE9BQU8sY0FBYztnQkFDakMsUUFBUSxJQUFJLEtBQUssbUNBQW1DOztnQkFDcEQsSUFBSSxPQUFPLElBQUksWUFBWSxVQUFVLFdBQVc7b0JBQzlDLFFBQVEsSUFBSSxJQUFJO29CQUVoQixPQUFPLGNBQWM7b0JBQ3JCLE9BQU87b0JBQ1AsV0FBVztvQkFDWDtnQkFDRjtZQUNGO1FBQ0Y7SUFDRixHQUFHO0FBQ0w7QUFFQSxTQUFTLFdBQVcsSUFBSTtJQUN0QixJQUFJLFlBQVksS0FBSyxjQUFjO0lBQ25DLFFBQVEsSUFBSSxhQUFhO0lBQ3pCLElBQUksb0JBQW9CLFVBQVUsY0FDaEM7SUFFRixRQUFRLElBQUkscUJBQXFCO0lBRWpDLGVBQWUsa0JBQWtCLGNBQWM7SUFDL0MsUUFBUSxJQUFJLGdCQUFnQjtJQUU1QixJQUFJLGNBQWMsYUFBYSxpQkFBaUI7SUFFaEQsUUFBUSxJQUFJLGVBQWU7SUFDM0IsWUFBWSxRQUFRLENBQUM7UUFDbkIsSUFBSSxPQUFPLG1CQUFtQixjQUM1QjtRQUVGLFFBQVEsSUFBSTtRQUVaLElBQUksUUFBUSxLQUFLLGNBQWM7UUFDL0IsSUFBRyxPQUFPO1lBQ1YsUUFBUSxJQUFJLFNBQVM7WUFDckIsS0FBSztRQUNMO0lBQ0Y7SUFFQSxXQUFXO1FBQ1QsSUFBSSxPQUFPLFNBQVMsY0FBYztRQUNsQyxRQUFRLElBQUksUUFBUTtRQUNwQixJQUFJLFNBQVMsS0FBSyxjQUFjO1FBQ2hDLFFBQVEsSUFBSSxtQkFBbUI7UUFDL0IsSUFBSSxlQUFlLE9BQU8sY0FBYztRQUN4QyxJQUFJLFNBQVMsYUFBYSxjQUFjO1FBQ3hDLFFBQVEsSUFBSTtRQUNaLElBQUksUUFDRixJQUFJO1lBQ0YsT0FBTztRQUNQLHFCQUFxQjtRQUNyQix5Q0FBeUM7UUFDekMsbUJBQW1CO1FBQ25CLFlBQVk7UUFDWiwyQ0FBMkM7UUFDN0MsRUFBRSxPQUFPLE9BQU87WUFDZCxRQUFRLElBQUk7WUFDWixRQUFRLE1BQU07WUFDZCxPQUFPO1FBQ1Q7YUFFQSxRQUFRLE1BQU07SUFFbEIsR0FBRztJQUNIO0FBQ0Y7QUFFQSxlQUFlLGlCQUFpQixTQUFTO0lBQ3ZDLE9BQU8sSUFBSSxRQUFRLENBQUMsU0FBUztRQUMzQixJQUFJLFdBQVc7WUFDYixNQUFNLFdBQVcsSUFBSSxpQkFBaUIsQ0FBQyxlQUFlO2dCQUNwRCxLQUFLLElBQUksWUFBWSxjQUNuQixJQUFJLFNBQVMsU0FBUyxhQUFhO29CQUNqQyxJQUFJLGlCQUFpQixVQUFVLGNBQWM7b0JBQzdDLElBQUksZ0JBQWdCO3dCQUNsQixRQUFRLElBQUksMkJBQTJCO3dCQUN2Qyw4Q0FBOEM7d0JBQzlDLElBQUksWUFBWSxVQUFVLFVBQVU7d0JBQ3BDLFFBQVEsSUFBSSxlQUFlO3dCQUMzQiwrREFBK0Q7d0JBQy9ELFNBQVM7d0JBQ1QsMkVBQTJFO3dCQUMzRSxRQUFRLFdBQVcsMENBQTBDOzt3QkFDN0Q7b0JBQ0Y7Z0JBQ0Y7WUFFSjtZQUVBLFNBQVMsUUFBUSxXQUFXO2dCQUMxQixXQUFXO2dCQUNYLFNBQVM7WUFDWDtRQUNGLE9BQ0UsT0FBTztJQUVYO0FBQ0Y7QUFFQSxlQUFlO0lBQ2IsSUFBSSxpQkFBaUIsZUFBZSxRQUFRO0lBRTVDLElBQUksQ0FBQyxnQkFBZ0I7UUFDbkIsaUJBQWlCO1FBQ2pCLGVBQWUsUUFBUSxrQkFBa0I7SUFDM0M7SUFFQSxNQUFNLE1BQU0sTUFBTTtJQUNsQixJQUFJLENBQUMsS0FBSztRQUNSLE1BQU07UUFDTixRQUFRLE1BQU07UUFDZCxPQUFPO0lBQ1Q7SUFFQSxXQUFXO1FBQ1QsUUFBUSxJQUFJO1FBRVosSUFBSSxPQUFPLFNBQVMsY0FBYztRQUNsQyxRQUFRLElBQUk7UUFDWixJQUFJLE9BQU8sS0FBSyxjQUFjO1FBRTlCLE1BQU0sU0FBUyxTQUFTLGNBQWM7UUFDdEMsT0FBTyxjQUFjLENBQUM7Ozs7Ozs7O1FBUWxCLENBQUM7UUFDTCxTQUFTLEtBQUssWUFBWTtRQUUxQixRQUFRLElBQUk7UUFDWixJQUFJLFVBQVUsS0FBSyxjQUNqQjtRQUVGLFFBQVEsSUFBSTtRQUNaLElBQUksV0FBVyxRQUFRLGNBQWM7UUFDckMsUUFBUSxJQUFJO1FBQ1osSUFBSSxnQkFBZ0IsU0FBUyxjQUFjO1FBQzNDLFFBQVEsSUFBSTtRQUNaLElBQUksZUFDRixjQUFjO1FBS2hCLElBQUksYUFBYSxLQUFLLGNBQ3BCO1FBRUYsUUFBUSxJQUFJO1FBQ1osSUFBSSxZQUNGLFdBQVc7UUFHYixJQUFJLGVBQWUsS0FBSyxpQkFBaUI7UUFDekMsUUFBUSxJQUFJO1FBRVosYUFBYSxRQUFRLENBQUMsT0FBTztZQUMzQixRQUFRLElBQUk7WUFDWixRQUFRLElBQUk7WUFDWixJQUFJLFNBQVMsR0FBRztnQkFDZCxJQUFJLFFBQVEsTUFBTSxjQUFjO2dCQUNoQyxJQUFJLGdCQUFnQixNQUFNLGNBQWM7Z0JBQ3hDLFFBQVEsSUFBSTtnQkFDWixRQUFRLElBQUk7Z0JBQ1osSUFBSSxTQUFTLE1BQU0saUJBQWlCO2dCQUNwQyxJQUFJLFVBQVUsY0FBYyxpQkFBaUI7Z0JBQzdDLE9BQU8sUUFBUSxDQUFDLE9BQU87b0JBQ3JCLElBQUksT0FBTzt3QkFDVCxRQUFRLElBQUksTUFBTTt3QkFDbEIsSUFBSSxNQUFNLFVBQVUsU0FBUyxnQkFBZ0I7NEJBQzNDLElBQUksUUFBUSxNQUFNLGNBQWM7NEJBRWhDLFFBQVEsSUFBSTs0QkFDWixNQUFNLFFBQVMsSUFBSTs0QkFDbkIsTUFBTSxjQUFjLElBQUksTUFBTSxTQUFTO2dDQUFFLFNBQVM7NEJBQUs7NEJBQ3ZELE1BQU0sY0FBYyxJQUFJLE1BQU0sVUFBVTtnQ0FBRSxTQUFTOzRCQUFLO3dCQUMxRCxPQUFPLElBQUksTUFBTSxVQUFVLFNBQVMsZUFBZTs0QkFDakQsSUFBSSxRQUFRLE1BQU0sY0FBYzs0QkFFaEMsUUFBUSxJQUFJOzRCQUNaLE1BQU0sUUFBUSxJQUFJOzRCQUVsQixNQUFNLGNBQWMsSUFBSSxNQUFNLFNBQVM7Z0NBQUUsU0FBUzs0QkFBSzs0QkFDdkQsTUFBTSxjQUFjLElBQUksTUFBTSxVQUFVO2dDQUFFLFNBQVM7NEJBQUs7d0JBQzFEO29CQUNGO2dCQUNGO2dCQUVBLFFBQVEsUUFBUSxDQUFDLE9BQU87b0JBQ3RCLElBQUksT0FBTzt3QkFDVCxRQUFRLElBQUksTUFBTTt3QkFDbEIsSUFBSSxNQUFNLFVBQVUsU0FBUyxxQkFBcUI7NEJBQ2hELElBQUksUUFBUSxNQUFNLGNBQWM7NEJBRWhDLFFBQVEsSUFBSTs0QkFDWixNQUFNLFFBQVEsSUFBSTs0QkFFbEIsTUFBTSxjQUFjLElBQUksTUFBTSxTQUFTO2dDQUFFLFNBQVM7NEJBQUs7NEJBQ3ZELE1BQU0sY0FBYyxJQUFJLE1BQU0sVUFBVTtnQ0FBRSxTQUFTOzRCQUFLO3dCQUMxRCxPQUFPLElBQUksTUFBTSxVQUFVLFNBQVMsc0JBQXNCOzRCQUN4RCxJQUFJLFFBQVEsTUFBTSxjQUFjOzRCQUVoQyxRQUFRLElBQUk7NEJBQ1osTUFBTSxRQUFRLElBQUk7NEJBRWxCLE1BQU0sY0FBYyxJQUFJLE1BQU0sU0FBUztnQ0FBRSxTQUFTOzRCQUFLOzRCQUN2RCxNQUFNLGNBQWMsSUFBSSxNQUFNLFVBQVU7Z0NBQUUsU0FBUzs0QkFBSzt3QkFDMUQ7b0JBQ0Y7Z0JBQ0Y7WUFDRjtZQUVBLElBQUksU0FBUyxHQUFHO2dCQUNkLFFBQVEsSUFBSTtnQkFDWixJQUFJLFNBQVMsTUFBTSxpQkFBaUI7Z0JBQ3BDLE9BQU8sUUFBUSxDQUFDLE9BQU87b0JBQ3JCLElBQUksT0FBTzt3QkFDVCxRQUFRLElBQUksTUFBTTt3QkFDbEIsSUFBSSxNQUFNLFVBQVUsU0FBUyxXQUFXOzRCQUN0QyxJQUFJLFFBQVEsTUFBTSxjQUFjOzRCQUVoQyxRQUFRLElBQUk7NEJBQ1osTUFBTSxRQUFRLElBQUk7NEJBRWxCLE1BQU0sY0FBYyxJQUFJLE1BQU0sU0FBUztnQ0FBRSxTQUFTOzRCQUFLOzRCQUN2RCxNQUFNLGNBQWMsSUFBSSxNQUFNLFVBQVU7Z0NBQUUsU0FBUzs0QkFBSzt3QkFDMUQsT0FBTyxJQUFJLE1BQU0sVUFBVSxTQUFTLFdBQVc7NEJBQzdDLElBQUksUUFBUSxNQUFNLGNBQWM7NEJBRWhDLFFBQVEsSUFBSTs0QkFDWixNQUFNLFFBQVEsSUFBSTs0QkFFbEIsTUFBTSxjQUFjLElBQUksTUFBTSxTQUFTO2dDQUFFLFNBQVM7NEJBQUs7NEJBQ3ZELE1BQU0sY0FBYyxJQUFJLE1BQU0sVUFBVTtnQ0FBRSxTQUFTOzRCQUFLO3dCQUMxRDtvQkFDRjtnQkFDRjtZQUNGO1lBRUEsSUFBSSxTQUFTLEdBQUc7Z0JBQ2QsSUFBSSxnQkFBZ0IsTUFBTSxjQUN4QjtnQkFFRixRQUFRLElBQUk7Z0JBRVosSUFBSSxTQUFTLGNBQWMsaUJBQWlCO2dCQUM1QyxRQUFRLElBQUk7Z0JBRVosT0FBTyxRQUFRLENBQUMsT0FBTztvQkFDckIsSUFBSSxTQUFTLEdBQUc7d0JBQ2QsSUFBSSxXQUFXLE1BQU0sY0FBYzt3QkFDbkMsSUFBSSxTQUFTLFNBQVMsY0FDcEI7d0JBRUYsUUFBUSxJQUFJO3dCQUNaLElBQUksUUFBUSxPQUFPLGNBQWM7d0JBQ2pDLFFBQVEsSUFBSTt3QkFDWiw0Q0FBNEM7d0JBQzVDLHFCQUFxQjt3QkFDckIsTUFBTSxRQUFRO3dCQUNkLE1BQU07d0JBRU4sTUFBTSxjQUFjLElBQUksTUFBTSxTQUFTOzRCQUFFLFNBQVM7d0JBQUs7d0JBQ3ZELE1BQU0sY0FBYyxJQUFJLE1BQU0sVUFBVTs0QkFBRSxTQUFTO3dCQUFLO3dCQUV4RCxJQUFJLGFBQWEsSUFBSSxjQUFjLFdBQVc7NEJBQzVDLFNBQVM7NEJBQ1QsWUFBWTs0QkFDWixLQUFLOzRCQUNMLFNBQVM7d0JBQ1g7d0JBQ0EsTUFBTSxjQUFjO29CQUN0QixPQUFPLElBQUksU0FBUyxHQUFHO3dCQUNyQixJQUFJLGNBQWMsTUFBTSxjQUN0Qjt3QkFFRixRQUFRLElBQUk7d0JBRVosSUFBSSxjQUFjLFlBQVksY0FBYzt3QkFDNUMsUUFBUSxJQUFJLGVBQWU7d0JBQzNCLElBQUksUUFBUSxZQUFZLGNBQ3RCO3dCQUVGLFFBQVEsSUFBSSxTQUFTO3dCQUNyQixNQUFNO3dCQUVOLHFDQUFxQzt3QkFFckMsSUFBSSxnQkFBZ0IsU0FBUyxjQUFjO3dCQUMzQyxRQUFRLElBQUk7d0JBQ1osSUFBSSxZQUFZLGNBQWMsY0FDNUI7d0JBRUYsUUFBUSxJQUFJO3dCQUNaLElBQUksT0FBTyxVQUFVLGNBQ25CO3dCQUVGLFFBQVEsSUFBSTt3QkFDWix5QkFBeUI7d0JBQ3pCLElBQUksUUFBUSxLQUFLLGlCQUFpQjt3QkFDbEMsUUFBUSxJQUFJLFNBQVM7d0JBQ3JCLE1BQU0sUUFBUSxDQUFDOzRCQUNiLDJCQUEyQjs0QkFDM0IsSUFBSSxlQUFlLFFBQVEsaUJBQ3pCOzRCQUVGLFFBQVEsSUFBSSxnQkFBZ0I7NEJBQzVCLGFBQWEsUUFBUSxDQUFDO2dDQUNwQixJQUFJLFlBQVksU0FBUyxjQUN2QjtnQ0FFRixRQUFRLElBQUk7Z0NBQ1osSUFBSSxhQUFhLE1BQU0sMERBQTBEOztnQ0FFakYsaUJBQWlCLFdBQ2QsS0FBSyxPQUFPO29DQUNYLHNDQUFzQztvQ0FDdEMsUUFBUSxJQUFJO29DQUNaLFFBQVEsSUFBSTtvQ0FDWixhQUFhO29DQUNiLE1BQU0sb0JBQW9CO29DQUUxQjtnQ0FDRixHQUNDLE1BQU0sQ0FBQztvQ0FDTixRQUFRLE1BQU07Z0NBQ2hCO2dDQUVGLFFBQVEsSUFBSTs0QkFDWixtQkFBbUI7NEJBQ25CLDJDQUEyQzs0QkFDM0MscUNBQXFDOzRCQUNyQyw4Q0FBOEM7NEJBQzlDLGlDQUFpQzs0QkFDakMsK0NBQStDOzRCQUMvQyxpQ0FBaUM7NEJBQ2pDLGtEQUFrRDs0QkFDbEQsa0NBQWtDOzRCQUNsQywyQkFBMkI7NEJBQzNCLDJDQUEyQzs0QkFDM0MsK0JBQStCOzRCQUMvQixnQkFBZ0I7NEJBQ2hCLDZEQUE2RDs0QkFDN0QseURBQXlEOzRCQUN6RCxvREFBb0Q7NEJBQ3BELDhFQUE4RTs0QkFDOUUsb0NBQW9DOzRCQUNwQyxzRkFBc0Y7NEJBQ3RGLHdCQUF3Qjs0QkFDeEIsZ0VBQWdFOzRCQUNoRSxvQ0FBb0M7NEJBQ3BDLHdDQUF3Qzs0QkFDeEMsa0NBQWtDOzRCQUNsQyxnREFBZ0Q7NEJBQ2hELG9EQUFvRDs0QkFDcEQsK0JBQStCOzRCQUMvQixxQ0FBcUM7NEJBQ3JDLHVDQUF1Qzs0QkFDdkMsaUVBQWlFOzRCQUVqRSw2Q0FBNkM7NEJBQzdDLHNDQUFzQzs0QkFDdEMsbUNBQW1DOzRCQUVuQyw4QkFBOEI7NEJBQzlCLGlGQUFpRjs0QkFDakYscUNBQXFDOzRCQUNyQywrREFBK0Q7NEJBQy9ELHFDQUFxQzs0QkFDckMsK0JBQStCOzRCQUMvQix5QkFBeUI7NEJBQ3pCLG9DQUFvQzs0QkFDcEMsd0NBQXdDOzRCQUN4Qyx5REFBeUQ7NEJBQ3pELHNDQUFzQzs0QkFDdEMsK0JBQStCOzRCQUMvQixpRUFBaUU7NEJBQ2pFLHFDQUFxQzs0QkFDckMsc0RBQXNEOzRCQUN0RCwwQ0FBMEM7NEJBQzFDLG9DQUFvQzs0QkFDcEMscUJBQXFCOzRCQUNyQiwwQkFBMEI7NEJBQzFCLGtDQUFrQzs0QkFDbEMsNERBQTREOzRCQUM1RCxxQkFBcUI7NEJBQ3JCLG1CQUFtQjs0QkFDbkIsc0VBQXNFOzRCQUV0RSxxQkFBcUI7NEJBQ3JCLGNBQWM7NEJBQ2QsWUFBWTs0QkFDWixVQUFVOzRCQUNWLFFBQVE7NEJBQ1IsTUFBTTs0QkFFTixrQ0FBa0M7NEJBQ2xDLHVCQUF1Qjs0QkFDdkIsb0JBQW9COzRCQUNwQixPQUFPOzRCQUNQLElBQUk7NEJBRUoseUJBQXlCOzRCQUMzQjt3QkFDRjtvQkFDRjtnQkFDRjtZQUNGO1FBQ0Y7UUFFQSxRQUFRLElBQUk7SUFDZCxHQUFHO0FBQ0w7QUFFQSxPQUFPLGlCQUFpQixRQUFRO0lBRTlCO0lBQ0EsWUFBWTtRQUVSLE9BQU8sU0FBUyxPQUFPO0lBRTNCLEdBQUc7QUFDTDs7Ozs7QUNoaUJvOUgsaURBQU87QUFBUCw2Q0FBd0I7QUFBNStIOztBQUFvQixJQUFJLElBQUU7SUFBSyxJQUFHO1FBQUMsSUFBSSxJQUFFLEFBQUMsV0FBVyxXQUFXLFVBQVcsTUFBTSxtRUFBaUUsRUFBRTtRQUFDLElBQUcsQ0FBQyxDQUFDLEVBQUUsS0FBRyxVQUFTLE9BQU8sU0FBUyxDQUFDLENBQUMsRUFBRSxJQUFFLE9BQUssV0FBVyxPQUFPLFNBQVMsZUFBZSxxQkFBbUI7SUFBQyxFQUFDLE9BQUs7UUFBQyxPQUFNLENBQUM7SUFBQztJQUFDLE9BQU0sQ0FBQztBQUFDO0FBQUUsSUFBSSxJQUFFO0lBQU0sQ0FBQyxDQUFDLENBQUM7SUFBQSxDQUFDLENBQUMsQ0FBQztJQUFBLElBQUksZ0JBQWU7UUFBQyxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUM7SUFBQTtJQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsSUFBSSxrQkFBaUI7UUFBQyxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUM7SUFBQTtJQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsSUFBSSxPQUFNO1FBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQUE7SUFBQyxJQUFJLFlBQVc7UUFBQyxJQUFHO1lBQUMsT0FBTyxPQUFPLFNBQU8sT0FBSyxDQUFDLENBQUMsT0FBTztRQUFZLEVBQUMsT0FBTSxHQUFFO1lBQUMsT0FBTyxRQUFRLE1BQU0sSUFBRyxDQUFDO1FBQUM7SUFBQztJQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksSUFBSTtJQUFBLENBQUMsQ0FBQyxDQUFDO0lBQUEsSUFBSSxlQUFjO1FBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQUE7SUFBQyxXQUFTLENBQUEsSUFBRyxJQUFJLENBQUMsYUFBWSxDQUFBLElBQUksQ0FBQyxhQUFXLElBQUksQ0FBQyxhQUFhLElBQUksRUFBQyxFQUFHO0lBQUEsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFFO0lBQUEsSUFBSSxZQUFXO1FBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQUE7SUFBQyxtQkFBaUIsSUFBSSxXQUFXLFNBQVMsV0FBUyxXQUFXLFFBQVEsUUFBUTtJQUFBLElBQUksa0JBQWlCO1FBQUMsSUFBRztZQUFDLE9BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztRQUFrQixFQUFDLE9BQU0sR0FBRTtZQUFDLE9BQU8sUUFBUSxNQUFNLElBQUcsQ0FBQztRQUFDO0lBQUM7SUFBQyxtQkFBaUIsSUFBSSxJQUFJLENBQUMsZ0JBQWdCO0lBQUEsZUFBYSxHQUFHO0lBQUEsYUFBVyxDQUFBLElBQUcsRUFBRSxXQUFXLElBQUksQ0FBQyxjQUFjO0lBQUEsbUJBQWlCLENBQUEsSUFBRyxDQUFDLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUFBLHFCQUFtQixDQUFBLElBQUcsRUFBRSxNQUFNLElBQUksQ0FBQyxhQUFhLFFBQVE7SUFBQSxRQUFNO1FBQUMsWUFBVyxLQUFLO1FBQVUsY0FBYSxLQUFLO0lBQUssRUFBRTtJQUFBLFlBQVksRUFBQyxNQUFLLElBQUUsTUFBTSxFQUFDLFdBQVUsSUFBRSxDQUFDLENBQUMsRUFBQyxlQUFjLElBQUUsRUFBRSxFQUFDLE9BQU0sSUFBRSxDQUFDLENBQUMsRUFBQyxHQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUMsSUFBSSxDQUFDLGdCQUFnQixJQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFFLElBQUksQ0FBQyxRQUFNO1lBQUMsR0FBRyxJQUFJLENBQUMsS0FBSztZQUFDLEdBQUcsQ0FBQztRQUFBO1FBQUUsSUFBRztZQUFDLElBQUksQ0FBQyxhQUFZLENBQUEsS0FBRyxFQUFFLFNBQU8sQ0FBQSxLQUFLLENBQUEsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFDLE9BQU8sWUFBVztRQUFFLEVBQUMsT0FBSyxDQUFDO1FBQUMsSUFBRztZQUFDLElBQUksQ0FBQyxtQkFBa0IsQ0FBQSxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLG9CQUFtQixNQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFBLEdBQUEsb0JBQUEsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBQztnQkFBQyxTQUFRO29CQUFDO2lCQUFnQjtnQkFBQyxZQUFXLENBQUM7WUFBQyxLQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQUFBRDtRQUFFLEVBQUMsT0FBSyxDQUFDO0lBQUM7SUFBQyxnQkFBZ0IsQ0FBQyxFQUFDO1FBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksSUFBSTtJQUFFO0lBQUMsWUFBVSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNO0lBQUEsU0FBTztRQUFVLElBQUksSUFBRSxNQUFNLElBQUksQ0FBQztRQUFZLE9BQU8sT0FBTyxRQUFRLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLElBQUksT0FBTyxDQUFDLEdBQUUsQ0FBQyxHQUFFLEVBQUUsR0FBSSxDQUFBLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsR0FBQyxHQUFFLENBQUEsR0FBRyxDQUFDO0lBQUUsRUFBRTtJQUFBLE9BQUssT0FBTTtRQUFJLElBQUksSUFBRSxNQUFJLEtBQUs7UUFBRSxJQUFHLENBQUMsS0FBRyxDQUFDLElBQUksQ0FBQyxhQUFhLElBQUksTUFBSSxDQUFDLElBQUksQ0FBQyxhQUFXLENBQUMsSUFBSSxDQUFDLGlCQUFnQixPQUFNLENBQUM7UUFBRSxJQUFJLElBQUUsSUFBSSxDQUFDLFlBQVUsTUFBTSxJQUFJLENBQUMsY0FBWSxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEFBQUMsQ0FBQSxJQUFFO2VBQUksSUFBSSxDQUFDO1NBQWEsR0FBQztZQUFDO1NBQUUsQUFBRCxFQUFHLElBQUksSUFBSSxDQUFDO1FBQW1CLElBQUcsQ0FBQyxHQUFFLE9BQU0sQ0FBQztRQUFFLElBQUksSUFBRSxDQUFDO1FBQUUsSUFBSSxJQUFJLEtBQUssRUFBRTtZQUFDLElBQUksSUFBRSxDQUFDLENBQUMsRUFBRSxFQUFDLElBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVE7WUFBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxHQUFFLElBQUcsTUFBSSxNQUFJO1FBQUM7UUFBQyxPQUFPO0lBQUMsRUFBRTtJQUFBLFNBQU8sT0FBTSxJQUFHLElBQUksQ0FBQyxrQkFBZ0IsQUFBQyxDQUFBLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBQyxDQUFFLENBQUMsRUFBRSxHQUFDLElBQUksQ0FBQyxTQUFTLEtBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsS0FBRyxLQUFLO0lBQUEsU0FBTyxPQUFNLEdBQUUsSUFBSyxDQUFBLElBQUksQ0FBQyxTQUFTLE1BQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsR0FBRSxJQUFHLElBQUksQ0FBQyxtQkFBaUIsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtZQUFDLENBQUMsRUFBRSxFQUFDO1FBQUMsSUFBRyxJQUFHLEVBQUc7SUFBQSxRQUFNLE9BQU0sSUFBRSxDQUFDLENBQUM7UUFBSSxLQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxTQUFRLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQU8sRUFBRTtJQUFBLFlBQVUsT0FBTTtRQUFJLElBQUksQ0FBQyxTQUFTLE1BQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFdBQVcsSUFBRyxJQUFJLENBQUMsbUJBQWlCLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87SUFBRSxFQUFFO0lBQUEsWUFBVTtRQUFVLElBQUksSUFBRSxNQUFNLElBQUksQ0FBQyxVQUFTLElBQUUsT0FBTyxLQUFLO1FBQUcsTUFBTSxRQUFRLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQztJQUFRLEVBQUU7SUFBQSxRQUFNLENBQUE7UUFBSSxJQUFJLElBQUUsSUFBSSxDQUFDO1FBQW1CLE9BQU8sS0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRztJQUFDLEVBQUU7SUFBQSxDQUFDLENBQUMsR0FBQyxDQUFBO1FBQUksSUFBSSxJQUFJLEtBQUssRUFBRTtZQUFDLElBQUksSUFBRSxJQUFJLENBQUMsaUJBQWlCLElBQUcsSUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLGVBQWEsSUFBSTtZQUFJLElBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLEdBQUUsRUFBRSxPQUFLLEdBQUU7WUFBUyxJQUFJLElBQUUsQ0FBQyxHQUFFO2dCQUFLLElBQUcsTUFBSSxJQUFJLENBQUMsUUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUM7Z0JBQU8sSUFBSSxJQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO2dCQUFHLElBQUcsQ0FBQyxHQUFFLE1BQU0sSUFBSSxNQUFNLENBQUMsd0NBQXdDLEVBQUUsRUFBRSxDQUFDO2dCQUFFLFFBQVEsSUFBSTtvQkFBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxDQUFDO29CQUFVLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUM7aUJBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQyxHQUFFLEVBQUU7b0JBQUksS0FBSSxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUU7d0JBQUMsVUFBUzt3QkFBRSxVQUFTO29CQUFDLEdBQUU7Z0JBQUU7WUFBRTtZQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLFlBQVksSUFBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFFO2dCQUFDLGFBQVk7Z0JBQUUsVUFBUztZQUFDO1FBQUU7SUFBQyxFQUFFO0lBQUEsVUFBUSxDQUFBO1FBQUksSUFBSSxJQUFFLElBQUksQ0FBQztRQUFtQixPQUFPLEtBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUc7SUFBQyxFQUFFO0lBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUFFLElBQUksSUFBSSxLQUFLLEVBQUU7WUFBQyxJQUFJLElBQUUsSUFBSSxDQUFDLGlCQUFpQixJQUFHLElBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBQyxJQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO1lBQUcsS0FBSSxDQUFBLEVBQUUsWUFBWSxPQUFPLElBQUcsRUFBRSxZQUFZLFNBQU8sS0FBSSxDQUFBLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLElBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsZUFBZSxFQUFFLFNBQVEsQ0FBQztRQUFFO0lBQUM7SUFBQyxhQUFXLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHO0lBQUEsQ0FBQyxDQUFDO1FBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFDLFVBQVMsQ0FBQyxFQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsZUFBZSxLQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFPO0lBQUMsTUFBTSxRQUFRLENBQUMsRUFBQztRQUFDLE9BQU8sSUFBSSxDQUFDLElBQUk7SUFBRTtJQUFDLE1BQU0sUUFBUSxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsTUFBTSxJQUFJLENBQUMsSUFBSSxHQUFFO0lBQUU7SUFBQyxNQUFNLFdBQVcsQ0FBQyxFQUFDO1FBQUMsT0FBTyxJQUFJLENBQUMsT0FBTztJQUFFO0FBQUMsR0FBRSxJQUFFLGNBQWM7SUFBRSxNQUFJLE9BQU07UUFBSSxJQUFJLElBQUUsSUFBSSxDQUFDLGlCQUFpQixJQUFHLElBQUUsTUFBTSxJQUFJLENBQUMsT0FBTztRQUFHLE9BQU8sSUFBSSxDQUFDLFdBQVc7SUFBRSxFQUFFO0lBQUEsTUFBSSxPQUFNLEdBQUU7UUFBSyxJQUFJLElBQUUsSUFBSSxDQUFDLGlCQUFpQixJQUFHLElBQUUsSUFBSSxDQUFDLE1BQU0sV0FBVztRQUFHLE9BQU8sSUFBSSxDQUFDLE9BQU8sR0FBRTtJQUFFLEVBQUU7SUFBQSxTQUFPLE9BQU07UUFBSSxJQUFJLElBQUUsSUFBSSxDQUFDLGlCQUFpQjtRQUFHLE9BQU8sSUFBSSxDQUFDLFVBQVU7SUFBRSxFQUFFO0lBQUEsZUFBYSxDQUFBO1FBQUksSUFBSSxDQUFDLGVBQWE7SUFBQyxFQUFFO0lBQUEsYUFBVyxPQUFNO1FBQUksSUFBRztZQUFDLElBQUcsTUFBSSxLQUFLLEdBQUUsT0FBTyxJQUFJLENBQUMsTUFBTSxhQUFhO1FBQUUsRUFBQyxPQUFNLEdBQUU7WUFBQyxRQUFRLE1BQU07UUFBRTtJQUFDLEVBQUM7QUFBQTs7Ozs7NkNDb0MxN0g7QUFwQ3hCLE1BQU0sa0JBQWtCLENBQUMsV0FBVyxTQUFTLE9BQU8sWUFBYyxTQUFVLEdBQUcsVUFBVTtRQUN4RixNQUFNLElBQUksUUFBUTtRQUVsQixPQUFPLElBQUksRUFBRSxDQUFDLFNBQVM7WUFDdEIsSUFBSSxRQUFRLFdBQ1gsV0FBVyxLQUFLLENBQUMsR0FBRztnQkFDbkIsSUFBSSxRQUFRO29CQUNYLElBQUksTUFBTSxDQUFDLEVBQUUsRUFDWixPQUFPO3lCQUNEO3dCQUNOLE9BQU87d0JBQ1AsUUFBUTtvQkFDVDt1QkFFQSxRQUFRO1lBRVY7aUJBQ00sSUFBSSxRQUFRLFlBQ2xCLFdBQVcsS0FBSyxDQUFDLE9BQU87Z0JBQ3ZCLElBQUksT0FDSCxPQUFPO3FCQUVQLFFBQVE7WUFFVjtpQkFFQSxXQUFXLEtBQUs7WUFHakIsTUFBTSxPQUFPLElBQUksS0FBSyxRQUFRLFlBQVksSUFBSTtZQUM5QyxRQUFRLE1BQU0sV0FBVyxNQUFNO1FBQ2hDO0lBQ0Q7QUFFQSxNQUFNLGNBQWMsSUFBSTtBQUVULFNBQVMsS0FBSyxLQUFLLEVBQUUsT0FBTztJQUMxQyxVQUFVO1FBQ1QsU0FBUztZQUFDO1NBQXFCO1FBQy9CLFlBQVk7UUFDWixlQUFlO1FBQ2YsR0FBRyxPQUFPO0lBQ1g7SUFFQSxNQUFNLGFBQWEsT0FBTztJQUMxQixJQUFJLENBQUUsQ0FBQSxVQUFVLFFBQVMsQ0FBQSxlQUFlLFlBQVksZUFBZSxVQUFTLENBQUMsR0FDNUUsTUFBTSxJQUFJLFVBQVUsQ0FBQyw2REFBNkQsRUFBRSxVQUFVLE9BQU8sU0FBUyxXQUFXLEVBQUUsQ0FBQztJQUc3SCxNQUFNLFNBQVMsQ0FBQyxRQUFRO1FBQ3ZCLElBQUksU0FBUyxZQUFZLElBQUk7UUFFN0IsSUFBSSxDQUFDLFFBQVE7WUFDWixTQUFTLENBQUM7WUFDVixZQUFZLElBQUksUUFBUTtRQUN6QjtRQUVBLElBQUksT0FBTyxRQUNWLE9BQU8sTUFBTSxDQUFDLElBQUk7UUFHbkIsTUFBTSxRQUFRLENBQUEsVUFBVyxBQUFDLE9BQU8sWUFBWSxZQUFZLE9BQU8sUUFBUSxXQUFZLFFBQVEsVUFBVSxRQUFRLEtBQUs7UUFDbkgsTUFBTSxhQUFhLFFBQVEseUJBQXlCLFFBQVE7UUFDNUQsTUFBTSw0QkFBNkIsZUFBZSxhQUFhLFdBQVcsWUFBWSxXQUFXO1FBQ2pHLE1BQU0sV0FBVyxRQUFRLFVBQVUsUUFBUSxRQUFRLEtBQUssQ0FBQSxVQUFXLE1BQU0sWUFBWSxDQUFDLFFBQVEsUUFBUSxLQUFLLENBQUEsVUFBVyxNQUFNO1FBQzVILE1BQU0sZUFBZSxZQUFZO1FBQ2pDLE1BQU0sQ0FBQyxJQUFJLEdBQUc7UUFDZCxPQUFPO0lBQ1I7SUFFQSxNQUFNLFFBQVEsSUFBSTtJQUVsQixNQUFNLFFBQVEsSUFBSSxNQUFNLE9BQU87UUFDOUIsT0FBTSxNQUFNLEVBQUUsT0FBTyxFQUFFLElBQUk7WUFDMUIsTUFBTSxTQUFTLE1BQU0sSUFBSTtZQUV6QixJQUFJLFFBQ0gsT0FBTyxRQUFRLE1BQU0sUUFBUSxTQUFTO1lBR3ZDLE1BQU0sU0FBUyxRQUFRLGNBQWMsU0FBUyxnQkFBZ0IsUUFBUSxTQUFTLE9BQU87WUFDdEYsTUFBTSxJQUFJLFFBQVE7WUFDbEIsT0FBTyxRQUFRLE1BQU0sUUFBUSxTQUFTO1FBQ3ZDO1FBRUEsS0FBSSxNQUFNLEVBQUUsR0FBRztZQUNkLE1BQU0sV0FBVyxNQUFNLENBQUMsSUFBSTtZQUU1QixxRUFBcUU7WUFDckUsSUFBSSxDQUFDLE9BQU8sUUFBUSxRQUFRLGFBQWEsU0FBUyxTQUFTLENBQUMsSUFBSSxFQUMvRCxPQUFPO1lBR1IsTUFBTSxTQUFTLE1BQU0sSUFBSTtZQUV6QixJQUFJLFFBQ0gsT0FBTztZQUdSLElBQUksT0FBTyxhQUFhLFlBQVk7Z0JBQ25DLE1BQU0sU0FBUyxnQkFBZ0IsVUFBVSxTQUFTLE9BQU87Z0JBQ3pELE1BQU0sSUFBSSxVQUFVO2dCQUNwQixPQUFPO1lBQ1I7WUFFQSxPQUFPO1FBQ1I7SUFDRDtJQUVBLE9BQU87QUFDUjs7O0FDOUdBLFFBQVEsaUJBQWlCLFNBQVUsQ0FBQztJQUNsQyxPQUFPLEtBQUssRUFBRSxhQUFhLElBQUk7UUFBQyxTQUFTO0lBQUM7QUFDNUM7QUFFQSxRQUFRLG9CQUFvQixTQUFVLENBQUM7SUFDckMsT0FBTyxlQUFlLEdBQUcsY0FBYztRQUFDLE9BQU87SUFBSTtBQUNyRDtBQUVBLFFBQVEsWUFBWSxTQUFVLE1BQU0sRUFBRSxJQUFJO0lBQ3hDLE9BQU8sS0FBSyxRQUFRLFFBQVEsU0FBVSxHQUFHO1FBQ3ZDLElBQUksUUFBUSxhQUFhLFFBQVEsZ0JBQWdCLEtBQUssZUFBZSxNQUNuRTtRQUdGLE9BQU8sZUFBZSxNQUFNLEtBQUs7WUFDL0IsWUFBWTtZQUNaLEtBQUs7Z0JBQ0gsT0FBTyxNQUFNLENBQUMsSUFBSTtZQUNwQjtRQUNGO0lBQ0Y7SUFFQSxPQUFPO0FBQ1Q7QUFFQSxRQUFRLFNBQVMsU0FBVSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUc7SUFDNUMsT0FBTyxlQUFlLE1BQU0sVUFBVTtRQUNwQyxZQUFZO1FBQ1osS0FBSztJQUNQO0FBQ0YiLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy8ucG5wbS9AcGxhc21vaHErcGFyY2VsLXJ1bnRpbWVAMC4yNS4wL25vZGVfbW9kdWxlcy9AcGxhc21vaHEvcGFyY2VsLXJ1bnRpbWUvZGlzdC9ydW50aW1lLWEyMzcxNjQxNmQyMWRjZmMuanMiLCJjb250ZW50cy9mb3JtZmlsbC5qcyIsIm5vZGVfbW9kdWxlcy8ucG5wbS9AcGxhc21vaHErc3RvcmFnZUAxLjExLjBfcmVhY3RAMTguMi4wL25vZGVfbW9kdWxlcy9AcGxhc21vaHEvc3RvcmFnZS9kaXN0L2luZGV4LmpzIiwibm9kZV9tb2R1bGVzLy5wbnBtL3BpZnlANi4xLjAvbm9kZV9tb2R1bGVzL3BpZnkvaW5kZXguanMiLCJub2RlX21vZHVsZXMvLnBucG0vQHBhcmNlbCt0cmFuc2Zvcm1lci1qc0AyLjkuM19AcGFyY2VsK2NvcmVAMi45LjMvbm9kZV9tb2R1bGVzL0BwYXJjZWwvdHJhbnNmb3JtZXItanMvc3JjL2VzbW9kdWxlLWhlbHBlcnMuanMiXSwic291cmNlc0NvbnRlbnQiOlsidmFyIGQ9dHlwZW9mIGdsb2JhbFRoaXMucHJvY2VzczxcInVcIj9nbG9iYWxUaGlzLnByb2Nlc3MuYXJndjpbXTt2YXIgeT0oKT0+dHlwZW9mIGdsb2JhbFRoaXMucHJvY2VzczxcInVcIj9nbG9iYWxUaGlzLnByb2Nlc3MuZW52Ont9O3ZhciBIPW5ldyBTZXQoZCksXz1lPT5ILmhhcyhlKSxHPWQuZmlsdGVyKGU9PmUuc3RhcnRzV2l0aChcIi0tXCIpJiZlLmluY2x1ZGVzKFwiPVwiKSkubWFwKGU9PmUuc3BsaXQoXCI9XCIpKS5yZWR1Y2UoKGUsW3Qsb10pPT4oZVt0XT1vLGUpLHt9KTt2YXIgWj1fKFwiLS1kcnktcnVuXCIpLHA9KCk9Pl8oXCItLXZlcmJvc2VcIil8fHkoKS5WRVJCT1NFPT09XCJ0cnVlXCIscT1wKCk7dmFyIHU9KGU9XCJcIiwuLi50KT0+Y29uc29sZS5sb2coZS5wYWRFbmQoOSksXCJ8XCIsLi4udCk7dmFyIHg9KC4uLmUpPT5jb25zb2xlLmVycm9yKFwiXFx1ezFGNTM0fSBFUlJPUlwiLnBhZEVuZCg5KSxcInxcIiwuLi5lKSxiPSguLi5lKT0+dShcIlxcdXsxRjUzNX0gSU5GT1wiLC4uLmUpLG09KC4uLmUpPT51KFwiXFx1ezFGN0UwfSBXQVJOXCIsLi4uZSksUz0wLGM9KC4uLmUpPT5wKCkmJnUoYFxcdXsxRjdFMX0gJHtTKyt9YCwuLi5lKTt2YXIgcz17XCJpc0NvbnRlbnRTY3JpcHRcIjp0cnVlLFwiaXNCYWNrZ3JvdW5kXCI6ZmFsc2UsXCJpc1JlYWN0XCI6ZmFsc2UsXCJydW50aW1lc1wiOltcInNjcmlwdC1ydW50aW1lXCJdLFwiaG9zdFwiOlwibG9jYWxob3N0XCIsXCJwb3J0XCI6MTgxNSxcImVudHJ5RmlsZVBhdGhcIjpcIkM6XFxcXFVzZXJzXFxcXHNoaXJpc2lcXFxcRGVza3RvcFxcXFxleHRlbnNpb25cXFxcZW1iYXNzeS1vZi1tb2xkb3ZhXFxcXGNvbnRlbnRzXFxcXGZvcm1maWxsLmpzXCIsXCJidW5kbGVJZFwiOlwiMTBlMTViMjMxN2IzZDcyM1wiLFwiZW52SGFzaFwiOlwiZTc5MmZiYmRhYTc4ZWU4NFwiLFwidmVyYm9zZVwiOlwiZmFsc2VcIixcInNlY3VyZVwiOmZhbHNlLFwic2VydmVyUG9ydFwiOjEwMTJ9O21vZHVsZS5idW5kbGUuSE1SX0JVTkRMRV9JRD1zLmJ1bmRsZUlkO2dsb2JhbFRoaXMucHJvY2Vzcz17YXJndjpbXSxlbnY6e1ZFUkJPU0U6cy52ZXJib3NlfX07dmFyIEQ9bW9kdWxlLmJ1bmRsZS5Nb2R1bGU7ZnVuY3Rpb24gSShlKXtELmNhbGwodGhpcyxlKSx0aGlzLmhvdD17ZGF0YTptb2R1bGUuYnVuZGxlLmhvdERhdGFbZV0sX2FjY2VwdENhbGxiYWNrczpbXSxfZGlzcG9zZUNhbGxiYWNrczpbXSxhY2NlcHQ6ZnVuY3Rpb24odCl7dGhpcy5fYWNjZXB0Q2FsbGJhY2tzLnB1c2godHx8ZnVuY3Rpb24oKXt9KX0sZGlzcG9zZTpmdW5jdGlvbih0KXt0aGlzLl9kaXNwb3NlQ2FsbGJhY2tzLnB1c2godCl9fSxtb2R1bGUuYnVuZGxlLmhvdERhdGFbZV09dm9pZCAwfW1vZHVsZS5idW5kbGUuTW9kdWxlPUk7bW9kdWxlLmJ1bmRsZS5ob3REYXRhPXt9O3ZhciBsPWdsb2JhbFRoaXMuYnJvd3Nlcnx8Z2xvYmFsVGhpcy5jaHJvbWV8fG51bGw7ZnVuY3Rpb24gdigpe3JldHVybiFzLmhvc3R8fHMuaG9zdD09PVwiMC4wLjAuMFwiP1wibG9jYWxob3N0XCI6cy5ob3N0fWZ1bmN0aW9uIEMoKXtyZXR1cm4gcy5wb3J0fHxsb2NhdGlvbi5wb3J0fXZhciBFPVwiX19wbGFzbW9fcnVudGltZV9zY3JpcHRfXCI7ZnVuY3Rpb24gTChlLHQpe2xldHttb2R1bGVzOm99PWU7cmV0dXJuIG8/ISFvW3RdOiExfWZ1bmN0aW9uIE8oZT1DKCkpe2xldCB0PXYoKTtyZXR1cm5gJHtzLnNlY3VyZXx8bG9jYXRpb24ucHJvdG9jb2w9PT1cImh0dHBzOlwiJiYhL2xvY2FsaG9zdHwxMjcuMC4wLjF8MC4wLjAuMC8udGVzdCh0KT9cIndzc1wiOlwid3NcIn06Ly8ke3R9OiR7ZX0vYH1mdW5jdGlvbiBCKGUpe3R5cGVvZiBlLm1lc3NhZ2U9PVwic3RyaW5nXCImJngoXCJbcGxhc21vL3BhcmNlbC1ydW50aW1lXTogXCIrZS5tZXNzYWdlKX1mdW5jdGlvbiBUKGUpe2lmKHR5cGVvZiBnbG9iYWxUaGlzLldlYlNvY2tldD5cInVcIilyZXR1cm47bGV0IHQ9bmV3IFdlYlNvY2tldChPKCkpO3JldHVybiB0LmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsYXN5bmMgZnVuY3Rpb24obyl7bGV0IHI9SlNPTi5wYXJzZShvLmRhdGEpO2lmKHIudHlwZT09PVwidXBkYXRlXCImJmF3YWl0IGUoci5hc3NldHMpLHIudHlwZT09PVwiZXJyb3JcIilmb3IobGV0IGEgb2Ygci5kaWFnbm9zdGljcy5hbnNpKXtsZXQgdz1hLmNvZGVmcmFtZXx8YS5zdGFjazttKFwiW3BsYXNtby9wYXJjZWwtcnVudGltZV06IFwiK2EubWVzc2FnZStgXG5gK3crYFxuXG5gK2EuaGludHMuam9pbihgXG5gKSl9fSksdC5hZGRFdmVudExpc3RlbmVyKFwiZXJyb3JcIixCKSx0LmFkZEV2ZW50TGlzdGVuZXIoXCJvcGVuXCIsKCk9PntiKGBbcGxhc21vL3BhcmNlbC1ydW50aW1lXTogQ29ubmVjdGVkIHRvIEhNUiBzZXJ2ZXIgZm9yICR7cy5lbnRyeUZpbGVQYXRofWApfSksdC5hZGRFdmVudExpc3RlbmVyKFwiY2xvc2VcIiwoKT0+e20oYFtwbGFzbW8vcGFyY2VsLXJ1bnRpbWVdOiBDb25uZWN0aW9uIHRvIHRoZSBITVIgc2VydmVyIGlzIGNsb3NlZCBmb3IgJHtzLmVudHJ5RmlsZVBhdGh9YCl9KSx0fXZhciBuPVwiX19wbGFzbW8tbG9hZGluZ19fXCI7ZnVuY3Rpb24gJCgpe2xldCBlPWdsb2JhbFRoaXMud2luZG93Py50cnVzdGVkVHlwZXM7aWYodHlwZW9mIGU+XCJ1XCIpcmV0dXJuO2xldCB0PWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ21ldGFbbmFtZT1cInRydXN0ZWQtdHlwZXNcIl0nKT8uY29udGVudD8uc3BsaXQoXCIgXCIpLG89dD90W3Q/Lmxlbmd0aC0xXTp2b2lkIDA7cmV0dXJuIHR5cGVvZiBlPFwidVwiP2UuY3JlYXRlUG9saWN5KG98fGB0cnVzdGVkLWh0bWwtJHtufWAse2NyZWF0ZUhUTUw6YT0+YX0pOnZvaWQgMH12YXIgUD0kKCk7ZnVuY3Rpb24gZygpe3JldHVybiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChuKX1mdW5jdGlvbiBmKCl7cmV0dXJuIWcoKX1mdW5jdGlvbiBGKCl7bGV0IGU9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtlLmlkPW47bGV0IHQ9YFxuICA8c3R5bGU+XG4gICAgIyR7bn0ge1xuICAgICAgYmFja2dyb3VuZDogI2YzZjNmMztcbiAgICAgIGNvbG9yOiAjMzMzO1xuICAgICAgYm9yZGVyOiAxcHggc29saWQgIzMzMztcbiAgICAgIGJveC1zaGFkb3c6ICMzMzMgNC43cHggNC43cHg7XG4gICAgfVxuXG4gICAgIyR7bn06aG92ZXIge1xuICAgICAgYmFja2dyb3VuZDogI2UzZTNlMztcbiAgICAgIGNvbG9yOiAjNDQ0O1xuICAgIH1cblxuICAgIEBrZXlmcmFtZXMgcGxhc21vLWxvYWRpbmctYW5pbWF0ZS1zdmctZmlsbCB7XG4gICAgICAwJSB7XG4gICAgICAgIGZpbGw6IHRyYW5zcGFyZW50O1xuICAgICAgfVxuICAgIFxuICAgICAgMTAwJSB7XG4gICAgICAgIGZpbGw6ICMzMzM7XG4gICAgICB9XG4gICAgfVxuXG4gICAgIyR7bn0gLnN2Zy1lbGVtLTEge1xuICAgICAgYW5pbWF0aW9uOiBwbGFzbW8tbG9hZGluZy1hbmltYXRlLXN2Zy1maWxsIDEuNDdzIGN1YmljLWJlemllcigwLjQ3LCAwLCAwLjc0NSwgMC43MTUpIDAuOHMgYm90aCBpbmZpbml0ZTtcbiAgICB9XG5cbiAgICAjJHtufSAuc3ZnLWVsZW0tMiB7XG4gICAgICBhbmltYXRpb246IHBsYXNtby1sb2FkaW5nLWFuaW1hdGUtc3ZnLWZpbGwgMS40N3MgY3ViaWMtYmV6aWVyKDAuNDcsIDAsIDAuNzQ1LCAwLjcxNSkgMC45cyBib3RoIGluZmluaXRlO1xuICAgIH1cbiAgICBcbiAgICAjJHtufSAuc3ZnLWVsZW0tMyB7XG4gICAgICBhbmltYXRpb246IHBsYXNtby1sb2FkaW5nLWFuaW1hdGUtc3ZnLWZpbGwgMS40N3MgY3ViaWMtYmV6aWVyKDAuNDcsIDAsIDAuNzQ1LCAwLjcxNSkgMXMgYm90aCBpbmZpbml0ZTtcbiAgICB9XG5cbiAgICAjJHtufSAuaGlkZGVuIHtcbiAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgfVxuXG4gIDwvc3R5bGU+XG4gIFxuICA8c3ZnIGhlaWdodD1cIjMyXCIgd2lkdGg9XCIzMlwiIHZpZXdCb3g9XCIwIDAgMjY0IDM1NFwiIGZpbGw9XCJub25lXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgIDxwYXRoIGQ9XCJNMTM5LjIyMSAyODIuMjQzQzE1NC4yNTIgMjgyLjI0MyAxNjYuOTAzIDI5NC44NDkgMTYxLjMzOCAzMDguODEyQzE1OS40ODkgMzEzLjQ1NCAxNTcuMTUgMzE3LjkxMyAxNTQuMzQ3IDMyMi4xMDlDMTQ2LjQ2NCAzMzMuOTA5IDEzNS4yNiAzNDMuMTA3IDEyMi4xNTEgMzQ4LjUzOEMxMDkuMDQzIDM1My45NjkgOTQuNjE4MiAzNTUuMzkgODAuNzAyMiAzNTIuNjIxQzY2Ljc4NjEgMzQ5Ljg1MiA1NC4wMDM0IDM0My4wMTggNDMuOTcwNSAzMzIuOTgzQzMzLjkzNzUgMzIyLjk0NyAyNy4xMDUgMzEwLjE2MiAyNC4zMzY5IDI5Ni4yNDJDMjEuNTY4OSAyODIuMzIzIDIyLjk4OTUgMjY3Ljg5NSAyOC40MTkzIDI1NC43ODNDMzMuODQ5MSAyNDEuNjcxIDQzLjA0NDEgMjMwLjQ2NCA1NC44NDE2IDIyMi41NzlDNTkuMDM1MyAyMTkuNzc3IDYzLjQ5MDggMjE3LjQzOCA2OC4xMjk1IDIxNS41ODhDODIuMDkxNSAyMTAuMDIxIDk0LjY5NzggMjIyLjY3MSA5NC42OTc4IDIzNy43MDNMOTQuNjk3OCAyNTUuMDI3Qzk0LjY5NzggMjcwLjA1OCAxMDYuODgzIDI4Mi4yNDMgMTIxLjkxNCAyODIuMjQzSDEzOS4yMjFaXCIgZmlsbD1cIiMzMzNcIiBjbGFzcz1cInN2Zy1lbGVtLTFcIiA+PC9wYXRoPlxuICAgIDxwYXRoIGQ9XCJNMTkyLjI2MSAxNDIuMDI4QzE5Mi4yNjEgMTI2Ljk5NiAyMDQuODY3IDExNC4zNDYgMjE4LjgyOSAxMTkuOTEzQzIyMy40NjggMTIxLjc2MyAyMjcuOTIzIDEyNC4xMDIgMjMyLjExNyAxMjYuOTA0QzI0My45MTUgMTM0Ljc4OSAyNTMuMTEgMTQ1Ljk5NiAyNTguNTM5IDE1OS4xMDhDMjYzLjk2OSAxNzIuMjIgMjY1LjM5IDE4Ni42NDggMjYyLjYyMiAyMDAuNTY3QzI1OS44NTQgMjE0LjQ4NyAyNTMuMDIxIDIyNy4yNzIgMjQyLjk4OCAyMzcuMzA4QzIzMi45NTUgMjQ3LjM0MyAyMjAuMTczIDI1NC4xNzcgMjA2LjI1NiAyNTYuOTQ2QzE5Mi4zNCAyNTkuNzE1IDE3Ny45MTYgMjU4LjI5NCAxNjQuODA3IDI1Mi44NjNDMTUxLjY5OSAyNDcuNDMyIDE0MC40OTUgMjM4LjIzNCAxMzIuNjEyIDIyNi40MzRDMTI5LjgwOCAyMjIuMjM4IDEyNy40NyAyMTcuNzc5IDEyNS42MiAyMTMuMTM3QzEyMC4wNTYgMTk5LjE3NCAxMzIuNzA3IDE4Ni41NjggMTQ3LjczOCAxODYuNTY4TDE2NS4wNDQgMTg2LjU2OEMxODAuMDc2IDE4Ni41NjggMTkyLjI2MSAxNzQuMzgzIDE5Mi4yNjEgMTU5LjM1MkwxOTIuMjYxIDE0Mi4wMjhaXCIgZmlsbD1cIiMzMzNcIiBjbGFzcz1cInN2Zy1lbGVtLTJcIiA+PC9wYXRoPlxuICAgIDxwYXRoIGQ9XCJNOTUuNjUyMiAxNjQuMTM1Qzk1LjY1MjIgMTc5LjE2NyA4My4yMjc5IDE5MS43MjUgNjguODAxMyAxODcuNTA1QzU5LjUxNDUgMTg0Ljc4OCA1MC42NDMyIDE4MC42NjMgNDIuNTEwNiAxNzUuMjI3QzI2Ljc4MDYgMTY0LjcxNCAxNC41MjA2IDE0OS43NzIgNy4yODA4OSAxMzIuMjg5QzAuMDQxMTgzIDExNC44MDcgLTEuODUzMDUgOTUuNTY5NyAxLjgzNzcyIDc3LjAxMDRDNS41Mjg0OSA1OC40NTExIDE0LjYzODUgNDEuNDAzMyAyOC4wMTU3IDI4LjAyMjhDNDEuMzkzIDE0LjY0MjMgNTguNDM2NiA1LjUzMDA2IDc2Ljk5MTQgMS44MzgzOUM5NS41NDYxIC0xLjg1MzI5IDExNC43NzkgMC4wNDE0MTYyIDEzMi4yNTcgNy4yODI5QzE0OS43MzUgMTQuNTI0NCAxNjQuNjc0IDI2Ljc4NzQgMTc1LjE4NCA0Mi41MjEyQzE4MC42MiA1MC42NTc2IDE4NC43NDQgNTkuNTMzMiAxODcuNDYgNjguODI0NUMxOTEuNjc4IDgzLjI1MTkgMTc5LjExOSA5NS42NzU5IDE2NC4wODggOTUuNjc1OUwxMjIuODY5IDk1LjY3NTlDMTA3LjgzNyA5NS42NzU5IDk1LjY1MjIgMTA3Ljg2MSA5NS42NTIyIDEyMi44OTJMOTUuNjUyMiAxNjQuMTM1WlwiIGZpbGw9XCIjMzMzXCIgY2xhc3M9XCJzdmctZWxlbS0zXCI+PC9wYXRoPlxuICA8L3N2Zz5cbiAgPHNwYW4gY2xhc3M9XCJoaWRkZW5cIj5Db250ZXh0IEludmFsaWRhdGVkLCBQcmVzcyB0byBSZWxvYWQ8L3NwYW4+XG4gIGA7cmV0dXJuIGUuaW5uZXJIVE1MPVA/UC5jcmVhdGVIVE1MKHQpOnQsZS5zdHlsZS5wb2ludGVyRXZlbnRzPVwibm9uZVwiLGUuc3R5bGUucG9zaXRpb249XCJmaXhlZFwiLGUuc3R5bGUuYm90dG9tPVwiMTQuN3B4XCIsZS5zdHlsZS5yaWdodD1cIjE0LjdweFwiLGUuc3R5bGUuZm9udEZhbWlseT1cInNhbnMtc2VyaWZcIixlLnN0eWxlLmRpc3BsYXk9XCJmbGV4XCIsZS5zdHlsZS5qdXN0aWZ5Q29udGVudD1cImNlbnRlclwiLGUuc3R5bGUuYWxpZ25JdGVtcz1cImNlbnRlclwiLGUuc3R5bGUucGFkZGluZz1cIjE0LjdweFwiLGUuc3R5bGUuZ2FwPVwiMTQuN3B4XCIsZS5zdHlsZS5ib3JkZXJSYWRpdXM9XCI0LjdweFwiLGUuc3R5bGUuekluZGV4PVwiMjE0NzQ4MzY0N1wiLGUuc3R5bGUub3BhY2l0eT1cIjBcIixlLnN0eWxlLnRyYW5zaXRpb249XCJhbGwgMC40N3MgZWFzZS1pbi1vdXRcIixlfWZ1bmN0aW9uIE4oZSl7cmV0dXJuIG5ldyBQcm9taXNlKHQ9Pntkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ/KGYoKSYmKGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5hcHBlbmRDaGlsZChlKSx0KCkpLHQoKSk6Z2xvYmFsVGhpcy5hZGRFdmVudExpc3RlbmVyKFwiRE9NQ29udGVudExvYWRlZFwiLCgpPT57ZigpJiZkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuYXBwZW5kQ2hpbGQoZSksdCgpfSl9KX12YXIgaz0oKT0+e2xldCBlO2lmKGYoKSl7bGV0IHQ9RigpO2U9Tih0KX1yZXR1cm57c2hvdzphc3luYyh7cmVsb2FkQnV0dG9uOnQ9ITF9PXt9KT0+e2F3YWl0IGU7bGV0IG89ZygpO28uc3R5bGUub3BhY2l0eT1cIjFcIix0JiYoby5vbmNsaWNrPXI9PntyLnN0b3BQcm9wYWdhdGlvbigpLGdsb2JhbFRoaXMubG9jYXRpb24ucmVsb2FkKCl9LG8ucXVlcnlTZWxlY3RvcihcInNwYW5cIikuY2xhc3NMaXN0LnJlbW92ZShcImhpZGRlblwiKSxvLnN0eWxlLmN1cnNvcj1cInBvaW50ZXJcIixvLnN0eWxlLnBvaW50ZXJFdmVudHM9XCJhbGxcIil9LGhpZGU6YXN5bmMoKT0+e2F3YWl0IGU7bGV0IHQ9ZygpO3Quc3R5bGUub3BhY2l0eT1cIjBcIn19fTt2YXIgVz1gJHtFfSR7bW9kdWxlLmlkfV9fYCxpLEE9ITEsTT1rKCk7YXN5bmMgZnVuY3Rpb24gaCgpe2MoXCJTY3JpcHQgUnVudGltZSAtIHJlbG9hZGluZ1wiKSxBP2dsb2JhbFRoaXMubG9jYXRpb24/LnJlbG9hZD8uKCk6TS5zaG93KHtyZWxvYWRCdXR0b246ITB9KX1mdW5jdGlvbiBSKCl7aT8uZGlzY29ubmVjdCgpLGk9bD8ucnVudGltZS5jb25uZWN0KHtuYW1lOld9KSxpLm9uRGlzY29ubmVjdC5hZGRMaXN0ZW5lcigoKT0+e2goKX0pLGkub25NZXNzYWdlLmFkZExpc3RlbmVyKGU9PntlLl9fcGxhc21vX2NzX3JlbG9hZF9fJiZoKCksZS5fX3BsYXNtb19jc19hY3RpdmVfdGFiX18mJihBPSEwKX0pfWZ1bmN0aW9uIGooKXtpZihsPy5ydW50aW1lKXRyeXtSKCksc2V0SW50ZXJ2YWwoUiwyNGUzKX1jYXRjaHtyZXR1cm59fWooKTtUKGFzeW5jIGU9PntjKFwiU2NyaXB0IHJ1bnRpbWUgLSBvbiB1cGRhdGVkIGFzc2V0c1wiKSxlLmZpbHRlcihvPT5vLmVudkhhc2g9PT1zLmVudkhhc2gpLnNvbWUobz0+TChtb2R1bGUuYnVuZGxlLG8uaWQpKSYmKE0uc2hvdygpLGw/LnJ1bnRpbWU/aS5wb3N0TWVzc2FnZSh7X19wbGFzbW9fY3NfY2hhbmdlZF9fOiEwfSk6c2V0VGltZW91dCgoKT0+e2goKX0sNDcwMCkpfSk7XG4iLCJpbXBvcnQgeyBTdG9yYWdlIH0gZnJvbSBcIkBwbGFzbW9ocS9zdG9yYWdlXCJcclxuXHJcbmNvbnN0IHN0b3JhZ2UgPSBuZXcgU3RvcmFnZSgpXHJcblxyXG5leHBvcnQgY29uc3QgY29uZmlnID0ge1xyXG4gIG1hdGNoZXM6IFtcImh0dHBzOi8vcHJvZ3JhbWFyaS5nb3YubWQvZW4vbWFlaWUvYXBwb2ludG1lbnRzKlwiXVxyXG4gIFxyXG59XHJcblxyXG5jb25zb2xlLmxvZyhcImluIGZvcm1maWxsXCIpXHJcblxyXG5mdW5jdGlvbiBnZW5lcmF0ZVVuaXF1ZUlkZW50aWZpZXIoKSB7XHJcbiAgcmV0dXJuIGNyeXB0by5yYW5kb21VVUlEKClcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZ2V0dmFsdWUoKSB7XHJcbiAgY29uc29sZS5sb2coXCJpbnNpZGUgZm9ybSBwYWdlXCIpXHJcbiAgY29uc3QgZGF0YSA9IGF3YWl0IHN0b3JhZ2UuZ2V0KFwidXNlcnNkYXRhXCIpXHJcbiAgY29uc29sZS5sb2coZGF0YSlcclxuICByZXR1cm4gZGF0YVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBjbGVhckRhdGEoKSB7XHJcbiAgY29uc3QgdmFsID0gYXdhaXQgc3RvcmFnZS5yZW1vdmUoXCJ1c2Vyc2RhdGFcIilcclxuICBjb25zb2xlLmxvZyh2YWwpXHJcbiAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJ1c2VkQXJyYXlzXCIpXHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldFVuaXF1ZUFycmF5KCkge1xyXG4gIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXR2YWx1ZSgpXHJcbiAgLy8gbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2FycmF5c0V4aGF1c3RlZCcsICdmYWxzZScpO1xyXG4gIGlmICghZGF0YSB8fCAhQXJyYXkuaXNBcnJheShkYXRhKSB8fCBkYXRhLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkludmFsaWQgb3IgZW1wdHkgZGF0YSByZXRyaWV2ZWQuXCIpXHJcbiAgICByZXR1cm4gbnVsbFxyXG4gIH1cclxuXHJcbiAgbGV0IHBhZ2VJZGVudGlmaWVyID0gc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShcInBhZ2VJZGVudGlmaWVyXCIpXHJcbiAgaWYgKCFwYWdlSWRlbnRpZmllcikge1xyXG4gICAgcGFnZUlkZW50aWZpZXIgPSBnZW5lcmF0ZVVuaXF1ZUlkZW50aWZpZXIoKVxyXG4gICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShcInBhZ2VJZGVudGlmaWVyXCIsIHBhZ2VJZGVudGlmaWVyKVxyXG4gIH1cclxuXHJcbiAgbGV0IHVzZWRBcnJheXMgPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlZEFycmF5c1wiKSkgfHwgW11cclxuICBsZXQgdXNlZEFycmF5c192YWx1ZSA9XHJcbiAgICBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlZEFycmF5c1ZhbHVlXCIpKSB8fCBbXVxyXG5cclxuICBpZiAodXNlZEFycmF5cy5sZW5ndGggPj0gZGF0YS5sZW5ndGgpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJObyBtb3JlIHVuaXF1ZSBhcnJheXMgYXZhaWxhYmxlLlwiKVxyXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJhcnJheXNFeGhhdXN0ZWRcIiwgXCJ0cnVlXCIpXHJcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShcInBhZ2VJZGVudGlmaWVyXCIpXHJcbiAgICBzZXNzaW9uU3RvcmFnZS5yZW1vdmVJdGVtKFwicGFnZUlkZW50aWZpZXJcIilcclxuICAgIGF3YWl0IGNsZWFyRGF0YSgpXHJcblxyXG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJ1bmlxdWVBcnJheVwiKVxyXG4gICAgd2luZG93LmNsb3NlKClcclxuICAgIGFsZXJ0KFwiYWxsIHZhbHVlcyBhcmUgZmlsbGVkIG5vdyBzdGFydCBhZ2FpblwiKVxyXG5cclxuICAgIC8vIHJldHVybiBudWxsO1xyXG4gIH1cclxuXHJcbiAgbGV0IHVuaXF1ZUFycmF5ID0gbnVsbFxyXG5cclxuICAvLyBGaW5kIGFuIHVudXNlZCBhcnJheSBpbmRleFxyXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgaWYgKCF1c2VkQXJyYXlzLmluY2x1ZGVzKGkpKSB7XHJcbiAgICAgIHVuaXF1ZUFycmF5ID0gZGF0YVtpXVxyXG4gICAgICB1c2VkQXJyYXlzLnB1c2goaSlcclxuICAgICAgdXNlZEFycmF5c192YWx1ZS5wdXNoW2RhdGFbaV1dXHJcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwidXNlZEFycmF5c1ZhbHVlXCIsIEpTT04uc3RyaW5naWZ5KHVzZWRBcnJheXNfdmFsdWUpKVxyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInVzZWRBcnJheXNcIiwgSlNPTi5zdHJpbmdpZnkodXNlZEFycmF5cykpXHJcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKHBhZ2VJZGVudGlmaWVyLCBKU09OLnN0cmluZ2lmeSh1bmlxdWVBcnJheSkpXHJcbiAgICAgIGNvbnNvbGUubG9nKFwiVXNlZCBhcnJheSBpbmRleDpcIiwgaSlcclxuICAgICAgYnJlYWtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGlmICghdW5pcXVlQXJyYXkpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJObyB1bnVzZWQgYXJyYXkgZm91bmQuXCIpXHJcbiAgICByZXR1cm4gbnVsbFxyXG4gIH1cclxuXHJcbiAgY29uc29sZS5sb2coXCJVc2VkIGFycmF5czpcIiwgdXNlZEFycmF5cylcclxuICBjb25zb2xlLmxvZyhcIlVuaXF1ZSBhcnJheTpcIiwgdW5pcXVlQXJyYXkpXHJcbiAgcmV0dXJuIHVuaXF1ZUFycmF5XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGZpbmRkYXRlYW5kdGltZXNsb3QoZGF0ZVZhbHVlKSB7XHJcbiAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICBsZXQgY2Rjb250YWluZXIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAnZGl2W2NsYXNzPVwiY2RrLW92ZXJsYXktY29udGFpbmVyXCJdJ1xyXG4gICAgKVxyXG4gICAgY29uc29sZS5sb2coXCJjZGNvbnRhaW5lclwiLCBjZGNvbnRhaW5lcilcclxuXHJcbiAgICBsZXQgY2RrX292ZXJsYXkgPSBjZGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCdkaXYgPiBkaXZbaWQ9XCJjZGstb3ZlcmxheS0wXCJdJylcclxuICAgIGNvbnNvbGUubG9nKFwiY2RrX292ZXJsYXlcIiwgY2RrX292ZXJsYXkpXHJcblxyXG4gICAgbGV0IG1lbnUgPSBjZGtfb3ZlcmxheS5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAnZGl2W3JvbGU9XCJtZW51XCJdID4gZGl2ID4gZGl2W2NsYXNzKj1cImRhdGUtdGltZS1waWNrZXItd3JhcHBlclwiXSdcclxuICAgIClcclxuICAgIGNvbnNvbGUubG9nKG1lbnUpXHJcblxyXG4gICAgbGV0IHNjcm9sbGJhciA9IG1lbnUucXVlcnlTZWxlY3RvcihcclxuICAgICAgXCJtYXQtY2FsZW5kYXIgPiBkaXZbY2RrbW9uaXRvcnN1YnRyZWVmb2N1c11cIlxyXG4gICAgKVxyXG4gICAgY29uc29sZS5sb2coc2Nyb2xsYmFyKVxyXG5cclxuICAgIGxldCB0YWJsZSA9IHNjcm9sbGJhci5xdWVyeVNlbGVjdG9yKCd0YWJsZVtyb2xlPVwiZ3JpZFwiXSA+IHRib2R5JylcclxuICAgIGNvbnNvbGUubG9nKHRhYmxlKVxyXG5cclxuICAgIGxldCB0ciA9IHRhYmxlLnF1ZXJ5U2VsZWN0b3JBbGwoJ3RyW3JvbGU9XCJyb3dcIl0nKVxyXG5cclxuICAgIHRyLmZvckVhY2goKHJvdykgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhcInJlcGVhdFwiKVxyXG4gICAgICBsZXQgYWxsZGF0ZXMgPSByb3cucXVlcnlTZWxlY3RvckFsbChcInRkID4gYnV0dG9uXCIpXHJcbiAgICAgIGNvbnNvbGUubG9nKFwiYWxsZGF0ZXNcIiwgYWxsZGF0ZXMpXHJcbiAgICAgIGFsbGRhdGVzLmZvckVhY2goKGJ1dHRvbikgPT4ge1xyXG4gICAgICAgIGNvbnN0IGRpdiA9IGJ1dHRvbi5xdWVyeVNlbGVjdG9yKCdkaXZbY2xhc3MqPVwibWF0LWZvY3VzLWluZGljYXRvclwiXScpXHJcbiAgICAgICAgY29uc29sZS5sb2coZGl2KSAvLyBBZGp1c3QgdGhlIHNlbGVjdG9yIGlmIG5lY2Vzc2FyeVxyXG4gICAgICAgIGlmIChkaXYgJiYgZGl2LnRleHRDb250ZW50LnRyaW0oKSA9PSBkYXRlVmFsdWUpIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGRpdi50ZXh0Q29udGVudClcclxuXHJcbiAgICAgICAgICBidXR0b24uYXJpYVByZXNzZWQgPSBcInRydWVcIlxyXG4gICAgICAgICAgYnV0dG9uLmNsaWNrKClcclxuICAgICAgICAgIHRpbWVTZWxlY3QobWVudSlcclxuICAgICAgICAgIHJldHVyblxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgIH0pXHJcbiAgfSwgNDAwMClcclxufVxyXG5cclxuZnVuY3Rpb24gdGltZVNlbGVjdChtZW51KSB7XHJcbiAgbGV0IHNjcm9sbGJhciA9IG1lbnUucXVlcnlTZWxlY3RvcihcIm5nLXNjcm9sbGJhclwiKVxyXG4gIGNvbnNvbGUubG9nKFwic2Nyb2xsYmFyXCIsIHNjcm9sbGJhcilcclxuICBsZXQgbXdsX2NhbGVuZGFyX3dlZWsgPSBzY3JvbGxiYXIucXVlcnlTZWxlY3RvcihcclxuICAgICdtd2wtY2FsZW5kYXItZGF5LXZpZXcgPiBtd2wtY2FsZW5kYXItd2Vlay12aWV3ID4gZGl2W3JvbGU9XCJncmlkXCJdJ1xyXG4gIClcclxuICBjb25zb2xlLmxvZyhcIm13bF9jYWxlbmRhcl93ZWVrXCIsIG13bF9jYWxlbmRhcl93ZWVrKVxyXG5cclxuICBtd2xkcm9wcGFibGUgPSBtd2xfY2FsZW5kYXJfd2Vlay5xdWVyeVNlbGVjdG9yKCdkaXZbY2xhc3M9XCJjYWwtdGltZS1ldmVudHNcIl0nKVxyXG4gIGNvbnNvbGUubG9nKFwibXdsZHJvcHBhYmxlXCIsIG13bGRyb3BwYWJsZSlcclxuXHJcbiAgbGV0IHByZXNlbnRob3VyID0gbXdsZHJvcHBhYmxlLnF1ZXJ5U2VsZWN0b3JBbGwoJ2RpdltjbGFzcyo9XCJjYWwtaG91clwiXScpXHJcblxyXG4gIGNvbnNvbGUubG9nKFwicHJlc2VudGhvdXJcIiwgcHJlc2VudGhvdXIpXHJcbiAgcHJlc2VudGhvdXIuZm9yRWFjaCgoZWFjaHRpbWVhdmFpbGNoZWNrKSA9PiB7XHJcbiAgICBsZXQgdGltZSA9IGVhY2h0aW1lYXZhaWxjaGVjay5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAnbXdsLWNhbGVuZGFyLXdlZWstdmlldy1ob3VyLXNlZ21lbnQgPiBkaXZbY2xhc3MqPVwidGltZS1jZWxsXCJdJ1xyXG4gICAgKVxyXG4gICAgY29uc29sZS5sb2codGltZSlcclxuXHJcbiAgICBsZXQgYmFkZ2UgPSB0aW1lLnF1ZXJ5U2VsZWN0b3IoJ3NwYW5bY2xhc3M9XCJiYWRnZVwiXScpXHJcbiAgICBpZihiYWRnZSkge1xyXG4gICAgY29uc29sZS5sb2coXCJiYWRnZVwiLCBiYWRnZSlcclxuICAgIHRpbWUuY2xpY2soKVxyXG4gICAgfVxyXG4gIH0pXHJcblxyXG4gIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgbGV0IG1haW4gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdtYWluW3JvbGU9XCJtYWluXCJdID4gZWFwLWFwcG9pbnRtZW50cyA+IGRpdltjbGFzcyo9XCJjb250YWluZXJcIl0nKVxyXG4gICAgY29uc29sZS5sb2coXCJtYWluXCIsIG1haW4pXHJcbiAgICBsZXQgYnV0dG9uID0gbWFpbi5xdWVyeVNlbGVjdG9yKCdkaXZbY2xhc3M9XCJjb250ZW50XCJdJylcclxuICAgIGNvbnNvbGUubG9nKFwiYnV0dG9uZm9yc3VibWl0XCIsIGJ1dHRvbilcclxuICAgIGxldCBidXR0b25zZWxlY3QgPSBidXR0b24ucXVlcnlTZWxlY3RvcignZGl2W2NsYXNzPVwibGVmdFwiXScpXHJcbiAgICBsZXQgc3VibWl0ID0gYnV0dG9uc2VsZWN0LnF1ZXJ5U2VsZWN0b3IoXCJidXR0b25bbWF0LXJhaXNlZC1idXR0b25dXCIpXHJcbiAgICBjb25zb2xlLmxvZyhzdWJtaXQpXHJcbiAgICBpZiAoc3VibWl0KSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc3VibWl0LmNsaWNrKClcclxuICAgICAgICAvLyBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAvLyAvLyAgIGFsZXJ0KFwiZm9ybSBmaWxsZWQgc3VjY2Vzc2Z1bGx5XCIpXHJcbiAgICAgICAgLy8gICB3aW5kb3cuY2xvc2UoKVxyXG4gICAgICAgIC8vIH0sIDIwMDAwKVxyXG4gICAgICAgIC8vIFByb2dyYW1tYXRpY2FsbHkgY2xpY2sgdGhlIHN1Ym1pdCBidXR0b25cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcImhlcmUgaW5zaWRlIGVycm9yXCIpXHJcbiAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcilcclxuICAgICAgICB3aW5kb3cuY2xvc2UoKVxyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiU3VibWl0IGJ1dHRvbiBub3QgZm91bmQgaW4gdGhlIGZvcm0uXCIpXHJcbiAgICB9XHJcbiAgfSwgMTAwMClcclxuICByZXR1cm5cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gd2FpdEZvckRhdGVWYWx1ZShmb3VuZGRhdGUpIHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgaWYgKGZvdW5kZGF0ZSkge1xyXG4gICAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKChtdXRhdGlvbnNMaXN0LCBvYnNlcnZlcikgPT4ge1xyXG4gICAgICAgIGZvciAobGV0IG11dGF0aW9uIG9mIG11dGF0aW9uc0xpc3QpIHtcclxuICAgICAgICAgIGlmIChtdXRhdGlvbi50eXBlID09PSBcImNoaWxkTGlzdFwiKSB7XHJcbiAgICAgICAgICAgIGxldCBjaGVja2RhdGVhdmFpbCA9IGZvdW5kZGF0ZS5xdWVyeVNlbGVjdG9yKFwibWF0LWljb25cIilcclxuICAgICAgICAgICAgaWYgKGNoZWNrZGF0ZWF2YWlsKSB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJtYXQtaWNvbiBlbGVtZW50IGZvdW5kOlwiLCBjaGVja2RhdGVhdmFpbClcclxuICAgICAgICAgICAgICAvLyBFeHRyYWN0IHRoZSBpbm5lciB0ZXh0IHZhbHVlIGZyb20gZm91bmRkYXRlXHJcbiAgICAgICAgICAgICAgbGV0IGRhdGVWYWx1ZSA9IGZvdW5kZGF0ZS5pbm5lclRleHQudHJpbSgpXHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJEYXRlIHZhbHVlOlwiLCBkYXRlVmFsdWUpXHJcbiAgICAgICAgICAgICAgLy8gT3B0aW9uYWxseSBkaXNjb25uZWN0IHRoZSBvYnNlcnZlciBhZnRlciBmaW5kaW5nIHRoZSBlbGVtZW50XHJcbiAgICAgICAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpXHJcbiAgICAgICAgICAgICAgLy8gICBzbG90Qm9va2VkID0gdHJ1ZSAvLyBTZXQgc2xvdEJvb2tlZCB0byB0cnVlIHRvIHN0b3AgZnVydGhlciBwcm9jZXNzaW5nXHJcbiAgICAgICAgICAgICAgcmVzb2x2ZShkYXRlVmFsdWUpIC8vIFJlc29sdmUgdGhlIHByb21pc2Ugd2l0aCB0aGUgZGF0ZSB2YWx1ZVxyXG4gICAgICAgICAgICAgIHJldHVyblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG5cclxuICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZShmb3VuZGRhdGUsIHtcclxuICAgICAgICBjaGlsZExpc3Q6IHRydWUsXHJcbiAgICAgICAgc3VidHJlZTogdHJ1ZVxyXG4gICAgICB9KVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmVqZWN0KFwiZm91bmRkYXRlIGVsZW1lbnQgaXMgbm90IGRlZmluZWRcIilcclxuICAgIH1cclxuICB9KVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBmaWxsc2FuZHN1Ym1pdHN2YWx1ZSgpIHtcclxuICBsZXQgcGFnZUlkZW50aWZpZXIgPSBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCdwYWdlSWRlbnRpZmllcicpO1xyXG5cclxuICBpZiAoIXBhZ2VJZGVudGlmaWVyKSB7XHJcbiAgICBwYWdlSWRlbnRpZmllciA9IGdlbmVyYXRlVW5pcXVlSWRlbnRpZmllcigpO1xyXG4gICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgncGFnZUlkZW50aWZpZXInLCBwYWdlSWRlbnRpZmllcik7XHJcbiAgfVxyXG5cclxuICBjb25zdCB2YWwgPSBhd2FpdCBnZXRVbmlxdWVBcnJheSgpO1xyXG4gIGlmICghdmFsKSB7XHJcbiAgICBhbGVydCgnZmlsbCB0aGUgdmFsdWVzIGluIGV4Y2VsIHNoZWV0IGFuZCB0aGVuIHJldHJ5JylcclxuICAgIGNvbnNvbGUuZXJyb3IoJ05vIHVuaXF1ZSBhcnJheSBmb3VuZC4nKTtcclxuICAgIHdpbmRvdy5jbG9zZSgpXHJcbiAgfVxyXG5cclxuICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKFwiaGVyZSBpbnNpZGUgdGltZW91dFwiKVxyXG5cclxuICAgIGxldCBtYWluID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignbWFpbltyb2xlPVwibWFpblwiXScpXHJcbiAgICBjb25zb2xlLmxvZyhtYWluKVxyXG4gICAgbGV0IGZvcm0gPSBtYWluLnF1ZXJ5U2VsZWN0b3IoXCJmb3JtXCIpXHJcblxyXG4gICAgY29uc3Qgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiKVxyXG4gICAgc2NyaXB0LnRleHRDb250ZW50ID0gYChmdW5jdGlvbigpIHtcclxuICAgICAgICBsZXQgZm9ybSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXHJcbiAgICAnZm9ybScpXHJcbiAgICAgZm9ybS5zZXRBdHRyaWJ1dGUoJ25vdmFsaWRhdGUnLCB0cnVlKTtcclxuICAgICBmb3JtLmFkZEV2ZW50TGlzdGVuZXIoJ3N1Ym1pdCcsIGZ1bmN0aW9uKGUpIHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7IC8vIFByZXZlbnQgZGVmYXVsdCBmb3JtIHN1Ym1pc3Npb25cclxuICAgICAgICAvLyBBZGRpdGlvbmFsIGxvZ2ljIGZvciBoYW5kbGluZyBmb3JtIHN1Ym1pc3Npb24gaGVyZSBpZiBuZWVkZWRcclxuICAgICB9KTtcclxuICAgIH0pKClgXHJcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHNjcmlwdClcclxuXHJcbiAgICBjb25zb2xlLmxvZyhmb3JtKVxyXG4gICAgbGV0IGNpdGl6ZW4gPSBmb3JtLnF1ZXJ5U2VsZWN0b3IoXHJcbiAgICAgICdkaXZbY2xhc3MqPVwiZWFwLWNhcmRcIl0gPiBkaXY6bnRoLWNoaWxkKDEpJ1xyXG4gICAgKVxyXG4gICAgY29uc29sZS5sb2coY2l0aXplbilcclxuICAgIGxldCBjaGVja2JveCA9IGNpdGl6ZW4ucXVlcnlTZWxlY3RvcihcIm1hdC1jaGVja2JveCA+IGxhYmVsXCIpXHJcbiAgICBjb25zb2xlLmxvZyhjaGVja2JveClcclxuICAgIGxldCBpbnB1dGNoZWNrYm94ID0gY2hlY2tib3gucXVlcnlTZWxlY3RvcignaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdJylcclxuICAgIGNvbnNvbGUubG9nKGlucHV0Y2hlY2tib3gpXHJcbiAgICBpZiAoaW5wdXRjaGVja2JveCkge1xyXG4gICAgICBpbnB1dGNoZWNrYm94LmNsaWNrKClcclxuICAgICAgLy8gICBpbnB1dC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImlucHV0XCIsIHsgYnViYmxlczogdHJ1ZSB9KSk7XHJcbiAgICAgIC8vICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGVja2VkXCIsIHsgYnViYmxlczogdHJ1ZSB9KSk7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IEFncmVlVGVybXMgPSBmb3JtLnF1ZXJ5U2VsZWN0b3IoXHJcbiAgICAgICdsYWJlbCA+IHNwYW4gPiBpbnB1dFtpZD1cIm1hdC1jaGVja2JveC0xLWlucHV0XCJdJ1xyXG4gICAgKVxyXG4gICAgY29uc29sZS5sb2coQWdyZWVUZXJtcylcclxuICAgIGlmIChBZ3JlZVRlcm1zKSB7XHJcbiAgICAgIEFncmVlVGVybXMuY2xpY2soKVxyXG4gICAgfVxyXG5cclxuICAgIGxldCBzZWN0aW9uaW5wdXQgPSBmb3JtLnF1ZXJ5U2VsZWN0b3JBbGwoXCJzZWN0aW9uXCIpXHJcbiAgICBjb25zb2xlLmxvZyhzZWN0aW9uaW5wdXQpXHJcblxyXG4gICAgc2VjdGlvbmlucHV0LmZvckVhY2goKGZpZWxkLCBpbmRleCkgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhpbmRleClcclxuICAgICAgY29uc29sZS5sb2coZmllbGQpXHJcbiAgICAgIGlmIChpbmRleCA9PSAwKSB7XHJcbiAgICAgICAgbGV0IG5hbWVzID0gZmllbGQucXVlcnlTZWxlY3RvcignZGl2W2Zvcm1ncm91cG5hbWU9XCJ1c2VyXCJdJylcclxuICAgICAgICBsZXQgbnVtYW5kYWRkcmVzcyA9IGZpZWxkLnF1ZXJ5U2VsZWN0b3IoJ2RpdltjbGFzcz1cImdyb3VwZWQtZmllbGRzXCJdJylcclxuICAgICAgICBjb25zb2xlLmxvZyhuYW1lcylcclxuICAgICAgICBjb25zb2xlLmxvZyhudW1hbmRhZGRyZXNzKVxyXG4gICAgICAgIGxldCBsYWJlbHMgPSBuYW1lcy5xdWVyeVNlbGVjdG9yQWxsKFwibGFiZWxcIilcclxuICAgICAgICBsZXQgcmxhYmVscyA9IG51bWFuZGFkZHJlc3MucXVlcnlTZWxlY3RvckFsbChcImxhYmVsXCIpXHJcbiAgICAgICAgbGFiZWxzLmZvckVhY2goKGxhYmVsLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgaWYgKGxhYmVsKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGxhYmVsLmlubmVyVGV4dClcclxuICAgICAgICAgICAgaWYgKGxhYmVsLmlubmVyVGV4dC5pbmNsdWRlcyhcIkZpcnN0IG5hbWUqXCIpKSB7XHJcbiAgICAgICAgICAgICAgbGV0IGlucHV0ID0gbGFiZWwucXVlcnlTZWxlY3RvcihcImlucHV0XCIpXHJcblxyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKGlucHV0KVxyXG4gICAgICAgICAgICAgIGlucHV0LnZhbHVlID0gIHZhbC5GaXJzdG5hbWVcclxuICAgICAgICAgICAgICBpbnB1dC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImlucHV0XCIsIHsgYnViYmxlczogdHJ1ZSB9KSlcclxuICAgICAgICAgICAgICBpbnB1dC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImNoYW5nZVwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpXHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAobGFiZWwuaW5uZXJUZXh0LmluY2x1ZGVzKFwiTGFzdCBuYW1lKlwiKSkge1xyXG4gICAgICAgICAgICAgIGxldCBpbnB1dCA9IGxhYmVsLnF1ZXJ5U2VsZWN0b3IoXCJpbnB1dFwiKVxyXG5cclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhpbnB1dClcclxuICAgICAgICAgICAgICBpbnB1dC52YWx1ZSA9IHZhbC5MYXN0bmFtZVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJpbnB1dFwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpXHJcbiAgICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuXHJcbiAgICAgICAgcmxhYmVscy5mb3JFYWNoKChsYWJlbCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgIGlmIChsYWJlbCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhsYWJlbC5pbm5lclRleHQpXHJcbiAgICAgICAgICAgIGlmIChsYWJlbC5pbm5lclRleHQuaW5jbHVkZXMoXCJQYXNzcG9ydCBudW1iZXIqXCIpKSB7XHJcbiAgICAgICAgICAgICAgbGV0IGlucHV0ID0gbGFiZWwucXVlcnlTZWxlY3RvcihcImlucHV0XCIpXHJcblxyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKGlucHV0KVxyXG4gICAgICAgICAgICAgIGlucHV0LnZhbHVlID0gdmFsLlBhc3Nwb3J0bnVtYmVyXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICBpbnB1dC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImlucHV0XCIsIHsgYnViYmxlczogdHJ1ZSB9KSlcclxuICAgICAgICAgICAgICBpbnB1dC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImNoYW5nZVwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpXHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAobGFiZWwuaW5uZXJUZXh0LmluY2x1ZGVzKFwiUmVzaWRlbmNlIGFkZHJlc3NcIikpIHtcclxuICAgICAgICAgICAgICBsZXQgaW5wdXQgPSBsYWJlbC5xdWVyeVNlbGVjdG9yKFwiaW5wdXRcIilcclxuXHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coaW5wdXQpXHJcbiAgICAgICAgICAgICAgaW5wdXQudmFsdWUgPSB2YWwuUmVzaWRlbmNlYWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJpbnB1dFwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpXHJcbiAgICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKGluZGV4ID09IDEpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcImh5XCIpXHJcbiAgICAgICAgbGV0IGxhYmVscyA9IGZpZWxkLnF1ZXJ5U2VsZWN0b3JBbGwoXCJsYWJlbFwiKVxyXG4gICAgICAgIGxhYmVscy5mb3JFYWNoKChsYWJlbCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgIGlmIChsYWJlbCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhsYWJlbC5pbm5lclRleHQpXHJcbiAgICAgICAgICAgIGlmIChsYWJlbC5pbm5lclRleHQuaW5jbHVkZXMoXCJQaG9uZSpcIikpIHtcclxuICAgICAgICAgICAgICBsZXQgaW5wdXQgPSBsYWJlbC5xdWVyeVNlbGVjdG9yKFwiaW5wdXRcIilcclxuXHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coaW5wdXQpXHJcbiAgICAgICAgICAgICAgaW5wdXQudmFsdWUgPSB2YWwucGhvbmVcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIGlucHV0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiaW5wdXRcIiwgeyBidWJibGVzOiB0cnVlIH0pKVxyXG4gICAgICAgICAgICAgIGlucHV0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiY2hhbmdlXCIsIHsgYnViYmxlczogdHJ1ZSB9KSlcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChsYWJlbC5pbm5lclRleHQuaW5jbHVkZXMoXCJFbWFpbCpcIikpIHtcclxuICAgICAgICAgICAgICBsZXQgaW5wdXQgPSBsYWJlbC5xdWVyeVNlbGVjdG9yKFwiaW5wdXRcIilcclxuXHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coaW5wdXQpXHJcbiAgICAgICAgICAgICAgaW5wdXQudmFsdWUgPSB2YWwuZW1haWxcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIGlucHV0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiaW5wdXRcIiwgeyBidWJibGVzOiB0cnVlIH0pKVxyXG4gICAgICAgICAgICAgIGlucHV0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiY2hhbmdlXCIsIHsgYnViYmxlczogdHJ1ZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChpbmRleCA9PSAyKSB7XHJcbiAgICAgICAgbGV0IGluc2lkZXNlY3Rpb24gPSBmaWVsZC5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAgICAgJ2RpdltjbGFzcyo9XCJncm91cGVkLWZpZWxkcyBuZy1zdGFyLWluc2VydGVkXCJdJ1xyXG4gICAgICAgIClcclxuICAgICAgICBjb25zb2xlLmxvZyhpbnNpZGVzZWN0aW9uKVxyXG5cclxuICAgICAgICBsZXQgbGFiZWxzID0gaW5zaWRlc2VjdGlvbi5xdWVyeVNlbGVjdG9yQWxsKFwibGFiZWxcIilcclxuICAgICAgICBjb25zb2xlLmxvZyhsYWJlbHMpXHJcblxyXG4gICAgICAgIGxhYmVscy5mb3JFYWNoKChsYWJlbCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgIGlmIChpbmRleCA9PSAwKSB7XHJcbiAgICAgICAgICAgIGxldCBuZ3NlbGVjdCA9IGxhYmVsLnF1ZXJ5U2VsZWN0b3IoXCJuZy1zZWxlY3RcIilcclxuICAgICAgICAgICAgbGV0IHNlbGVjdCA9IG5nc2VsZWN0LnF1ZXJ5U2VsZWN0b3IoXHJcbiAgICAgICAgICAgICAgJ2RpdiA+IGRpdltjbGFzcz1cIm5nLXZhbHVlLWNvbnRhaW5lclwiXSdcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhzZWxlY3QpXHJcbiAgICAgICAgICAgIGxldCBpbnB1dCA9IHNlbGVjdC5xdWVyeVNlbGVjdG9yKCdkaXZbcm9sZT1cImNvbWJvYm94XCJdID4gaW5wdXQnKVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhpbnB1dClcclxuICAgICAgICAgICAgLy8gbGV0IGlucHV0ID0gc2VsZWN0LnF1ZXJ5U2VsZWN0b3IoJ2lucHV0JylcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coaW5wdXQpXHJcbiAgICAgICAgICAgIGlucHV0LnZhbHVlID0gXCJWaXNhXCJcclxuICAgICAgICAgICAgaW5wdXQuZm9jdXMoKVxyXG5cclxuICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJpbnB1dFwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpXHJcbiAgICAgICAgICAgIGlucHV0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiY2hhbmdlXCIsIHsgYnViYmxlczogdHJ1ZSB9KSlcclxuXHJcbiAgICAgICAgICAgIGxldCBlbnRlckV2ZW50ID0gbmV3IEtleWJvYXJkRXZlbnQoXCJrZXlkb3duXCIsIHtcclxuICAgICAgICAgICAgICBidWJibGVzOiB0cnVlLFxyXG4gICAgICAgICAgICAgIGNhbmNlbGFibGU6IHRydWUsXHJcbiAgICAgICAgICAgICAga2V5OiBcIkVudGVyXCIsXHJcbiAgICAgICAgICAgICAga2V5Q29kZTogMTNcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgaW5wdXQuZGlzcGF0Y2hFdmVudChlbnRlckV2ZW50KVxyXG4gICAgICAgICAgfSBlbHNlIGlmIChpbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICAgIGxldCBkYXRlYW5kdGltZSA9IGxhYmVsLnF1ZXJ5U2VsZWN0b3IoXHJcbiAgICAgICAgICAgICAgJ2RpdltjbGFzcyo9XCJtYXQtZm9ybS1maWVsZC13cmFwcGVyXCJdJ1xyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGVhbmR0aW1lKVxyXG5cclxuICAgICAgICAgICAgbGV0IGNsaWNrc2VsZWN0ID0gZGF0ZWFuZHRpbWUucXVlcnlTZWxlY3RvcihcImRpdlwiKVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImNsaWNrc2VsZWN0XCIsIGNsaWNrc2VsZWN0KVxyXG4gICAgICAgICAgICBsZXQgY2xpY2sgPSBjbGlja3NlbGVjdC5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAgICAgICAgICdkaXZbY2xhc3MqPVwibWF0LWZvcm0tZmllbGQtaW5maXhcIl0nXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJjbGlja1wiLCBjbGljaylcclxuICAgICAgICAgICAgY2xpY2suY2xpY2soKVxyXG5cclxuICAgICAgICAgICAgLy8gZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChzY3JpcHQpO1xyXG5cclxuICAgICAgICAgICAgbGV0IGNoZWNraW5nYXZhaWwgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdkaXZbY2xhc3M9XCJyaWdodFwiXScpXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGNoZWNraW5nYXZhaWwpXHJcbiAgICAgICAgICAgIGxldCBzdGlja3ljYWwgPSBjaGVja2luZ2F2YWlsLnF1ZXJ5U2VsZWN0b3IoXHJcbiAgICAgICAgICAgICAgJ2RpdltjbGFzcyo9XCJzdGlja3ktY2FsZW5kYXJcIl0gPiBlYXAtc2VydmljZXMtY2FsZW5kYXInXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgICAgY29uc29sZS5sb2coc3RpY2t5Y2FsKVxyXG4gICAgICAgICAgICBsZXQgZGF0ZSA9IHN0aWNreWNhbC5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAgICAgICAgICdtd2wtY2FsZW5kYXItbW9udGgtdmlldyA+IGRpdltyb2xlPVwiZ3JpZFwiXSA+IGRpdltjbGFzcz1cImNhbC1kYXlzXCJdJ1xyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGUpXHJcbiAgICAgICAgICAgIC8vIGxldCBzbG90Qm9va2VkID0gZmFsc2VcclxuICAgICAgICAgICAgbGV0IGF2YWlsID0gZGF0ZS5xdWVyeVNlbGVjdG9yQWxsKCdkaXZbY2xhc3M9XCJuZy1zdGFyLWluc2VydGVkXCJdJylcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhdmFpbFwiLCBhdmFpbClcclxuICAgICAgICAgICAgYXZhaWwuZm9yRWFjaCgoZGF0ZXJvdykgPT4ge1xyXG4gICAgICAgICAgICAgIC8vICAgaWYgKHNsb3RCb29rZWQpIHJldHVyblxyXG4gICAgICAgICAgICAgIGxldCBtd2xfY2FsZW5kYXIgPSBkYXRlcm93LnF1ZXJ5U2VsZWN0b3JBbGwoXHJcbiAgICAgICAgICAgICAgICAnZGl2W3JvbGU9XCJyb3dcIl0gPiBtd2wtY2FsZW5kYXItbW9udGgtY2VsbCdcclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJtd2xfY2FsZW5kYXJcIiwgbXdsX2NhbGVuZGFyKVxyXG4gICAgICAgICAgICAgIG13bF9jYWxlbmRhci5mb3JFYWNoKChjYWxlbmRhcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGZvdW5kZGF0ZSA9IGNhbGVuZGFyLnF1ZXJ5U2VsZWN0b3IoXHJcbiAgICAgICAgICAgICAgICAgICdkaXYgPiBkaXZbY2xhc3M9XCJkYXRlXCJdJ1xyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZm91bmRkYXRlKVxyXG4gICAgICAgICAgICAgICAgbGV0IHNsb3RCb29rZWQgPSBmYWxzZSAvLyBFbnN1cmUgc2xvdEJvb2tlZCBpcyBkZWZpbmVkIG91dHNpZGUgdGhlIGZ1bmN0aW9uIHNjb3BlXHJcblxyXG4gICAgICAgICAgICAgICAgd2FpdEZvckRhdGVWYWx1ZShmb3VuZGRhdGUpXHJcbiAgICAgICAgICAgICAgICAgIC50aGVuKGFzeW5jIChkYXRlVmFsdWUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBwZXJmb3JtRnVydGhlck9wZXJhdGlvbnMoZGF0ZVZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiaGVyZVwiKVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGVWYWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICBzbG90Qm9va2VkID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGZpbmRkYXRlYW5kdGltZXNsb3QoZGF0ZVZhbHVlKVxyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm5cclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpXHJcbiAgICAgICAgICAgICAgICAgIH0pXHJcblxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJvdXQgb24gYXN5bmMgYXdhaXRcIilcclxuICAgICAgICAgICAgICAgIC8vIGlmIChmb3VuZGRhdGUpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcihcclxuICAgICAgICAgICAgICAgIC8vICAgICAobXV0YXRpb25zTGlzdCwgb2JzZXJ2ZXIpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgIGZvciAobGV0IG11dGF0aW9uIG9mIG11dGF0aW9uc0xpc3QpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgaWYgKHNsb3RCb29rZWQpIHJldHVyblxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBpZiAobXV0YXRpb24udHlwZSA9PT0gXCJjaGlsZExpc3RcIikge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgIGxldCBjaGVja2RhdGVhdmFpbCA9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICBmb3VuZGRhdGUucXVlcnlTZWxlY3RvcihcIm1hdC1pY29uXCIpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgaWYgKGNoZWNrZGF0ZWF2YWlsKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICBjb25zb2xlLmxvZyhcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgXCJtYXQtaWNvbiBlbGVtZW50IGZvdW5kOlwiLFxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICBjaGVja2RhdGVhdmFpbFxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gRXh0cmFjdCB0aGUgaW5uZXIgdGV4dCB2YWx1ZSBmcm9tIGZvdW5kZGF0ZVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgbGV0IGRhdGVWYWx1ZSA9IGZvdW5kZGF0ZS5pbm5lclRleHQudHJpbSgpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkRhdGUgdmFsdWU6XCIsIGRhdGVWYWx1ZSlcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIE9wdGlvbmFsbHkgZGlzY29ubmVjdCB0aGUgb2JzZXJ2ZXIgYWZ0ZXIgZmluZGluZyB0aGUgZWxlbWVudFxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICBzbG90Qm9va2VkID0gdHJ1ZTsgLy8gU2V0IHNsb3RCb29rZWQgdG8gdHJ1ZSB0byBzdG9wIGZ1cnRoZXIgcHJvY2Vzc2luZ1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyBsZXQgaW5wdXQgPSBkYXRlYW5kdGltZS5xdWVyeVNlbGVjdG9yKFwiaW5wdXRcIilcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGlucHV0KVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gY29uc3Qgbm93ID0gbmV3IERhdGUoKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gY29uc29sZS5sb2cobm93KVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gY29uc3QgeWVhciA9IG5vdy5nZXRGdWxsWWVhcigpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyBjb25zdCBtb250aCA9IChub3cuZ2V0TW9udGgoKSArIDEpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgIC5wYWRTdGFydCgyLCBcIjBcIilcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIGNvbnN0IGRheSA9IGRhdGVWYWx1ZVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gY29uc3QgZm9ybWF0dGVkRGF0ZSA9IGAke2RheX0uJHttb250aH0uJHt5ZWFyfWBcclxuXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyBpbnB1dC52YWx1ZSA9IGZvcm1hdHRlZERhdGVcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIGJ1dHRvbmNsaWNrZWQgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyBzbG90Qm9va2VkID0gdHJ1ZVxyXG5cclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIGxldCBidXR0b24gPVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICBtYWluLnF1ZXJ5U2VsZWN0b3IoJ2RpdltjbGFzcz1cImNvbnRlbnRcIl0gPiBkaXZbY2xhc3M9XCJsZWZ0XScpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhidXR0b24pXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyBjb25zdCBzdWJtaXQgPSBidXR0b24ucXVlcnlTZWxlY3RvcihcImJ1dHRvblwiKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gY29uc29sZS5sb2coc3VibWl0KVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gaWYgKHN1Ym1pdCkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICB0cnkge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICAgIHN1Ym1pdC5jbGljaygpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgICAgICBhbGVydChcImZvcm0gZmlsbGVkIHN1Y2Nlc3NmdWxseVwiKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICAgICAgd2luZG93LmNsb3NlKClcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vICAgICB9LCAxMDAwMClcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vICAgICAvLyBQcm9ncmFtbWF0aWNhbGx5IGNsaWNrIHRoZSBzdWJtaXQgYnV0dG9uXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coXCJoZXJlIGluc2lkZSBlcnJvclwiKVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgICAgd2luZG93LmNsb3NlKClcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgLy8gfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vICAgY29uc29sZS5lcnJvcihcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vICAgICBcIlN1Ym1pdCBidXR0b24gbm90IGZvdW5kIGluIHRoZSBmb3JtLlwiXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAvLyAgIClcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIC8vIHRoaXMgY29kZSByZXNwb25zaWJsZSBmb3IgcmVxdWVzdGluZyB0aGUgQXBwb2ludG1lbnRcclxuXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICByZXR1cm5cclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgIClcclxuXHJcbiAgICAgICAgICAgICAgICAvLyAgIG9ic2VydmVyLm9ic2VydmUoZm91bmRkYXRlLCB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgY2hpbGRMaXN0OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgLy8gICAgIHN1YnRyZWU6IHRydWVcclxuICAgICAgICAgICAgICAgIC8vICAgfSlcclxuICAgICAgICAgICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhkYXRlVmFsdWUpXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG5cclxuICAgIGNvbnNvbGUubG9nKFwibGV0cyBzdWJtaXQgdGhlIGZvcm1cIilcclxuICB9LCA1MDAwKVxyXG59XHJcblxyXG53aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImxvYWRcIiwgKCkgPT4ge1xyXG4gIFxyXG4gIGZpbGxzYW5kc3VibWl0c3ZhbHVlKClcclxuICBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICBcclxuICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBcImh0dHBzOi8vcHJvZ3JhbWFyaS5nb3YubWQvZW4vbWFlaWUvYXBwb2ludG1lbnRzLzY5YTdhNzllLWI0NGMtNDlkZS04ZTk2LTBjY2ZiNTY0ZjY1YVwiXHJcbiAgIFxyXG4gIH0sIDIwMDAwKVxyXG59KVxyXG4iLCJpbXBvcnQgeSBmcm9tXCJwaWZ5XCI7dmFyIGw9KCk9Pnt0cnl7bGV0IGU9KGdsb2JhbFRoaXMubmF2aWdhdG9yPy51c2VyQWdlbnQpLm1hdGNoKC8ob3BlcmF8Y2hyb21lfHNhZmFyaXxmaXJlZm94fG1zaWV8dHJpZGVudCg/PVxcLykpXFwvP1xccyooXFxkKykvaSl8fFtdO2lmKGVbMV09PT1cIkNocm9tZVwiKXJldHVybiBwYXJzZUludChlWzJdKTwxMDB8fGdsb2JhbFRoaXMuY2hyb21lLnJ1bnRpbWU/LmdldE1hbmlmZXN0KCk/Lm1hbmlmZXN0X3ZlcnNpb249PT0yfWNhdGNoe3JldHVybiExfXJldHVybiExfTt2YXIgbz1jbGFzc3sjcjsjZTtnZXQgcHJpbWFyeUNsaWVudCgpe3JldHVybiB0aGlzLiNlfSN0O2dldCBzZWNvbmRhcnlDbGllbnQoKXtyZXR1cm4gdGhpcy4jdH0jYTtnZXQgYXJlYSgpe3JldHVybiB0aGlzLiNhfWdldCBoYXNXZWJBcGkoKXt0cnl7cmV0dXJuIHR5cGVvZiB3aW5kb3c8XCJ1XCImJiEhd2luZG93LmxvY2FsU3RvcmFnZX1jYXRjaChlKXtyZXR1cm4gY29uc29sZS5lcnJvcihlKSwhMX19I3M9bmV3IE1hcDsjaTtnZXQgY29waWVkS2V5U2V0KCl7cmV0dXJuIHRoaXMuI2l9aXNDb3BpZWQ9ZT0+dGhpcy5oYXNXZWJBcGkmJih0aGlzLmFsbENvcGllZHx8dGhpcy5jb3BpZWRLZXlTZXQuaGFzKGUpKTsjbj0hMTtnZXQgYWxsQ29waWVkKCl7cmV0dXJuIHRoaXMuI259Z2V0RXh0U3RvcmFnZUFwaT0oKT0+Z2xvYmFsVGhpcy5icm93c2VyPy5zdG9yYWdlfHxnbG9iYWxUaGlzLmNocm9tZT8uc3RvcmFnZTtnZXQgaGFzRXh0ZW5zaW9uQXBpKCl7dHJ5e3JldHVybiEhdGhpcy5nZXRFeHRTdG9yYWdlQXBpKCl9Y2F0Y2goZSl7cmV0dXJuIGNvbnNvbGUuZXJyb3IoZSksITF9fWlzV2F0Y2hTdXBwb3J0ZWQ9KCk9PnRoaXMuaGFzRXh0ZW5zaW9uQXBpO2tleU5hbWVzcGFjZT1cIlwiO2lzVmFsaWRLZXk9ZT0+ZS5zdGFydHNXaXRoKHRoaXMua2V5TmFtZXNwYWNlKTtnZXROYW1lc3BhY2VkS2V5PWU9PmAke3RoaXMua2V5TmFtZXNwYWNlfSR7ZX1gO2dldFVubmFtZXNwYWNlZEtleT1lPT5lLnNsaWNlKHRoaXMua2V5TmFtZXNwYWNlLmxlbmd0aCk7c2VyZGU9e3NlcmlhbGl6ZXI6SlNPTi5zdHJpbmdpZnksZGVzZXJpYWxpemVyOkpTT04ucGFyc2V9O2NvbnN0cnVjdG9yKHthcmVhOmU9XCJzeW5jXCIsYWxsQ29waWVkOnQ9ITEsY29waWVkS2V5TGlzdDpzPVtdLHNlcmRlOnI9e319PXt9KXt0aGlzLnNldENvcGllZEtleVNldChzKSx0aGlzLiNhPWUsdGhpcy4jbj10LHRoaXMuc2VyZGU9ey4uLnRoaXMuc2VyZGUsLi4ucn07dHJ5e3RoaXMuaGFzV2ViQXBpJiYodHx8cy5sZW5ndGg+MCkmJih0aGlzLiN0PXdpbmRvdy5sb2NhbFN0b3JhZ2UpfWNhdGNoe310cnl7dGhpcy5oYXNFeHRlbnNpb25BcGkmJih0aGlzLiNyPXRoaXMuZ2V0RXh0U3RvcmFnZUFwaSgpLGwoKT90aGlzLiNlPXkodGhpcy4jclt0aGlzLmFyZWFdLHtleGNsdWRlOltcImdldEJ5dGVzSW5Vc2VcIl0sZXJyb3JGaXJzdDohMX0pOnRoaXMuI2U9dGhpcy4jclt0aGlzLmFyZWFdKX1jYXRjaHt9fXNldENvcGllZEtleVNldChlKXt0aGlzLiNpPW5ldyBTZXQoZSl9cmF3R2V0QWxsPSgpPT50aGlzLiNlPy5nZXQoKTtnZXRBbGw9YXN5bmMoKT0+e2xldCBlPWF3YWl0IHRoaXMucmF3R2V0QWxsKCk7cmV0dXJuIE9iamVjdC5lbnRyaWVzKGUpLmZpbHRlcigoW3RdKT0+dGhpcy5pc1ZhbGlkS2V5KHQpKS5yZWR1Y2UoKHQsW3Mscl0pPT4odFt0aGlzLmdldFVubmFtZXNwYWNlZEtleShzKV09cix0KSx7fSl9O2NvcHk9YXN5bmMgZT0+e2xldCB0PWU9PT12b2lkIDA7aWYoIXQmJiF0aGlzLmNvcGllZEtleVNldC5oYXMoZSl8fCF0aGlzLmFsbENvcGllZHx8IXRoaXMuaGFzRXh0ZW5zaW9uQXBpKXJldHVybiExO2xldCBzPXRoaXMuYWxsQ29waWVkP2F3YWl0IHRoaXMucmF3R2V0QWxsKCk6YXdhaXQgdGhpcy4jZS5nZXQoKHQ/Wy4uLnRoaXMuY29waWVkS2V5U2V0XTpbZV0pLm1hcCh0aGlzLmdldE5hbWVzcGFjZWRLZXkpKTtpZighcylyZXR1cm4hMTtsZXQgcj0hMTtmb3IobGV0IGEgaW4gcyl7bGV0IGk9c1thXSxuPXRoaXMuI3Q/LmdldEl0ZW0oYSk7dGhpcy4jdD8uc2V0SXRlbShhLGkpLHJ8fD1pIT09bn1yZXR1cm4gcn07cmF3R2V0PWFzeW5jIGU9PnRoaXMuaGFzRXh0ZW5zaW9uQXBpPyhhd2FpdCB0aGlzLiNlLmdldChlKSlbZV06dGhpcy5pc0NvcGllZChlKT90aGlzLiN0Py5nZXRJdGVtKGUpOm51bGw7cmF3U2V0PWFzeW5jKGUsdCk9Pih0aGlzLmlzQ29waWVkKGUpJiZ0aGlzLiN0Py5zZXRJdGVtKGUsdCksdGhpcy5oYXNFeHRlbnNpb25BcGkmJmF3YWl0IHRoaXMuI2Uuc2V0KHtbZV06dH0pLG51bGwpO2NsZWFyPWFzeW5jKGU9ITEpPT57ZSYmdGhpcy4jdD8uY2xlYXIoKSxhd2FpdCB0aGlzLiNlLmNsZWFyKCl9O3Jhd1JlbW92ZT1hc3luYyBlPT57dGhpcy5pc0NvcGllZChlKSYmdGhpcy4jdD8ucmVtb3ZlSXRlbShlKSx0aGlzLmhhc0V4dGVuc2lvbkFwaSYmYXdhaXQgdGhpcy4jZS5yZW1vdmUoZSl9O3JlbW92ZUFsbD1hc3luYygpPT57bGV0IGU9YXdhaXQgdGhpcy5nZXRBbGwoKSx0PU9iamVjdC5rZXlzKGUpO2F3YWl0IFByb21pc2UuYWxsKHQubWFwKHRoaXMucmVtb3ZlKSl9O3dhdGNoPWU9PntsZXQgdD10aGlzLmlzV2F0Y2hTdXBwb3J0ZWQoKTtyZXR1cm4gdCYmdGhpcy4jbyhlKSx0fTsjbz1lPT57Zm9yKGxldCB0IGluIGUpe2xldCBzPXRoaXMuZ2V0TmFtZXNwYWNlZEtleSh0KSxyPXRoaXMuI3MuZ2V0KHMpPy5jYWxsYmFja1NldHx8bmV3IFNldDtpZihyLmFkZChlW3RdKSxyLnNpemU+MSljb250aW51ZTtsZXQgYT0oaSxuKT0+e2lmKG4hPT10aGlzLmFyZWF8fCFpW3NdKXJldHVybjtsZXQgaD10aGlzLiNzLmdldChzKTtpZighaCl0aHJvdyBuZXcgRXJyb3IoYFN0b3JhZ2UgY29tbXMgZG9lcyBub3QgZXhpc3QgZm9yIG5zS2V5OiAke3N9YCk7UHJvbWlzZS5hbGwoW3RoaXMucGFyc2VWYWx1ZShpW3NdLm5ld1ZhbHVlKSx0aGlzLnBhcnNlVmFsdWUoaVtzXS5vbGRWYWx1ZSldKS50aGVuKChbcCxkXSk9Pntmb3IobGV0IG0gb2YgaC5jYWxsYmFja1NldCltKHtuZXdWYWx1ZTpwLG9sZFZhbHVlOmR9LG4pfSl9O3RoaXMuI3Iub25DaGFuZ2VkLmFkZExpc3RlbmVyKGEpLHRoaXMuI3Muc2V0KHMse2NhbGxiYWNrU2V0OnIsbGlzdGVuZXI6YX0pfX07dW53YXRjaD1lPT57bGV0IHQ9dGhpcy5pc1dhdGNoU3VwcG9ydGVkKCk7cmV0dXJuIHQmJnRoaXMuI2MoZSksdH07I2MoZSl7Zm9yKGxldCB0IGluIGUpe2xldCBzPXRoaXMuZ2V0TmFtZXNwYWNlZEtleSh0KSxyPWVbdF0sYT10aGlzLiNzLmdldChzKTthJiYoYS5jYWxsYmFja1NldC5kZWxldGUociksYS5jYWxsYmFja1NldC5zaXplPT09MCYmKHRoaXMuI3MuZGVsZXRlKHMpLHRoaXMuI3Iub25DaGFuZ2VkLnJlbW92ZUxpc3RlbmVyKGEubGlzdGVuZXIpKSl9fXVud2F0Y2hBbGw9KCk9PnRoaXMuI2goKTsjaCgpe3RoaXMuI3MuZm9yRWFjaCgoe2xpc3RlbmVyOmV9KT0+dGhpcy4jci5vbkNoYW5nZWQucmVtb3ZlTGlzdGVuZXIoZSkpLHRoaXMuI3MuY2xlYXIoKX1hc3luYyBnZXRJdGVtKGUpe3JldHVybiB0aGlzLmdldChlKX1hc3luYyBzZXRJdGVtKGUsdCl7YXdhaXQgdGhpcy5zZXQoZSx0KX1hc3luYyByZW1vdmVJdGVtKGUpe3JldHVybiB0aGlzLnJlbW92ZShlKX19LGc9Y2xhc3MgZXh0ZW5kcyBve2dldD1hc3luYyBlPT57bGV0IHQ9dGhpcy5nZXROYW1lc3BhY2VkS2V5KGUpLHM9YXdhaXQgdGhpcy5yYXdHZXQodCk7cmV0dXJuIHRoaXMucGFyc2VWYWx1ZShzKX07c2V0PWFzeW5jKGUsdCk9PntsZXQgcz10aGlzLmdldE5hbWVzcGFjZWRLZXkoZSkscj10aGlzLnNlcmRlLnNlcmlhbGl6ZXIodCk7cmV0dXJuIHRoaXMucmF3U2V0KHMscil9O3JlbW92ZT1hc3luYyBlPT57bGV0IHQ9dGhpcy5nZXROYW1lc3BhY2VkS2V5KGUpO3JldHVybiB0aGlzLnJhd1JlbW92ZSh0KX07c2V0TmFtZXNwYWNlPWU9Pnt0aGlzLmtleU5hbWVzcGFjZT1lfTtwYXJzZVZhbHVlPWFzeW5jIGU9Pnt0cnl7aWYoZSE9PXZvaWQgMClyZXR1cm4gdGhpcy5zZXJkZS5kZXNlcmlhbGl6ZXIoZSl9Y2F0Y2godCl7Y29uc29sZS5lcnJvcih0KX19fTtleHBvcnR7byBhcyBCYXNlU3RvcmFnZSxnIGFzIFN0b3JhZ2V9O1xuIiwiY29uc3QgcHJvY2Vzc0Z1bmN0aW9uID0gKGZ1bmN0aW9uXywgb3B0aW9ucywgcHJveHksIHVud3JhcHBlZCkgPT4gZnVuY3Rpb24gKC4uLmFyZ3VtZW50c18pIHtcblx0Y29uc3QgUCA9IG9wdGlvbnMucHJvbWlzZU1vZHVsZTtcblxuXHRyZXR1cm4gbmV3IFAoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGlmIChvcHRpb25zLm11bHRpQXJncykge1xuXHRcdFx0YXJndW1lbnRzXy5wdXNoKCguLi5yZXN1bHQpID0+IHtcblx0XHRcdFx0aWYgKG9wdGlvbnMuZXJyb3JGaXJzdCkge1xuXHRcdFx0XHRcdGlmIChyZXN1bHRbMF0pIHtcblx0XHRcdFx0XHRcdHJlamVjdChyZXN1bHQpO1xuXHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRyZXN1bHQuc2hpZnQoKTtcblx0XHRcdFx0XHRcdHJlc29sdmUocmVzdWx0KTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0cmVzb2x2ZShyZXN1bHQpO1xuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9IGVsc2UgaWYgKG9wdGlvbnMuZXJyb3JGaXJzdCkge1xuXHRcdFx0YXJndW1lbnRzXy5wdXNoKChlcnJvciwgcmVzdWx0KSA9PiB7XG5cdFx0XHRcdGlmIChlcnJvcikge1xuXHRcdFx0XHRcdHJlamVjdChlcnJvcik7XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0cmVzb2x2ZShyZXN1bHQpO1xuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0YXJndW1lbnRzXy5wdXNoKHJlc29sdmUpO1xuXHRcdH1cblxuXHRcdGNvbnN0IHNlbGYgPSB0aGlzID09PSBwcm94eSA/IHVud3JhcHBlZCA6IHRoaXM7XG5cdFx0UmVmbGVjdC5hcHBseShmdW5jdGlvbl8sIHNlbGYsIGFyZ3VtZW50c18pO1xuXHR9KTtcbn07XG5cbmNvbnN0IGZpbHRlckNhY2hlID0gbmV3IFdlYWtNYXAoKTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gcGlmeShpbnB1dCwgb3B0aW9ucykge1xuXHRvcHRpb25zID0ge1xuXHRcdGV4Y2x1ZGU6IFsvLisoPzpTeW5jfFN0cmVhbSkkL10sXG5cdFx0ZXJyb3JGaXJzdDogdHJ1ZSxcblx0XHRwcm9taXNlTW9kdWxlOiBQcm9taXNlLFxuXHRcdC4uLm9wdGlvbnMsXG5cdH07XG5cblx0Y29uc3Qgb2JqZWN0VHlwZSA9IHR5cGVvZiBpbnB1dDtcblx0aWYgKCEoaW5wdXQgIT09IG51bGwgJiYgKG9iamVjdFR5cGUgPT09ICdvYmplY3QnIHx8IG9iamVjdFR5cGUgPT09ICdmdW5jdGlvbicpKSkge1xuXHRcdHRocm93IG5ldyBUeXBlRXJyb3IoYEV4cGVjdGVkIFxcYGlucHV0XFxgIHRvIGJlIGEgXFxgRnVuY3Rpb25cXGAgb3IgXFxgT2JqZWN0XFxgLCBnb3QgXFxgJHtpbnB1dCA9PT0gbnVsbCA/ICdudWxsJyA6IG9iamVjdFR5cGV9XFxgYCk7XG5cdH1cblxuXHRjb25zdCBmaWx0ZXIgPSAodGFyZ2V0LCBrZXkpID0+IHtcblx0XHRsZXQgY2FjaGVkID0gZmlsdGVyQ2FjaGUuZ2V0KHRhcmdldCk7XG5cblx0XHRpZiAoIWNhY2hlZCkge1xuXHRcdFx0Y2FjaGVkID0ge307XG5cdFx0XHRmaWx0ZXJDYWNoZS5zZXQodGFyZ2V0LCBjYWNoZWQpO1xuXHRcdH1cblxuXHRcdGlmIChrZXkgaW4gY2FjaGVkKSB7XG5cdFx0XHRyZXR1cm4gY2FjaGVkW2tleV07XG5cdFx0fVxuXG5cdFx0Y29uc3QgbWF0Y2ggPSBwYXR0ZXJuID0+ICh0eXBlb2YgcGF0dGVybiA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIGtleSA9PT0gJ3N5bWJvbCcpID8ga2V5ID09PSBwYXR0ZXJuIDogcGF0dGVybi50ZXN0KGtleSk7XG5cdFx0Y29uc3QgZGVzY3JpcHRvciA9IFJlZmxlY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHRhcmdldCwga2V5KTtcblx0XHRjb25zdCB3cml0YWJsZU9yQ29uZmlndXJhYmxlT3duID0gKGRlc2NyaXB0b3IgPT09IHVuZGVmaW5lZCB8fCBkZXNjcmlwdG9yLndyaXRhYmxlIHx8IGRlc2NyaXB0b3IuY29uZmlndXJhYmxlKTtcblx0XHRjb25zdCBpbmNsdWRlZCA9IG9wdGlvbnMuaW5jbHVkZSA/IG9wdGlvbnMuaW5jbHVkZS5zb21lKGVsZW1lbnQgPT4gbWF0Y2goZWxlbWVudCkpIDogIW9wdGlvbnMuZXhjbHVkZS5zb21lKGVsZW1lbnQgPT4gbWF0Y2goZWxlbWVudCkpO1xuXHRcdGNvbnN0IHNob3VsZEZpbHRlciA9IGluY2x1ZGVkICYmIHdyaXRhYmxlT3JDb25maWd1cmFibGVPd247XG5cdFx0Y2FjaGVkW2tleV0gPSBzaG91bGRGaWx0ZXI7XG5cdFx0cmV0dXJuIHNob3VsZEZpbHRlcjtcblx0fTtcblxuXHRjb25zdCBjYWNoZSA9IG5ldyBXZWFrTWFwKCk7XG5cblx0Y29uc3QgcHJveHkgPSBuZXcgUHJveHkoaW5wdXQsIHtcblx0XHRhcHBseSh0YXJnZXQsIHRoaXNBcmcsIGFyZ3MpIHtcblx0XHRcdGNvbnN0IGNhY2hlZCA9IGNhY2hlLmdldCh0YXJnZXQpO1xuXG5cdFx0XHRpZiAoY2FjaGVkKSB7XG5cdFx0XHRcdHJldHVybiBSZWZsZWN0LmFwcGx5KGNhY2hlZCwgdGhpc0FyZywgYXJncyk7XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IHBpZmllZCA9IG9wdGlvbnMuZXhjbHVkZU1haW4gPyB0YXJnZXQgOiBwcm9jZXNzRnVuY3Rpb24odGFyZ2V0LCBvcHRpb25zLCBwcm94eSwgdGFyZ2V0KTtcblx0XHRcdGNhY2hlLnNldCh0YXJnZXQsIHBpZmllZCk7XG5cdFx0XHRyZXR1cm4gUmVmbGVjdC5hcHBseShwaWZpZWQsIHRoaXNBcmcsIGFyZ3MpO1xuXHRcdH0sXG5cblx0XHRnZXQodGFyZ2V0LCBrZXkpIHtcblx0XHRcdGNvbnN0IHByb3BlcnR5ID0gdGFyZ2V0W2tleV07XG5cblx0XHRcdC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11c2UtZXh0ZW5kLW5hdGl2ZS9uby11c2UtZXh0ZW5kLW5hdGl2ZVxuXHRcdFx0aWYgKCFmaWx0ZXIodGFyZ2V0LCBrZXkpIHx8IHByb3BlcnR5ID09PSBGdW5jdGlvbi5wcm90b3R5cGVba2V5XSkge1xuXHRcdFx0XHRyZXR1cm4gcHJvcGVydHk7XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IGNhY2hlZCA9IGNhY2hlLmdldChwcm9wZXJ0eSk7XG5cblx0XHRcdGlmIChjYWNoZWQpIHtcblx0XHRcdFx0cmV0dXJuIGNhY2hlZDtcblx0XHRcdH1cblxuXHRcdFx0aWYgKHR5cGVvZiBwcm9wZXJ0eSA9PT0gJ2Z1bmN0aW9uJykge1xuXHRcdFx0XHRjb25zdCBwaWZpZWQgPSBwcm9jZXNzRnVuY3Rpb24ocHJvcGVydHksIG9wdGlvbnMsIHByb3h5LCB0YXJnZXQpO1xuXHRcdFx0XHRjYWNoZS5zZXQocHJvcGVydHksIHBpZmllZCk7XG5cdFx0XHRcdHJldHVybiBwaWZpZWQ7XG5cdFx0XHR9XG5cblx0XHRcdHJldHVybiBwcm9wZXJ0eTtcblx0XHR9LFxuXHR9KTtcblxuXHRyZXR1cm4gcHJveHk7XG59XG4iLCJleHBvcnRzLmludGVyb3BEZWZhdWx0ID0gZnVuY3Rpb24gKGEpIHtcbiAgcmV0dXJuIGEgJiYgYS5fX2VzTW9kdWxlID8gYSA6IHtkZWZhdWx0OiBhfTtcbn07XG5cbmV4cG9ydHMuZGVmaW5lSW50ZXJvcEZsYWcgPSBmdW5jdGlvbiAoYSkge1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkoYSwgJ19fZXNNb2R1bGUnLCB7dmFsdWU6IHRydWV9KTtcbn07XG5cbmV4cG9ydHMuZXhwb3J0QWxsID0gZnVuY3Rpb24gKHNvdXJjZSwgZGVzdCkge1xuICBPYmplY3Qua2V5cyhzb3VyY2UpLmZvckVhY2goZnVuY3Rpb24gKGtleSkge1xuICAgIGlmIChrZXkgPT09ICdkZWZhdWx0JyB8fCBrZXkgPT09ICdfX2VzTW9kdWxlJyB8fCBkZXN0Lmhhc093blByb3BlcnR5KGtleSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZGVzdCwga2V5LCB7XG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBzb3VyY2Vba2V5XTtcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0pO1xuXG4gIHJldHVybiBkZXN0O1xufTtcblxuZXhwb3J0cy5leHBvcnQgPSBmdW5jdGlvbiAoZGVzdCwgZGVzdE5hbWUsIGdldCkge1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZGVzdCwgZGVzdE5hbWUsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZ2V0LFxuICB9KTtcbn07XG4iXSwibmFtZXMiOltdLCJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybWZpbGwuMTdiM2Q3MjMuanMubWFwIn0=
 globalThis.define=__define;  })(globalThis.define);